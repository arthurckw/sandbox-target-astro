/**
 * GrandJury Chrome Extension Service Worker
 * Handles API communication, authentication, and configuration management
 */

// Configuration constants
const API_BASE_URL = 'https://grandjury-server.onrender.com'; // Production API URL
const LOCAL_API_URL = 'http://127.0.0.1:8001'; // Development API URL (fallback)
const CONFIG_CACHE_DURATION = 5 * 60 * 1000; // 5 minutes in milliseconds
const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes in milliseconds

// Extension state management
let isAuthenticated = false;
let authToken = null;
let configCache = null;
let configCacheTimestamp = null;
let evaluationSession = null;

// Chrome-resistant authentication state
let keepAliveInterval = null;
let lastAuthValidation = null;
let sessionBackupData = null;

// Auth flow state (for tab restoration)
let pendingAuthPreviousTabId = null;
let pendingAuthTabId = null;

/**
 * Initialize extension on startup
 */
chrome.runtime.onStartup.addListener(async () => {
  console.log('GrandJury Extension: Service worker started');
  await initializeChromeResistantAuth();
});

chrome.runtime.onInstalled.addListener(async () => {
  console.log('GrandJury Extension: Extension installed/updated');
  await initializeChromeResistantAuth();
});

/**
 * Open side panel when extension icon is clicked
 */
chrome.action.onClicked.addListener(async (tab) => {
  console.log('GrandJury Extension: Extension icon clicked, opening side panel');
  await chrome.sidePanel.open({ windowId: tab.windowId });
});

/**
 * Initialize Chrome-resistant authentication system
 */
async function initializeChromeResistantAuth() {
  try {
    console.log('GrandJury Extension: Initializing Chrome-resistant auth system');
    
    // Step 1: Start keepalive to prevent service worker termination
    startServiceWorkerKeepAlive();
    
    // Step 2: Attempt to restore authentication from multiple sources
    await loadStoredAuth();
    
    // Step 3: If no auth found, try web page session backup
    if (!authToken) {
      await attemptSessionRecovery();
    }
    
    // Step 4: Validate current authentication if available
    if (authToken) {
      await checkAuthStatus();
    }
    
    console.log('GrandJury Extension: Auth system initialized. Authenticated:', isAuthenticated);
    
  } catch (error) {
    console.error('GrandJury Extension: Error initializing auth system:', error);
  }
}

/**
 * Start service worker keepalive to prevent Chrome termination
 */
function startServiceWorkerKeepAlive() {
  // Clear any existing interval
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
  }
  
  // Chrome service workers can be terminated after 30 seconds of inactivity
  // Keep alive with lightweight operations every 25 seconds
  keepAliveInterval = setInterval(async () => {
    try {
      // Lightweight operation to keep service worker alive
      await chrome.storage.local.get(['keepAlive']);
      await chrome.storage.local.set({ keepAlive: Date.now() });
      
      // Validate auth periodically if we have a token
      const now = Date.now();
      if (authToken && (!lastAuthValidation || now - lastAuthValidation > 5 * 60 * 1000)) {
        console.log('GrandJury Extension: Periodic auth validation');
        await validateAuthenticationQuietly();
        lastAuthValidation = now;
      }
    } catch (error) {
      console.log('GrandJury Extension: Keepalive error (non-critical):', error.message);
    }
  }, 25000); // 25 seconds
  
  console.log('GrandJury Extension: Service worker keepalive started');
}

/**
 * Attempt to recover session from web page storage
 */
async function attemptSessionRecovery() {
  try {
    console.log('GrandJury Extension: Attempting session recovery from web pages');
    
    // Try to get active tabs to look for GrandJury pages
    const tabs = await chrome.tabs.query({
      url: ['*://grandjury.xyz/*', '*://*.grandjury.xyz/*', '*://humanjudge.com/*', '*://*.humanjudge.com/*', '*://grandjury-server.onrender.com/*', '*://localhost:*/*']
    });

    for (const tab of tabs) {
      try {
        console.log('GrandJury Extension: Checking tab for session data:', tab.url);

        // Ask content script to check for stored auth
        const response = await chrome.tabs.sendMessage(tab.id, {
          action: 'REQUEST_AUTH_BACKUP'
        });
        
        if (response && response.token) {
          console.log('GrandJury Extension: Recovered auth token from web page');
          await storeAuthToken(response.token);
          return true;
        }
      } catch (error) {
        // Content script might not be loaded, continue to next tab
        console.log('GrandJury Extension: Could not contact content script on tab:', tab.url);
      }
    }
    
    console.log('GrandJury Extension: No session recovery possible from web pages');
    return false;
    
  } catch (error) {
    console.error('GrandJury Extension: Error during session recovery:', error);
    return false;
  }
}

/**
 * Validate authentication without disrupting user experience
 */
async function validateAuthenticationQuietly() {
  try {
    if (!authToken) return false;
    
    const apiUrl = await getApiUrl();
    const response = await fetch(`${apiUrl}/api/v1/extension/auth/validate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        token: authToken,
        extension_version: "1.0.0"
      }),
      signal: AbortSignal.timeout(10000) // 10 second timeout
    });

    if (response.ok) {
      const result = await response.json();
      if (result.valid) {
        isAuthenticated = true;
        // Extend session silently
        await extendSessionSilently();
        return true;
      }
    }
    
    // Auth failed, clear but don't log extensively
    await clearAuth();
    return false;
    
  } catch (error) {
    // Network issues or timeouts - don't clear auth immediately
    console.log('GrandJury Extension: Quiet auth validation failed (keeping current state):', error.message);
    return false;
  }
}

/**
 * Extend session without full re-authentication
 */
async function extendSessionSilently() {
  try {
    const sessionExpiry = Date.now() + SESSION_TIMEOUT;
    const authData = {
      authToken: authToken,
      sessionExpiry: sessionExpiry,
      lastActivity: Date.now()
    };
    
    // Store in both storages silently
    await Promise.all([
      chrome.storage.local.set(authData),
      chrome.storage.session.set(authData)
    ]);
    
    // Update session backup data
    sessionBackupData = authData;
    
  } catch (error) {
    console.log('GrandJury Extension: Silent session extension failed:', error.message);
  }
}

/**
 * Load stored authentication data with Chrome-resistant fallbacks
 */
async function loadStoredAuth() {
  try {
    console.log('GrandJury Extension: loadStoredAuth() called at:', new Date().toISOString());
    
    // Step 1: Try local storage first (primary source)
    let result = await chrome.storage.local.get(['authToken', 'sessionExpiry', 'lastActivity']);
    let storageSource = 'local';
    
    // Step 2: If local storage is empty, try session storage
    if (!result.authToken && chrome.storage.session) {
      result = await chrome.storage.session.get(['authToken', 'sessionExpiry', 'lastActivity']);
      storageSource = 'session';
      
      // If we found auth in session storage, restore it to local storage
      if (result.authToken) {
        console.log('GrandJury Extension: Restoring auth from session storage to local storage');
        await chrome.storage.local.set(result);
      }
    }
    
    // Step 3: If no storage auth found, try session backup data (in-memory)
    if (!result.authToken && sessionBackupData) {
      console.log('GrandJury Extension: Attempting restore from in-memory backup');
      result = sessionBackupData;
      storageSource = 'memory-backup';
      
      // Restore to both storages
      await Promise.all([
        chrome.storage.local.set(result),
        chrome.storage.session.set(result)
      ]);
    }
    
    // Step 4: Process authentication data if found (only require authToken, sessionExpiry is optional for auto-auth)
    if (result.authToken) {
      const now = Date.now();
      const timeUntilExpiry = result.sessionExpiry ? result.sessionExpiry - now : -Infinity;
      console.log('GrandJury Extension: Found stored auth in', storageSource, 'storage.',
        result.sessionExpiry ? `Time until expiry: ${Math.round(timeUntilExpiry / 1000 / 60)} minutes` : 'No expiry set');

      // AUTO-AUTH: Always restore token if present, let API validation determine if still valid
      // This enables auto-login when user reopens extension (even after local session "expired")
      authToken = result.authToken;
      isAuthenticated = true;
      sessionBackupData = result; // Keep backup in memory

      // Extend session automatically on every restore (keeps local session fresh)
      const newExpiry = Date.now() + SESSION_TIMEOUT;
      const extendedData = { ...result, sessionExpiry: newExpiry, lastActivity: Date.now() };
      await Promise.all([
        chrome.storage.local.set(extendedData),
        chrome.storage.session.set(extendedData)
      ]);
      sessionBackupData = extendedData;

      const wasExpired = timeUntilExpiry <= 0;
      console.log('GrandJury Extension: Restored authentication from', storageSource, 'storage', wasExpired ? '(session was expired, auto-restored)' : '');

      const restoreEvent = {
        type: 'AUTH_RESTORED',
        timestamp: new Date().toISOString(),
        storageSource: storageSource,
        timeUntilExpiry: Math.round(timeUntilExpiry / 1000 / 60),
        wasExpired: wasExpired,
        autoRestored: true,
        chromeResistant: true
      };
      await logPersistentEvent(restoreEvent);
    } else {
      console.log('GrandJury Extension: No stored authentication found in any source');
      const noAuthEvent = {
        type: 'AUTH_STORAGE_EMPTY',
        timestamp: new Date().toISOString(),
        localStorageKeys: Object.keys(await chrome.storage.local.get()),
        sessionStorageAvailable: !!chrome.storage.session,
        memoryBackupAvailable: !!sessionBackupData,
        chromeResistant: true
      };
      await logPersistentEvent(noAuthEvent);
    }
  } catch (error) {
    console.error('GrandJury Extension: Error loading stored auth:', error);
  }
}

/**
 * Clear all authentication data from all sources
 */
async function clearAllStoredAuth() {
  try {
    // Clear Chrome storage
    await chrome.storage.local.remove(['authToken', 'sessionExpiry', 'lastActivity']);
    if (chrome.storage.session) {
      await chrome.storage.session.remove(['authToken', 'sessionExpiry', 'lastActivity']);
    }
    
    // Clear memory backup
    sessionBackupData = null;
    
    // Reset state
    authToken = null;
    isAuthenticated = false;
    
  } catch (error) {
    console.error('GrandJury Extension: Error clearing auth from all sources:', error);
  }
}

/**
 * Restore authentication from storage (wrapper for loadStoredAuth)
 * Called when authToken is null to attempt restoration
 * @returns {Promise<boolean>} True if auth was restored, false otherwise
 */
async function restoreAuthenticationFromStorage() {
  try {
    console.log('GrandJury Extension: Attempting to restore authentication from storage');

    // Use existing loadStoredAuth function which handles:
    // 1. Chrome local storage
    // 2. Chrome session storage
    // 3. In-memory backup
    // 4. Session expiry validation
    await loadStoredAuth();

    // Check if restoration was successful
    if (authToken) {
      console.log('GrandJury Extension: ✅ Authentication restored successfully');
      return true;
    }

    console.log('GrandJury Extension: ⚠️ No valid authentication found in storage');
    return false;
  } catch (error) {
    console.error('GrandJury Extension: ❌ Error restoring authentication:', error);
    return false;
  }
}

/**
 * Check authentication status with API
 */
async function checkAuthStatus() {
  console.log('GrandJury Extension: checkAuthStatus() called at:', new Date().toISOString());
  console.log('GrandJury Extension: Current authToken present:', !!authToken);

  // If authToken is null, try to restore from storage (service worker may have restarted)
  if (!authToken) {
    console.log('GrandJury Extension: No auth token in memory, attempting restoration from storage');
    const restored = await restoreAuthenticationFromStorage();
    if (!restored) {
      console.log('GrandJury Extension: No auth token available after restoration attempt');
      isAuthenticated = false;
      return false;
    }
    console.log('GrandJury Extension: Auth token restored from storage');
  }

  try {
    const apiUrl = await getApiUrl();
    console.log('GrandJury Extension: Validating auth with API:', apiUrl);
    
    // Use the extension-specific auth validation endpoint
    const response = await fetch(`${apiUrl}/api/v1/extension/auth/validate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        token: authToken,
        extension_version: "1.0.0"
      })
    });

    if (response.ok) {
      const result = await response.json();
      if (result.valid) {
        isAuthenticated = true;
        console.log('GrandJury Extension: Authentication validated successfully');
        // Extend session
        await storeAuthToken(authToken);
        return true;
      } else {
        // API says token invalid, but we still have a stored token
        // Don't clear auth - let user continue with stored token
        // The token might be valid for Supabase even if our API rejects it
        console.log('GrandJury Extension: API validation returned invalid, but keeping stored token');
        console.log('GrandJury Extension: Token still present:', !!authToken);
        // Still mark as authenticated if we have a token - API might be having issues
        isAuthenticated = !!authToken;
        return isAuthenticated;
      }
    } else {
      // API request failed (network error, server down, etc)
      // Don't clear auth - let user continue with stored token
      console.log('GrandJury Extension: Auth validation request failed:', response.status, response.statusText);
      console.log('GrandJury Extension: Keeping stored token despite API failure');
      // Still mark as authenticated if we have a token
      isAuthenticated = !!authToken;
      return isAuthenticated;
    }
  } catch (error) {
    // Network error or other failure
    // Don't clear auth - let user continue with stored token
    console.error('GrandJury Extension: Auth check failed:', error);
    console.log('GrandJury Extension: Keeping stored token despite error');
    isAuthenticated = !!authToken;
    return isAuthenticated;
  }
}

/**
 * Store authentication token with Chrome-resistant strategy
 */
async function storeAuthToken(token) {
  try {
    const sessionExpiry = Date.now() + SESSION_TIMEOUT;
    const expiryDate = new Date(sessionExpiry);
    
    // Create comprehensive auth data package
    const authData = {
      authToken: token,
      sessionExpiry: sessionExpiry,
      lastActivity: Date.now(),
      storeTimestamp: Date.now(),
      chromeResistant: true
    };
    
    // Step 1: Store in Chrome storage (both types)
    await Promise.all([
      chrome.storage.local.set(authData),
      chrome.storage.session.set(authData)
    ]);
    
    // Step 2: Keep backup in memory to survive Chrome storage clearing
    sessionBackupData = { ...authData };
    
    // Step 3: Update global state
    authToken = token;
    isAuthenticated = true;
    
    // Step 4: Request web pages to backup auth in sessionStorage
    await requestWebPageAuthBackup(token, sessionExpiry);
    
    const authEvent = {
      type: 'AUTH_STORED',
      timestamp: new Date().toISOString(),
      sessionExpiry: expiryDate.toISOString(),
      timeoutMinutes: SESSION_TIMEOUT / 1000 / 60,
      storageMethod: 'chrome_resistant',
      chromeResistant: true
    };
    
    console.log('GrandJury Extension: Authentication token stored with Chrome-resistant strategy. Expires at:', expiryDate.toISOString());
    console.log('GrandJury Extension: Session timeout configured for:', SESSION_TIMEOUT / 1000 / 60, 'minutes');
    
    await logPersistentEvent(authEvent);
  } catch (error) {
    console.error('GrandJury Extension: Error storing auth token:', error);
  }
}

/**
 * Request web pages to backup authentication in their sessionStorage
 */
async function requestWebPageAuthBackup(token, sessionExpiry) {
  try {
    // Find GrandJury tabs to backup auth data
    const tabs = await chrome.tabs.query({
      url: ['*://grandjury.xyz/*', '*://*.grandjury.xyz/*', '*://humanjudge.com/*', '*://*.humanjudge.com/*', '*://grandjury-server.onrender.com/*', '*://localhost:*/*']
    });
    
    const backupData = {
      authToken: token,
      sessionExpiry: sessionExpiry,
      backupTimestamp: Date.now()
    };
    
    // Send backup request to all GrandJury tabs
    for (const tab of tabs) {
      try {
        await chrome.tabs.sendMessage(tab.id, {
          action: 'BACKUP_AUTH_TO_WEBSTORAGE',
          authData: backupData
        });
        console.log('GrandJury Extension: Requested auth backup on tab:', tab.url);
      } catch (error) {
        // Content script might not be ready, that's okay
        console.log('GrandJury Extension: Could not request backup on tab:', tab.url);
      }
    }
  } catch (error) {
    console.log('GrandJury Extension: Error requesting web page auth backup:', error.message);
  }
}

/**
 * Clear authentication data from all sources
 */
async function clearAuth() {
  try {
    // Log the stack trace to see what's calling clearAuth
    const clearAuthEvent = {
      type: 'AUTH_CLEARED',
      timestamp: new Date().toISOString(),
      stack: new Error().stack,
      reason: 'clearAuth() called',
      chromeResistant: true
    };
    
    console.log('GrandJury Extension: clearAuth() called from:', clearAuthEvent.stack);
    console.log('GrandJury Extension: Current time:', clearAuthEvent.timestamp);
    
    // Store persistent log entry
    await logPersistentEvent(clearAuthEvent);
    
    // Use comprehensive clearing function
    await clearAllStoredAuth();
    
    // Clear evaluation session
    evaluationSession = null;
    
    console.log('GrandJury Extension: Authentication cleared from all sources');
    
    // Update badge to show signed out state
    await updateBadge('');
  } catch (error) {
    console.error('GrandJury Extension: Error clearing auth:', error);
  }
}

/**
 * Get appropriate API URL (development vs production)
 */
async function getApiUrl() {
  try {
    // Check if local development server is available
    const localResponse = await fetch(`${LOCAL_API_URL}/health`, {
      method: 'GET',
      signal: AbortSignal.timeout(2000) // 2 second timeout
    });
    
    if (localResponse.ok) {
      console.log('GrandJury Extension: Using local development API');
      return LOCAL_API_URL;
    }
  } catch (error) {
    // Local server not available, use production
  }
  
  console.log('GrandJury Extension: Using production API');
  return API_BASE_URL;
}

/**
 * Fetch evaluation configurations from API
 */
async function fetchConfigurations() {
  // Try to restore auth from storage if not authenticated (service worker may have restarted)
  if (!isAuthenticated || !authToken) {
    console.log('GrandJury Extension: fetchConfigurations - not authenticated, attempting restore');
    await restoreAuthenticationFromStorage();
    if (!isAuthenticated || !authToken) {
      throw new Error('Not authenticated');
    }
  }

  // Check cache first
  const now = Date.now();
  if (configCache && configCacheTimestamp && (now - configCacheTimestamp) < CONFIG_CACHE_DURATION) {
    console.log('GrandJury Extension: Using cached configurations');
    return configCache;
  }

  try {
    const apiUrl = await getApiUrl();
    const response = await fetch(`${apiUrl}/api/v1/extension/configurations`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      if (response.status === 401) {
        const authFailEvent = {
          type: 'API_401_RESPONSE',
          timestamp: new Date().toISOString(),
          url: response.url,
          status: response.status,
          statusText: response.statusText,
          headers: Object.fromEntries(response.headers.entries())
        };
        
        console.log('GrandJury Extension: 401 response from API endpoint:', response.url, response.status, response.statusText);
        console.log('GrandJury Extension: Response headers:', Object.fromEntries(response.headers.entries()));
        
        await logPersistentEvent(authFailEvent);
        await clearAuth();
        throw new Error('Authentication expired');
      }
      throw new Error(`API request failed: ${response.status}`);
    }

    const configurations = await response.json();
    
    // Cache the result
    configCache = configurations;
    configCacheTimestamp = now;
    
    console.log('GrandJury Extension: Fetched configurations from API');
    return configurations;
  } catch (error) {
    console.error('GrandJury Extension: Error fetching configurations:', error);
    throw error;
  }
}

/**
 * Fetch evaluation opportunities (public evaluations user can participate in)
 * @param {boolean} testMode - Whether to include test mode evaluations
 * @param {string|null} filterUrl - Optional URL to filter opportunities by
 */
async function fetchOpportunities(testMode = false, filterUrl = null) {
  console.log('📡 [SERVICE WORKER] fetchOpportunities called:', {
    testMode,
    filterUrl: filterUrl || '(none - will return all projects)'
  });

  // Try to restore auth from storage if not authenticated (service worker may have restarted)
  if (!isAuthenticated || !authToken) {
    console.log('GrandJury Extension: fetchOpportunities - not authenticated, attempting restore');
    await restoreAuthenticationFromStorage();
    if (!isAuthenticated || !authToken) {
      throw new Error('Not authenticated');
    }
  }

  try {
    const apiUrl = await getApiUrl();
    // Build URL with query params
    const params = new URLSearchParams();
    if (testMode) params.append('test_mode', 'true');
    if (filterUrl) params.append('url', filterUrl);
    const queryString = params.toString();
    const url = `${apiUrl}/api/v1/extension/opportunities${queryString ? '?' + queryString : ''}`;
    console.log('📡 [SERVICE WORKER] Fetching from:', url);
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      if (response.status === 401) {
        const authFailEvent = {
          type: 'API_401_RESPONSE',
          timestamp: new Date().toISOString(),
          url: response.url,
          status: response.status,
          statusText: response.statusText,
          headers: Object.fromEntries(response.headers.entries())
        };
        
        console.log('GrandJury Extension: 401 response from API endpoint:', response.url, response.status, response.statusText);
        console.log('GrandJury Extension: Response headers:', Object.fromEntries(response.headers.entries()));
        
        await logPersistentEvent(authFailEvent);
        await clearAuth();
        throw new Error('Authentication expired');
      }
      throw new Error(`API request failed: ${response.status}`);
    }

    const result = await response.json();
    console.log('📡 [SERVICE WORKER] API Response:', {
      totalCount: result.total_count,
      opportunitiesReturned: result.opportunities?.length || 0,
      filterWasApplied: !!filterUrl
    });
    return result;
  } catch (error) {
    console.error('GrandJury Extension: Error fetching opportunities:', error);
    throw error;
  }
}

/**
 * Check if current URL matches any configured apps or evaluation opportunities
 */
async function checkUrlMatch(url) {
  try {
    // Check owner configurations first (owned evaluations)
    const configurations = await fetchConfigurations();
    
    for (const config of configurations) {
      const primaryUrl = config.app_detection?.primary_url;
      if (primaryUrl && url.includes(primaryUrl)) {
        console.log('GrandJury Extension: Owner configuration match found:', primaryUrl);
        return {
          matched: true,
          configuration: config,
          matchType: 'owner'
        };
      }
    }
    
    // Check evaluation opportunities (public evaluations to participate in)
    const opportunities = await fetchOpportunities();
    
    for (const opportunity of opportunities.opportunities) {
      const primaryUrl = opportunity.app_detection?.primary_url;
      if (primaryUrl && url.includes(primaryUrl)) {
        console.log('GrandJury Extension: Evaluator opportunity match found:', primaryUrl);
        return {
          matched: true,
          configuration: opportunity,
          matchType: 'evaluator',
          opportunity: opportunity,
          userStats: opportunities.user_stats
        };
      }
    }
    
    return { matched: false };
  } catch (error) {
    console.error('GrandJury Extension: Error checking URL match:', error);
    return { matched: false, error: error.message };
  }
}

/**
 * Update extension badge
 */
async function updateBadge(text, color = '#4CAF50') {
  try {
    await chrome.action.setBadgeText({ text });
    await chrome.action.setBadgeBackgroundColor({ color });
  } catch (error) {
    console.error('GrandJury Extension: Error updating badge:', error);
  }
}

/**
 * Start evaluation session
 */
async function startEvaluationSession(configuration) {
  try {
    evaluationSession = {
      configuration,
      startTime: Date.now(),
      sessionId: `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
    
    // Store session in local storage
    await chrome.storage.local.set({
      evaluationSession: evaluationSession
    });
    
    console.log('GrandJury Extension: Evaluation session started:', evaluationSession.sessionId);
    await updateBadge('ON', '#2196F3');
    
    return evaluationSession;
  } catch (error) {
    console.error('GrandJury Extension: Error starting evaluation session:', error);
    throw error;
  }
}

/**
 * Stop evaluation session
 */
async function stopEvaluationSession() {
  try {
    if (evaluationSession) {
      const duration = Date.now() - evaluationSession.startTime;
      console.log('GrandJury Extension: Evaluation session stopped. Duration:', duration, 'ms');
      
      evaluationSession = null;
      await chrome.storage.local.remove(['evaluationSession']);
      await updateBadge('');
    }
  } catch (error) {
    console.error('GrandJury Extension: Error stopping evaluation session:', error);
  }
}

/**
 * Handle tab updates for app detection
 */
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  // Only process when page is completely loaded
  if (changeInfo.status === 'complete' && tab.url && isAuthenticated) {
    try {
      const matchResult = await checkUrlMatch(tab.url);
      
      if (matchResult.matched) {
        console.log('GrandJury Extension: App detected on tab:', tabId);
        await updateBadge(' ', '#FF3B30'); // Red badge (iOS-style notification dot)
        
        // Send message to content script
        try {
          await chrome.tabs.sendMessage(tabId, {
            action: 'APP_DETECTED',
            configuration: matchResult.configuration
          });
        } catch (error) {
          // Content script might not be ready yet, that's okay
          console.log('GrandJury Extension: Content script not ready for message');
        }
      } else {
        await updateBadge('');
      }
    } catch (error) {
      console.error('GrandJury Extension: Error processing tab update:', error);
    }
  }
});

/**
 * Handle messages from popup and content scripts
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('GrandJury Extension: Received message:', message.action);
  
  // Handle async responses
  (async () => {
    try {
      switch (message.action) {
        case 'GET_AUTH_STATUS':
          const authStatus = await checkAuthStatus();
          sendResponse({ 
            authenticated: authStatus,
            token: authToken 
          });
          break;

        case 'CLEAR_AUTH':
          await clearAuth();
          sendResponse({ success: true });
          break;
          
        case 'CHECK_URL_MATCH':
          const matchResult = await checkUrlMatch(message.url);
          sendResponse(matchResult);
          break;
          
        case 'GET_CONFIGURATIONS':
          const configurations = await fetchConfigurations();
          sendResponse({ configurations });
          break;
          
        case 'GET_OPPORTUNITIES':
          const opportunities = await fetchOpportunities(message.testMode, message.filterUrl);
          sendResponse(opportunities);
          break;
          
        case 'START_EVALUATION':
          const session = await startEvaluationSession(message.configuration);
          sendResponse({ session });
          break;
          
        case 'STOP_EVALUATION':
          await stopEvaluationSession();
          sendResponse({ success: true });
          break;
          
        case 'GET_EVALUATION_SESSION':
          sendResponse({ session: evaluationSession });
          break;

        case 'STORE_PREVIOUS_TAB':
          // Store the previous tab ID for restoring after auth
          pendingAuthPreviousTabId = message.previousTabId;
          console.log('GrandJury Extension: Stored previous tab ID:', pendingAuthPreviousTabId);
          sendResponse({ success: true });
          break;

        case 'STORE_AUTH_TAB':
          // Store the auth tab ID for closing later
          pendingAuthTabId = message.authTabId;
          console.log('GrandJury Extension: Stored auth tab ID:', pendingAuthTabId);
          sendResponse({ success: true });
          break;

        case 'SET_AUTH_TOKEN':
          // Handle authentication token from content script with tab restoration
          if (message.token) {
            console.log('GrandJury Extension: Received auth token from content script');
            await storeAuthToken(message.token);

            // Don't validate immediately - let the token be validated when needed
            // Immediate validation was causing tokens to be cleared if API was slow/unreachable
            // The token will be validated on next GET_AUTH_STATUS or API call
            console.log('GrandJury Extension: Token stored successfully, skipping immediate validation');

            // Notify the popup that auth is complete (so it can refresh UI)
            console.log('GrandJury Extension: Sending AUTH_COMPLETED message to popup');
            try {
              await chrome.runtime.sendMessage({
                action: 'AUTH_COMPLETED',
                token: message.token
              });
              console.log('GrandJury Extension: ✅ AUTH_COMPLETED message sent successfully');
            } catch (err) {
              console.log('GrandJury Extension: Could not notify popup (may be closed):', err);
            }

            // Use stored tab IDs (from STORE_PREVIOUS_TAB and STORE_AUTH_TAB)
            // IMPORTANT: Only use stored IDs - never use sender.tab.id to avoid closing user's manual tabs
            const authTabId = message.authTabId || pendingAuthTabId;
            const previousTabId = message.previousTabId || pendingAuthPreviousTabId;

            console.log('GrandJury Extension: Auth flow tab IDs:', {
              authTabId,
              previousTabId,
              fromMessage: { authTabId: message.authTabId, previousTabId: message.previousTabId },
              fromStorage: { authTabId: pendingAuthTabId, previousTabId: pendingAuthPreviousTabId }
            });

            // Auto-close the auth tab ONLY if extension opened it (authTabId was stored)
            if (authTabId) {
              console.log('GrandJury Extension: Scheduling auth tab auto-close in 2 seconds');
              setTimeout(async () => {
                try {
                  // Close the auth tab
                  await chrome.tabs.remove(authTabId);
                  console.log('GrandJury Extension: ✅ Auth tab closed successfully');

                  // Return focus to previous tab (AI demo app)
                  if (previousTabId) {
                    try {
                      await chrome.tabs.update(previousTabId, { active: true });
                      console.log('GrandJury Extension: ✅ Returned focus to previous tab:', previousTabId);
                    } catch (error) {
                      console.log('GrandJury Extension: Could not restore previous tab (may be closed):', error.message);
                    }
                  }

                  // Clear the stored tab IDs
                  pendingAuthPreviousTabId = null;
                  pendingAuthTabId = null;
                } catch (error) {
                  console.log('GrandJury Extension: Could not close auth tab (may already be closed):', error.message);
                }
              }, 2000);
            }

            sendResponse({ success: true });
          } else {
            sendResponse({ success: false, error: 'No token provided' });
          }
          break;

        case 'AUTH_COMPLETED':
          // Handle authentication completion from web app (legacy path)
          if (message.token) {
            console.log('GrandJury Extension: Received auth token from web app (legacy)');
            await storeAuthToken(message.token);

            // Validate the token immediately
            const isValid = await checkAuthStatus();

            sendResponse({ success: isValid });
          } else {
            sendResponse({ success: false, error: 'No token provided' });
          }
          break;
          
        case 'GET_DEBUG_LOGS':
          const logs = await getPersistentLogs();
          sendResponse({ logs });
          break;
          
        case 'CLEAR_DEBUG_LOGS':
          await clearPersistentLogs();
          sendResponse({ success: true });
          break;

        // New handlers for trace-based evaluation system
        case 'GET_TRACE':
          const traceResult = await fetchTrace(message.inference_id, message.project_id);
          sendResponse(traceResult);
          break;

        case 'GET_PENDING_EVALUATIONS':
          const pendingEvaluations = await fetchPendingEvaluations(message.session_id);
          sendResponse(pendingEvaluations);
          break;

        case 'SUBMIT_HUMAN_EVALUATION':
          const submissionResult = await submitHumanEvaluation(message.data);
          sendResponse(submissionResult);
          break;

        case 'GET_USER_STATS':
          const userStats = await fetchUserStats();
          sendResponse(userStats);
          break;

        case 'CHECK_REWARD_INFO':
          const rewardInfo = await checkRewardInfo(message.data.evaluation_id);
          sendResponse(rewardInfo);
          break;

        case 'API_REQUEST':
          // Generic API request handler for authenticated requests
          const apiResult = await makeAuthenticatedApiRequest(message.endpoint, message.method || 'GET', message.body);
          sendResponse(apiResult);
          break;

        // PBI-014: Others' Inferences handlers
        case 'FETCH_OTHERS_INFERENCE':
          const othersInferenceResult = await fetchOthersInference(message.data.project_id);
          sendResponse(othersInferenceResult);
          break;

        case 'FETCH_OTHERS_INFERENCE_STATS':
          const othersStatsResult = await fetchOthersInferenceStats(message.data.project_id);
          sendResponse(othersStatsResult);
          break;

        default:
          sendResponse({ error: 'Unknown action' });
      }
    } catch (error) {
      console.error('GrandJury Extension: Error handling message:', error);
      sendResponse({ error: error.message });
    }
  })();
  
  // Return true to indicate async response
  return true;
});

/**
 * Handle extension icon click
 */
chrome.action.onClicked.addListener(async (tab) => {
  // This is handled by the popup, but we can add fallback behavior here
  console.log('GrandJury Extension: Action clicked for tab:', tab.id);
});

/**
 * Log events to persistent storage for debugging
 */
async function logPersistentEvent(event) {
  try {
    const result = await chrome.storage.local.get(['debugLogs']);
    const logs = result.debugLogs || [];
    
    // Keep only last 50 log entries to prevent storage overflow
    const updatedLogs = [...logs, event].slice(-50);
    
    await chrome.storage.local.set({ debugLogs: updatedLogs });
  } catch (error) {
    console.error('Failed to store persistent log:', error);
  }
}

/**
 * Get persistent debug logs
 */
async function getPersistentLogs() {
  try {
    const result = await chrome.storage.local.get(['debugLogs']);
    return result.debugLogs || [];
  } catch (error) {
    console.error('Failed to retrieve persistent logs:', error);
    return [];
  }
}

/**
 * Clear persistent debug logs
 */
async function clearPersistentLogs() {
  try {
    await chrome.storage.local.remove(['debugLogs']);
    console.log('GrandJury Extension: Persistent logs cleared');
  } catch (error) {
    console.error('Failed to clear persistent logs:', error);
  }
}

// ==================== NEW EVALUATION API FUNCTIONS ====================

/**
 * Fetch pending evaluations for a session from the API
 */
async function fetchPendingEvaluations(sessionId) {
  try {
    console.log('GrandJury Extension: Fetching pending evaluations for session:', sessionId);
    
    await logPersistentEvent({
      timestamp: new Date().toISOString(),
      type: 'fetch_pending_evaluations',
      sessionId: sessionId,
      authToken: authToken ? 'present' : 'missing'
    });
    
    if (!authToken) {
      return { success: false, error: 'Authentication required' };
    }
    
    const url = `${API_BASE_URL}/api/v1/evaluations/pending?session_id=${encodeURIComponent(sessionId)}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      if (response.status === 401) {
        // Clear invalid auth token
        await clearAuth();
        return { success: false, error: 'Authentication expired. Please sign in again.' };
      }
      throw new Error(`API request failed: ${response.status}`);
    }
    
    const data = await response.json();
    
    await logPersistentEvent({
      timestamp: new Date().toISOString(),
      type: 'fetch_pending_evaluations_success',
      sessionId: sessionId,
      count: data.length
    });
    
    return { success: true, data: data };
    
  } catch (error) {
    console.error('GrandJury Extension: Error fetching pending evaluations:', error);
    
    await logPersistentEvent({
      timestamp: new Date().toISOString(),
      type: 'fetch_pending_evaluations_error',
      sessionId: sessionId,
      error: error.message
    });
    
    return { success: false, error: error.message };
  }
}

/**
 * Submit a human evaluation vote to the API
 */
async function submitHumanEvaluation(evaluationData) {
  try {
    console.log('GrandJury Extension: Submitting human evaluation:', evaluationData.langfuse_trace_id);
    
    await logPersistentEvent({
      timestamp: new Date().toISOString(),
      type: 'submit_human_evaluation',
      traceId: evaluationData.langfuse_trace_id,
      vote: evaluationData.vote,
      authToken: authToken ? 'present' : 'missing'
    });
    
    if (!authToken) {
      return { success: false, error: 'Authentication required' };
    }
    
    const url = `${API_BASE_URL}/api/v1/evaluations/submit`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(evaluationData)
    });
    
    if (!response.ok) {
      if (response.status === 401) {
        // Clear invalid auth token
        await clearAuth();
        return { success: false, error: 'Authentication expired. Please sign in again.' };
      }
      
      const errorText = await response.text();
      throw new Error(`API request failed: ${response.status} - ${errorText}`);
    }
    
    const data = await response.json();
    
    await logPersistentEvent({
      timestamp: new Date().toISOString(),
      type: 'submit_human_evaluation_success',
      traceId: evaluationData.langfuse_trace_id,
      vote: evaluationData.vote,
      creditsEarned: data.credits_earned
    });
    
    return { success: true, data: data };
    
  } catch (error) {
    console.error('GrandJury Extension: Error submitting human evaluation:', error);
    
    await logPersistentEvent({
      timestamp: new Date().toISOString(),
      type: 'submit_human_evaluation_error',
      traceId: evaluationData.langfuse_trace_id,
      error: error.message
    });
    
    return { success: false, error: error.message };
  }
}

// ==================== PBI-014: OTHERS' INFERENCES API FUNCTIONS ====================

/**
 * Fetch a random inference from another user for cross-evaluation
 * @param {string} projectId - The evaluation project ID
 */
async function fetchOthersInference(projectId) {
  try {
    console.log(`GrandJury Extension: Fetching others inference for project: ${projectId}`);

    if (!authToken) {
      return { success: false, error: 'Authentication required' };
    }

    const url = `${API_BASE_URL}/api/v1/extension/others-inferences?project_id=${encodeURIComponent(projectId)}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      if (response.status === 401) {
        await clearAuth();
        return { success: false, error: 'Authentication expired. Please sign in again.' };
      }
      if (response.status === 404) {
        return { success: true, data: { found: false, message: 'No inferences available from others' } };
      }
      throw new Error(`API request failed: ${response.status}`);
    }

    const data = await response.json();

    console.log(`GrandJury Extension: Others inference response:`, data);

    return { success: true, data: data };

  } catch (error) {
    console.error('GrandJury Extension: Error fetching others inference:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Fetch stats about available inferences from others
 * @param {string} projectId - The evaluation project ID
 */
async function fetchOthersInferenceStats(projectId) {
  try {
    console.log(`GrandJury Extension: Fetching others inference stats for project: ${projectId}`);

    if (!authToken) {
      return { success: false, error: 'Authentication required' };
    }

    const url = `${API_BASE_URL}/api/v1/extension/others-inferences/stats?project_id=${encodeURIComponent(projectId)}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      if (response.status === 401) {
        await clearAuth();
        return { success: false, error: 'Authentication expired. Please sign in again.' };
      }
      throw new Error(`API request failed: ${response.status}`);
    }

    const data = await response.json();

    return { success: true, data: data };

  } catch (error) {
    console.error('GrandJury Extension: Error fetching others inference stats:', error);
    return { success: false, error: error.message };
  }
}

// ==================== END PBI-014 FUNCTIONS ====================

/**
 * Fetch a single trace by inference ID from the backend
 */
async function fetchTrace(inferenceId, projectId) {
  try {
    console.log(`GrandJury Extension: Fetching trace for inference: ${inferenceId}, project: ${projectId}`);

    await logPersistentEvent({
      timestamp: new Date().toISOString(),
      type: 'fetch_trace',
      inferenceId: inferenceId,
      projectId: projectId,
      authToken: authToken ? 'present' : 'missing'
    });

    if (!authToken) {
      return { success: false, error: 'Authentication required' };
    }

    const url = `${API_BASE_URL}/api/v1/extension/traces/${encodeURIComponent(inferenceId)}?project_id=${encodeURIComponent(projectId)}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      if (response.status === 401) {
        await clearAuth();
        return { success: false, error: 'Authentication expired. Please sign in again.' };
      }
      if (response.status === 404) {
        return { success: false, error: 'Trace not found' };
      }
      throw new Error(`API request failed: ${response.status}`);
    }

    const data = await response.json();

    await logPersistentEvent({
      timestamp: new Date().toISOString(),
      type: 'fetch_trace_success',
      inferenceId: inferenceId,
      traceId: data.trace_id
    });

    return { success: true, data: data };

  } catch (error) {
    console.error('GrandJury Extension: Error fetching trace:', error);

    await logPersistentEvent({
      timestamp: new Date().toISOString(),
      type: 'fetch_trace_error',
      inferenceId: inferenceId,
      error: error.message
    });

    return { success: false, error: error.message };
  }
}

/**
 * Fetch user statistics from the API
 */
async function fetchUserStats() {
  try {
    console.log('GrandJury Extension: Fetching user stats');

    if (!authToken) {
      return { success: false, error: 'Authentication required' };
    }

    // Use the existing opportunities endpoint which returns user stats
    // Add cache-busting timestamp to force fresh data
    const url = `${API_BASE_URL}/api/v1/extension/opportunities?_t=${Date.now()}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache'
      },
      cache: 'no-store'
    });
    
    if (!response.ok) {
      if (response.status === 401) {
        await clearAuth();
        return { success: false, error: 'Authentication expired' };
      }
      throw new Error(`API request failed: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Extract user stats from the response
    const stats = {
      total_evaluations: data.user_stats?.total_evaluations || 0,
      credits_earned: data.user_stats?.credits_earned || 0,
      session_count: 1 // Simple placeholder
    };
    
    return { success: true, data: stats };
    
  } catch (error) {
    console.error('GrandJury Extension: Error fetching user stats:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Make an authenticated API request to the backend
 * Generic handler for popup to make API calls
 */
async function makeAuthenticatedApiRequest(endpoint, method = 'GET', body = null) {
  try {
    console.log(`GrandJury Extension: API Request - ${method} ${endpoint}`);

    if (!authToken) {
      return { error: 'Authentication required' };
    }

    const url = `${API_BASE_URL}${endpoint}`;
    const options = {
      method: method,
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    };

    if (body && method !== 'GET') {
      options.body = JSON.stringify(body);
    }

    const response = await fetch(url, options);

    if (!response.ok) {
      if (response.status === 401) {
        await clearAuth();
        return { error: 'Authentication expired' };
      }
      throw new Error(`API request failed: ${response.status}`);
    }

    const data = await response.json();
    console.log(`GrandJury Extension: API Response for ${endpoint}:`, data);
    return data;

  } catch (error) {
    console.error(`GrandJury Extension: API request error for ${endpoint}:`, error);
    return { error: error.message };
  }
}

/**
 * Check reward information for an evaluation before voting (PBI-007 GAP 4)
 * Returns effective reward, volunteer mode status, and creator balance
 */
async function checkRewardInfo(evaluationId) {
  try {
    console.log(`GrandJury Extension: Checking reward info for evaluation ${evaluationId}`);

    if (!authToken) {
      return { success: false, error: 'Authentication required' };
    }

    // Call the new reward info endpoint
    const url = `${API_BASE_URL}/api/v1/voting/evaluation/${evaluationId}/reward-info`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      if (response.status === 401) {
        await clearAuth();
        return { success: false, error: 'Authentication expired' };
      }
      throw new Error(`API request failed: ${response.status}`);
    }

    const rewardData = await response.json();

    console.log('GrandJury Extension: Reward info received:', rewardData);

    return {
      success: true,
      data: {
        evaluation_id: rewardData.evaluation_id,
        configured_reward: rewardData.configured_reward,
        effective_reward: rewardData.effective_reward,
        is_volunteer_mode: rewardData.is_volunteer_mode,
        creator_balance: rewardData.creator_balance
      }
    };

  } catch (error) {
    console.error('GrandJury Extension: Error checking reward info:', error);
    return { success: false, error: error.message };
  }
}

console.log('GrandJury Extension: Service worker loaded');