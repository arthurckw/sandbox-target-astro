/**
 * GrandJury Chrome Extension Popup Script
 * Handles authentication, app detection, and evaluation session management
 */

// DOM elements
let elements = {};

// Application state
let currentUser = null;
let currentTab = null;
let evaluationSession = null;
let appConfiguration = null;
let sessionTimer = null;

// PBI-014: Others' Inferences state
let currentInferenceMode = 'your'; // 'your' or 'others'
let currentOthersInference = null; // Current inference from another user
let othersInferenceStats = null; // Stats about available inferences

// ============================================================================
// C8: JSON Tree Renderer for Enterprise Agentic Workflows
// ============================================================================

/**
 * Check if a string is valid JSON
 * @param {string} str - The string to check
 * @returns {boolean} - True if valid JSON
 */
function isJSONString(str) {
  if (typeof str !== 'string') return false;
  const trimmed = str.trim();
  // Quick check: must start with { or [
  if (!trimmed.startsWith('{') && !trimmed.startsWith('[')) return false;
  try {
    JSON.parse(trimmed);
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Render a JSON tree recursively
 * @param {any} data - The parsed JSON data
 * @param {number} depth - Current depth level (for auto-collapse)
 * @param {string} key - Optional key name for this value
 * @returns {string} - HTML string for the tree
 */
function renderJSONTree(data, depth = 0, key = null) {
  const AUTO_COLLAPSE_DEPTH = 2; // Collapse items deeper than this
  const isCollapsed = depth >= AUTO_COLLAPSE_DEPTH;
  const toggleClass = isCollapsed ? 'collapsed' : '';

  // Escape HTML to prevent XSS
  const escapeHtml = (str) => {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  };

  // Truncate long strings for preview
  const truncate = (str, maxLen = 50) => {
    if (str.length <= maxLen) return str;
    return str.substring(0, maxLen) + '...';
  };

  // Key prefix if provided
  const keyHtml = key !== null
    ? `<span class="json-key">"${escapeHtml(String(key))}"</span><span class="json-colon">:</span>`
    : '';

  // Handle different types
  if (data === null) {
    return `<div class="json-item">${keyHtml}<span class="json-value null">null</span></div>`;
  }

  if (typeof data === 'boolean') {
    return `<div class="json-item">${keyHtml}<span class="json-value boolean">${data}</span></div>`;
  }

  if (typeof data === 'number') {
    return `<div class="json-item">${keyHtml}<span class="json-value number">${data}</span></div>`;
  }

  if (typeof data === 'string') {
    // Check if the string itself is JSON (nested stringified JSON)
    if (isJSONString(data)) {
      try {
        const nested = JSON.parse(data);
        return renderJSONTree(nested, depth, key);
      } catch (e) {
        // Fall through to regular string rendering
      }
    }
    return `<div class="json-item">${keyHtml}<span class="json-value string">"${escapeHtml(data)}"</span></div>`;
  }

  if (Array.isArray(data)) {
    if (data.length === 0) {
      return `<div class="json-item">${keyHtml}<span class="json-bracket">[]</span></div>`;
    }

    const preview = `${data.length} item${data.length !== 1 ? 's' : ''}`;
    const childrenHtml = data.map((item, idx) => renderJSONTree(item, depth + 1, idx)).join('');

    return `<div class="json-item ${depth === 0 ? 'json-root' : ''}"><span class="json-toggle ${toggleClass}">▼</span>${keyHtml}<span class="json-bracket">[</span><span class="json-preview ${toggleClass ? '' : 'hidden'}">${preview}</span><div class="json-children ${toggleClass}">${childrenHtml}</div><span class="json-bracket">]</span></div>`;
  }

  if (typeof data === 'object') {
    const keys = Object.keys(data);
    if (keys.length === 0) {
      return `<div class="json-item">${keyHtml}<span class="json-bracket">{}</span></div>`;
    }

    const preview = `${keys.length} key${keys.length !== 1 ? 's' : ''}`;
    const childrenHtml = keys.map(k => renderJSONTree(data[k], depth + 1, k)).join('');

    return `<div class="json-item ${depth === 0 ? 'json-root' : ''}"><span class="json-toggle ${toggleClass}">▼</span>${keyHtml}<span class="json-bracket">{</span><span class="json-preview ${toggleClass ? '' : 'hidden'}">${preview}</span><div class="json-children ${toggleClass}">${childrenHtml}</div><span class="json-bracket">}</span></div>`;
  }

  // Fallback for unknown types
  return `<div class="json-item">${keyHtml}<span class="json-value">${escapeHtml(String(data))}</span></div>`;
}

/**
 * Render content smartly - JSON tree for JSON strings, plain text otherwise
 * @param {string} text - The text content (may be stringified JSON)
 * @param {function} escapeHtml - HTML escape function
 * @returns {object} - { html: string, isJSON: boolean }
 */
function renderSmartContent(text, escapeHtml) {
  if (!text) {
    return { html: escapeHtml('No content'), isJSON: false };
  }

  // Try to detect and parse JSON
  if (isJSONString(text)) {
    try {
      const parsed = JSON.parse(text);
      const treeHtml = `<div class="json-tree">${renderJSONTree(parsed)}</div>`;
      return { html: treeHtml, isJSON: true };
    } catch (e) {
      // Fall through to plain text
    }
  }

  // Return as plain escaped text
  return { html: escapeHtml(text), isJSON: false };
}

// ============================================================================

/**
 * Initialize popup when DOM is loaded
 */
document.addEventListener('DOMContentLoaded', async () => {
  console.log('GrandJury Extension: Popup initializing...');
  
  // Cache DOM elements
  cacheElements();
  
  // Set up event listeners
  setupEventListeners();
  
  // Show loading screen
  showScreen('loading-screen');
  
  try {
    // Get current tab information
    await getCurrentTab();
    
    // Initialize appropriate screen (this will check auth status internally)
    await initializeInterface();
    
  } catch (error) {
    console.error('GrandJury Extension: Popup initialization error:', error);
    showError('Failed to initialize extension. Please try again.');
  }
});

/**
 * Cache DOM elements for performance
 */
function cacheElements() {
  console.log('GrandJury Extension: Caching DOM elements...');
  
  // Screens
  elements.loadingScreen = document.getElementById('loading-screen');
  elements.authScreen = document.getElementById('auth-screen');
  elements.projectSelectionScreen = document.getElementById('project-selection-screen');
  elements.projectDetailsScreen = document.getElementById('project-details-screen');
  elements.dashboardScreen = document.getElementById('dashboard-screen');
  elements.errorScreen = document.getElementById('error-screen');
  
  // Auth elements
  elements.signInButton = document.getElementById('sign-in-button');
  elements.createAccountLink = document.getElementById('create-account-link');
  elements.helpLink = document.getElementById('help-link');
  
  console.log('GrandJury Extension: Auth elements cached:', {
    signInButton: elements.signInButton,
    createAccountLink: elements.createAccountLink,
    helpLink: elements.helpLink
  });
  
  // Dashboard elements
  elements.userRole = document.getElementById('user-role');
  elements.userEmail = document.getElementById('user-email');
  elements.signOutButton = document.getElementById('sign-out-button');
  elements.settingsButton = document.getElementById('settings-button');

  // PBI-008: Evaluator status badge elements
  elements.evaluatorStatusBadge = document.getElementById('evaluator-status-badge');
  elements.evaluatorStatusText = document.getElementById('evaluator-status-text');
  elements.evaluatorApplyPrompt = document.getElementById('evaluator-apply-prompt');
  
  // Track AI Output elements
  elements.trackOutputCard = document.getElementById('track-output-card');
  elements.sessionStatus = document.getElementById('session-status');
  elements.trackPrompt = document.getElementById('track-prompt');
  elements.trackAiOutput = document.getElementById('track-ai-output');
  elements.retryTrack = document.getElementById('retry-track');
  elements.loadingTodos = document.getElementById('loading-todos');
  elements.noTodos = document.getElementById('no-todos');
  elements.todoList = document.getElementById('todo-list');
  elements.retrackSection = document.getElementById('retrack-section');
  elements.retrackAiOutput = document.getElementById('retrack-ai-output');
  elements.refreshTodos = document.getElementById('refresh-todos');
  elements.currentSessionId = document.getElementById('current-session-id');
  
  // SDK status elements
  elements.sdkStatus = document.getElementById('sdk-status');
  elements.sdkVersion = document.getElementById('sdk-version');
  
  // Activity stats
  elements.totalEvaluations = document.getElementById('total-evaluations');
  elements.creditsEarned = document.getElementById('credits-earned');
  elements.milestoneCelebration = document.getElementById('milestone-celebration');
  elements.milestoneMessage = document.getElementById('milestone-message');

  // Project selection elements
  elements.projectsList = document.getElementById('projects-list');
  elements.projectsSubtitle = document.getElementById('projects-subtitle');
  elements.backToDashboard = document.getElementById('back-to-dashboard');

  // Project details elements
  elements.detailProjectName = document.getElementById('detail-project-name');
  elements.detailProjectId = document.getElementById('detail-project-id');
  elements.detailReward = document.getElementById('detail-reward');
  elements.detailAppContext = document.getElementById('detail-app-context');
  elements.detailGeneralGuidelines = document.getElementById('detail-general-guidelines');
  elements.detailEvaluationCriteria = document.getElementById('detail-evaluation-criteria');
  elements.acceptTermsCheckbox = document.getElementById('accept-terms-checkbox');
  elements.acceptJoinProject = document.getElementById('accept-join-project');
  elements.backToProjects = document.getElementById('back-to-projects');

  // No projects message element
  elements.noProjectsMessage = document.getElementById('no-projects-message');
  elements.refreshProjects = document.getElementById('refresh-projects');

  // Project context elements (dashboard)
  elements.projectContextCard = document.getElementById('project-context-card');
  elements.currentProjectName = document.getElementById('current-project-name');
  elements.currentProjectId = document.getElementById('current-project-id');
  elements.currentReward = document.getElementById('current-reward');
  elements.currentAppContext = document.getElementById('current-app-context');
  elements.currentGeneralGuidelines = document.getElementById('current-general-guidelines');
  elements.currentEvaluationCriteria = document.getElementById('current-evaluation-criteria');
  elements.changeProject = document.getElementById('change-project');

  // PBI-015: Profile and Report links
  elements.viewProfileLink = document.getElementById('view-profile-link');
  elements.projectActions = document.getElementById('project-actions');
  elements.viewReportLink = document.getElementById('view-report-link');

  // PBI-014: Others' Inferences elements
  elements.inferenceModeToggle = document.getElementById('inference-mode-toggle');
  elements.modeYourInferences = document.getElementById('mode-your-inferences');
  elements.modeOthersInferences = document.getElementById('mode-others-inferences');
  elements.othersCountBadge = document.getElementById('others-count-badge');
  elements.othersInferenceCard = document.getElementById('others-inference-card');
  elements.othersLoading = document.getElementById('others-loading');
  elements.othersEmpty = document.getElementById('others-empty');
  elements.othersEmptyMessage = document.getElementById('others-empty-message');
  elements.othersRefresh = document.getElementById('others-refresh');
  elements.othersInferenceDisplay = document.getElementById('others-inference-display');
  elements.othersInferenceContent = document.getElementById('others-inference-content');
  elements.othersShuffle = document.getElementById('others-shuffle');
  elements.othersEvalCount = document.getElementById('others-eval-count');

  // Error elements
  elements.errorMessage = document.getElementById('error-message');
  elements.retryButton = document.getElementById('retry-button');
  elements.reportErrorButton = document.getElementById('report-error-button');

  // Footer links
  elements.helpCenterLink = document.getElementById('help-center-link');
  elements.privacyLink = document.getElementById('privacy-link');
  elements.termsLink = document.getElementById('terms-link');
}

/**
 * Set up event listeners
 */
function setupEventListeners() {
  // Auth events with debugging
  console.log('GrandJury Extension: Setting up event listeners');
  console.log('GrandJury Extension: signInButton element:', elements.signInButton);
  
  if (elements.signInButton) {
    elements.signInButton.addEventListener('click', handleSignIn);
    console.log('GrandJury Extension: Sign-in button event listener added');
  } else {
    console.error('GrandJury Extension: Sign-in button element not found!');
  }
  
  elements.createAccountLink?.addEventListener('click', handleCreateAccount);
  elements.signOutButton?.addEventListener('click', handleSignOut);
  
  // Track AI Output button events
  elements.trackAiOutput?.addEventListener('click', handleTrackAiOutput);
  elements.retryTrack?.addEventListener('click', handleTrackAiOutput);
  elements.retrackAiOutput?.addEventListener('click', handleTrackAiOutput);
  elements.refreshTodos?.addEventListener('click', handleRefreshTodos);

  // JSON tree toggle event delegation (CSP-safe, no inline onclick)
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('json-toggle')) {
      e.target.classList.toggle('collapsed');
      const children = e.target.parentElement.querySelector('.json-children');
      if (children) {
        children.classList.toggle('collapsed');
      }
    }
  });

  // Project selection/joining events
  elements.backToDashboard?.addEventListener('click', () => showScreen('dashboard-screen'));
  elements.backToProjects?.addEventListener('click', () => showScreen('project-selection-screen'));
  elements.changeProject?.addEventListener('click', handleChangeProject);
  elements.acceptTermsCheckbox?.addEventListener('change', handleTermsCheckboxChange);
  elements.acceptJoinProject?.addEventListener('click', handleAcceptJoinProject);

  // Error events
  elements.retryButton?.addEventListener('click', handleRetry);
  elements.reportErrorButton?.addEventListener('click', handleReportError);

  // Refresh projects button (in no-projects message)
  elements.refreshProjects?.addEventListener('click', async () => {
    console.log('🔄 Refresh projects clicked');
    // Re-fetch current tab URL and reload opportunities
    await getCurrentTab();
    await loadUserData();

    // Fetch and display projects for the new URL
    const projects = await fetchAvailableProjects();
    console.log(`🔄 Refresh found ${projects.length} projects`);

    if (projects.length === 0) {
      // Still no projects - keep showing the message
      console.log('📭 Still no projects on this page');
      elements.projectContextCard?.classList.add('hidden');
      elements.noProjectsMessage?.classList.remove('hidden');
      elements.trackOutputCard?.classList.add('hidden');
    } else if (projects.length === 1) {
      // One project found - show details directly, but populate selection for "Back to Projects"
      console.log('📄 One project found, showing details');
      elements.noProjectsMessage?.classList.add('hidden');
      elements.trackOutputCard?.classList.remove('hidden');
      // Populate the project selection list (for "Back to Projects" button)
      showProjectSelection(projects);
      selectedProjectForDetails = projects[0];
      window.viewProjectDetails(0);
    } else {
      // Multiple projects - show selection screen
      console.log(`📋 ${projects.length} projects found, showing selection`);
      elements.noProjectsMessage?.classList.add('hidden');
      elements.trackOutputCard?.classList.remove('hidden');
      showProjectSelection(projects);
    }
  });

  // Instructions toggle - change text when expanded/collapsed
  const instructionsDetails = document.getElementById('instructions-details');
  const instructionsSummary = document.getElementById('instructions-summary');
  if (instructionsDetails && instructionsSummary) {
    instructionsDetails.addEventListener('toggle', () => {
      if (instructionsDetails.open) {
        instructionsSummary.textContent = '📝 Hide Evaluation Instructions';
      } else {
        instructionsSummary.textContent = '📝 View Evaluation Instructions';
      }
    });
  }

  // Settings and help
  elements.settingsButton?.addEventListener('click', handleSettings);
  elements.helpCenterLink?.addEventListener('click', () => openExternalLink('https://humanjudge.com/help'));
  elements.privacyLink?.addEventListener('click', () => openExternalLink('https://humanjudge.com/privacy'));
  elements.termsLink?.addEventListener('click', () => openExternalLink('https://humanjudge.com/terms'));

  // PBI-014: Others' Inferences event listeners
  elements.modeYourInferences?.addEventListener('click', () => handleModeSwitch('your'));
  elements.modeOthersInferences?.addEventListener('click', () => handleModeSwitch('others'));
  elements.othersShuffle?.addEventListener('click', handleOthersShuffle);
  elements.othersRefresh?.addEventListener('click', () => fetchOthersInference());
  // Note: Pass/Flag buttons are now setup dynamically in setupOthersInferenceEventListeners()
}

/**
 * Get current active tab
 */
async function getCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTab = tab;
    console.log('GrandJury Extension: Current tab:', tab.url);
  } catch (error) {
    console.error('GrandJury Extension: Error getting current tab:', error);
    throw error;
  }
}

/**
 * Check authentication status
 */
async function checkAuthStatus() {
  try {
    console.log('GrandJury Extension Popup: Checking auth status at:', new Date().toISOString());
    const response = await chrome.runtime.sendMessage({ action: 'GET_AUTH_STATUS' });
    
    if (response && response.authenticated) {
      console.log('GrandJury Extension Popup: User is authenticated');
      console.log('GrandJury Extension Popup: Auth token present:', !!response.token);
      return true;
    } else {
      console.log('GrandJury Extension Popup: User is not authenticated');
      console.log('GrandJury Extension Popup: Response:', response);
      return false;
    }
  } catch (error) {
    console.error('GrandJury Extension Popup: Error checking auth status:', error);
    return false;
  }
}

/**
 * Initialize the appropriate interface
 */
async function initializeInterface() {
  console.log('GrandJury Extension: Initializing interface...');

  const isAuthenticated = await checkAuthStatus();
  console.log('GrandJury Extension: Authentication check result:', isAuthenticated);

  if (!isAuthenticated) {
    console.log('GrandJury Extension: User not authenticated, showing auth screen');
    showScreen('auth-screen');
    return;
  }

  console.log('GrandJury Extension: User authenticated');
  await loadUserData();

  // Get current tab URL first - needed for URL matching validation
  let currentTabUrl = null;
  let currentTabHostname = null;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url) {
      currentTabUrl = tab.url;
      try {
        const parsedUrl = new URL(currentTabUrl);
        currentTabHostname = parsedUrl.hostname;
        console.log('📍 [URL VALIDATION] Current tab:', { url: currentTabUrl, hostname: currentTabHostname });
      } catch (e) {
        console.log('📍 [URL VALIDATION] Could not parse tab URL:', currentTabUrl);
      }
    }
  } catch (tabError) {
    console.warn('⚠️ [URL VALIDATION] Error querying tab:', tabError);
  }

  // Check if user has already joined a project
  const joinedProject = await getJoinedProject();

  if (joinedProject) {
    console.log('✅ User has joined project in storage:', joinedProject.grandjury_project_id);

    // URL VALIDATION: Check if current tab URL matches joined project's URL
    let urlMatches = false;
    const projectUrl = joinedProject.app_detection?.primary_url;

    if (projectUrl && currentTabHostname) {
      try {
        const projectHostname = new URL(projectUrl).hostname;
        urlMatches = currentTabHostname === projectHostname;
        console.log('📍 [URL VALIDATION] Comparing URLs:', {
          currentHostname: currentTabHostname,
          projectHostname: projectHostname,
          match: urlMatches
        });
      } catch (e) {
        console.log('⚠️ [URL VALIDATION] Could not parse project URL:', projectUrl);
        // If we can't parse project URL, don't show as match
        urlMatches = false;
      }
    } else if (!projectUrl) {
      console.log('⚠️ [URL VALIDATION] Joined project has no primary_url, cannot validate');
      // If project has no URL, we can't validate - need to refetch
      urlMatches = false;
    } else if (!currentTabHostname) {
      console.log('⚠️ [URL VALIDATION] Cannot get current tab hostname');
      // Special pages like chrome:// etc - don't show project
      urlMatches = false;
    }

    // Only show joined project if URL matches
    if (!urlMatches) {
      console.log('🔄 [URL VALIDATION] URL does not match joined project - clearing and fetching fresh projects');
      // Clear the stored joined project since we're on a different page
      await clearJoinedProject();
      // Fall through to project fetching logic below
    } else {
      // URL matches - show the joined project
      // Fetch fresh project data from API to get latest credit_rates
      const projects = await fetchAvailableProjects();
      const freshProject = projects.find(p => p.grandjury_project_id === joinedProject.grandjury_project_id);

      if (freshProject) {
        console.log('✅ Refreshed project data from API');
        currentProject = freshProject;
        // Update stored project with fresh data
        await saveJoinedProject(freshProject);
      } else {
        // Fallback to cached project if API doesn't return it
        console.log('⚠️ Using cached project data');
        currentProject = joinedProject;
      }

      // Display project context and show dashboard
      displayProjectContext(currentProject);
      await initializeTodoList();
      showScreen('dashboard-screen');
      return; // Exit early - we've shown the dashboard
    }
  }

  // No joined project OR URL didn't match - fetch available projects for current page
  {
    console.log('📋 No joined project, fetching available projects...');

    // Fetch available projects
    const projects = await fetchAvailableProjects();

    if (projects.length === 0) {
      // No projects available for this URL - show dashboard with message
      console.log('⚠️ No projects available on this page');
      showScreen('dashboard-screen');
      elements.projectContextCard.classList.add('hidden');
      // Show the "No projects on this page" message
      if (elements.noProjectsMessage) {
        elements.noProjectsMessage.classList.remove('hidden');
        console.log('📭 Showing "No projects on this page" message');
      }
      // Hide the Track AI Output section when no projects
      if (elements.trackOutputCard) {
        elements.trackOutputCard.classList.add('hidden');
        console.log('🔒 Hiding Track AI Output section (no projects)');
      }
      // PBI-014: Hide mode toggle when no projects
      if (elements.inferenceModeToggle) {
        elements.inferenceModeToggle.classList.add('hidden');
      }
      if (elements.othersInferenceCard) {
        elements.othersInferenceCard.classList.add('hidden');
      }
    } else if (projects.length === 1) {
      // Only one project - show details directly, but also populate selection for "Back to Projects"
      console.log('📄 One project available, showing details');
      // Hide no-projects message since we have a project
      if (elements.noProjectsMessage) {
        elements.noProjectsMessage.classList.add('hidden');
      }
      // Show the Track AI Output section when we have projects
      if (elements.trackOutputCard) {
        elements.trackOutputCard.classList.remove('hidden');
      }
      // Populate the project selection list (for "Back to Projects" button)
      showProjectSelection(projects);
      selectedProjectForDetails = projects[0];
      window.viewProjectDetails(0);
    } else {
      // Multiple projects - show selection screen
      console.log(`📋 ${projects.length} projects available, showing selection`);
      // Hide no-projects message since we have projects
      if (elements.noProjectsMessage) {
        elements.noProjectsMessage.classList.add('hidden');
      }
      // Show the Track AI Output section when we have projects
      if (elements.trackOutputCard) {
        elements.trackOutputCard.classList.remove('hidden');
      }
      showProjectSelection(projects);
    }
  }
}

/**
 * Load user data and stats
 */
async function loadUserData() {
  try {
    // Fetch user profile for email
    const profileResponse = await chrome.runtime.sendMessage({
      action: 'API_REQUEST',
      endpoint: '/api/v1/profile/',
      method: 'GET'
    });

    if (profileResponse && profileResponse.email && elements.userEmail) {
      elements.userEmail.textContent = profileResponse.email;
      console.log('✅ User email loaded:', profileResponse.email);

      // PBI-015: Show "View My Profile" link with user ID
      if (profileResponse.id && elements.viewProfileLink) {
        elements.viewProfileLink.href = `https://humanjudge.com/u/${profileResponse.id}`;
        elements.viewProfileLink.classList.remove('hidden');
        console.log('✅ Profile link set:', elements.viewProfileLink.href);
      }
    } else {
      console.log('⚠️ Email not found in profile response:', profileResponse);
      if (elements.userEmail) {
        elements.userEmail.textContent = 'Not available';
      }
    }

    // Fetch opportunities to get user stats and qualification
    const opportunitiesData = await chrome.runtime.sendMessage({ action: 'GET_OPPORTUNITIES' });

    if (opportunitiesData && opportunitiesData.user_stats) {
      const stats = opportunitiesData.user_stats;

      // Update user stats from API
      if (elements.totalEvaluations) {
        elements.totalEvaluations.textContent = stats.total_evaluations || '0';
      }
      if (elements.creditsEarned) {
        elements.creditsEarned.textContent = stats.credits_earned || '0';
      }
      if (elements.successRate) {
        elements.successRate.textContent = `${(stats.success_rate || 0).toFixed(0)}%`;
      }

      // Show role from qualification
      const qualification = stats.evaluator_qualification || 'Community';
      if (elements.userRole) {
        elements.userRole.textContent = `Evaluator (${qualification.charAt(0).toUpperCase() + qualification.slice(1)})`;
      }
    } else {
      // Fallback values
      if (elements.userRole) {
        elements.userRole.textContent = 'Evaluator (Community)';
      }
      if (elements.totalEvaluations) {
        elements.totalEvaluations.textContent = '0';
      }
      if (elements.creditsEarned) {
        elements.creditsEarned.textContent = '0';
      }
      if (elements.successRate) {
        elements.successRate.textContent = '0%';
      }
    }

    // PBI-008: Fetch and display evaluator status
    await loadEvaluatorStatus();

    console.log('GrandJury Extension: User data loaded');
  } catch (error) {
    console.error('GrandJury Extension: Error loading user data:', error);
    // Fallback values
    if (elements.userRole) {
      elements.userRole.textContent = 'Evaluator';
    }
  }
}

/**
 * PBI-008: Fetch and display evaluator verification status
 */
async function loadEvaluatorStatus() {
  try {
    console.log('🔍 Fetching evaluator status...');

    const response = await chrome.runtime.sendMessage({
      action: 'API_REQUEST',
      endpoint: '/api/v1/evaluator/status',
      method: 'GET'
    });

    if (response && response.evaluator_status) {
      const status = response.evaluator_status;
      const statusMap = {
        'not_applied': '⚪ Not Applied',
        'pending': '🟡 Pending Review',
        'verified': '✅ Verified',
        'rejected': '🔴 Rejected'
      };

      // Update badge (if elements exist)
      if (elements.evaluatorStatusText) {
        elements.evaluatorStatusText.textContent = statusMap[status] || status;
      }
      if (elements.evaluatorStatusBadge) {
        elements.evaluatorStatusBadge.classList.remove('hidden', 'status-not-applied', 'status-pending', 'status-verified', 'status-rejected');
        elements.evaluatorStatusBadge.classList.add(`status-${status.replace('_', '-')}`);
      }

      // Show/hide application prompt
      if (status === 'not_applied') {
        elements.evaluatorApplyPrompt?.classList.remove('hidden');
      } else {
        elements.evaluatorApplyPrompt?.classList.add('hidden');
      }

      console.log(`✅ Evaluator status loaded: ${status}`);

      // Store status globally for access control checks
      window.evaluatorStatus = status;
      window.canCashout = response.can_cashout;
    }
  } catch (error) {
    console.error('❌ Error fetching evaluator status:', error);
    // Don't show badge if error
  }
}

/**
 * Check if current tab has a configured app
 */
async function checkAppDetection() {
  try {
    if (!currentTab || !currentTab.url) {
      updateDetectionStatus(false);
      return;
    }
    
    const response = await chrome.runtime.sendMessage({
      action: 'CHECK_URL_MATCH',
      url: currentTab.url
    });
    
    if (response && response.matched) {
      appConfiguration = response.configuration;
      updateDetectionStatus(true, response.configuration, response.matchType, response.opportunity);
      loadInstructions(response.configuration);
    } else {
      updateDetectionStatus(false);
    }
  } catch (error) {
    console.error('GrandJury Extension: Error checking app detection:', error);
    updateDetectionStatus(false);
  }
}

/**
 * Check if there's an active evaluation session
 */
async function checkEvaluationSession() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'GET_EVALUATION_SESSION' });
    
    if (response && response.session) {
      evaluationSession = response.session;
      showActiveSession(response.session);
      startSessionTimer();
    } else {
      hideActiveSession();
    }
  } catch (error) {
    console.error('GrandJury Extension: Error checking evaluation session:', error);
  }
}

/**
 * Update app detection status
 */
function updateDetectionStatus(detected, configuration = null, matchType = null, opportunity = null) {
  if (detected && configuration) {
    elements.detectionStatus.className = 'status-indicator detected';
    
    // Update status text based on match type
    if (matchType === 'owner') {
      elements.detectionStatus.querySelector('.status-text').textContent = 'Your app detected';
    } else if (matchType === 'evaluator') {
      elements.detectionStatus.querySelector('.status-text').textContent = 'Evaluation opportunity';
    } else {
      elements.detectionStatus.querySelector('.status-text').textContent = 'App detected';
    }
    
    elements.appName.textContent = configuration.app_detection?.app_identifier || configuration.title || 'Unknown App';
    elements.appUrl.textContent = configuration.app_detection?.primary_url || currentTab.url;
    
    // Show additional info for evaluator opportunities
    if (matchType === 'evaluator' && opportunity) {
      const appNameElement = elements.appName;
      if (opportunity.is_test_data) {
        appNameElement.textContent += ' [TEST MODE]';
        appNameElement.style.color = '#FF9800';
      }
      
      // Display credit rewards
      const creditRates = opportunity.credit_rates || {};
      const communityRate = creditRates.community_rate || 0;
      if (communityRate > 0) {
        const rewardInfo = document.createElement('div');
        rewardInfo.style.fontSize = '12px';
        rewardInfo.style.color = '#4CAF50';
        rewardInfo.textContent = `Reward: ${communityRate} credits/eval`;
        appNameElement.parentNode.appendChild(rewardInfo);
      } else if (opportunity.reward_per_vote > 0) {
        const rewardInfo = document.createElement('div');
        rewardInfo.style.fontSize = '12px';
        rewardInfo.style.color = '#4CAF50';
        rewardInfo.textContent = `Reward: $${opportunity.reward_per_vote} per evaluation`;
        appNameElement.parentNode.appendChild(rewardInfo);
      }
      
      if (opportunity.qualification_required) {
        const qualificationInfo = document.createElement('div');
        qualificationInfo.style.fontSize = '12px';
        qualificationInfo.style.color = '#2196F3';
        qualificationInfo.textContent = `Requires: ${opportunity.qualification_required} evaluator`;
        appNameElement.parentNode.appendChild(qualificationInfo);
      }
    }
    
    elements.appInfo.classList.remove('hidden');
    elements.noAppMessage.classList.add('hidden');
    elements.instructionsCard.classList.remove('hidden');
  } else {
    elements.detectionStatus.className = 'status-indicator inactive';
    elements.detectionStatus.querySelector('.status-text').textContent = 'No opportunities found';
    
    elements.appInfo.classList.add('hidden');
    elements.noAppMessage.classList.remove('hidden');
    elements.instructionsCard.classList.add('hidden');
  }
}

/**
 * Load evaluation instructions
 */
function loadInstructions(configuration) {
  if (!configuration || !configuration.evaluation_instructions) {
    return;
  }
  
  const instructions = configuration.evaluation_instructions;
  elements.generalGuidelines.textContent = instructions.general_guidelines || 'No specific guidelines provided.';
  elements.evaluationCriteria.textContent = instructions.evaluation_criteria || 'Standard evaluation criteria apply.';
  elements.appContext.textContent = instructions.app_context || 'No specific context provided.';
  elements.goodExample.textContent = instructions.good_example || 'No example provided.';
  elements.poorExample.textContent = instructions.poor_example || 'No example provided.';
}

/**
 * Show active evaluation session
 */
function showActiveSession(session) {
  elements.activeSessionCard.classList.remove('hidden');
  elements.sessionAppName.textContent = session.configuration?.app_detection?.app_identifier || 'Unknown App';
  
  const creditRate = session.configuration?.credit_rates?.expert_rate || 3;
  elements.sessionCreditRate.textContent = `${creditRate} credits/evaluation`;
  
  // Hide start evaluation button since session is active
  elements.startEvaluationButton.style.display = 'none';
}

/**
 * Hide active session display
 */
function hideActiveSession() {
  elements.activeSessionCard.classList.add('hidden');
  elements.startEvaluationButton.style.display = 'block';
  
  if (sessionTimer) {
    clearInterval(sessionTimer);
    sessionTimer = null;
  }
}

/**
 * Start session duration timer
 */
function startSessionTimer() {
  if (!evaluationSession) return;
  
  const updateDuration = () => {
    const elapsed = Date.now() - evaluationSession.startTime;
    const minutes = Math.floor(elapsed / 60000);
    const seconds = Math.floor((elapsed % 60000) / 1000);
    elements.sessionDuration.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  updateDuration();
  sessionTimer = setInterval(updateDuration, 1000);
}

/**
 * Show specific screen
 */
function showScreen(screenId) {
  console.log('GrandJury Extension: Switching to screen:', screenId);
  
  // Hide all screens
  document.querySelectorAll('.screen').forEach(screen => {
    screen.classList.add('hidden');
    console.log('GrandJury Extension: Hiding screen:', screen.id);
  });
  
  // Show target screen
  const targetScreen = document.getElementById(screenId);
  if (targetScreen) {
    targetScreen.classList.remove('hidden');
    console.log('GrandJury Extension: Successfully showed screen:', screenId);
  } else {
    console.error('GrandJury Extension: Target screen not found:', screenId);
  }
}

/**
 * Show error message
 */
function showError(message) {
  elements.errorMessage.textContent = message;
  showScreen('error-screen');
}

/**
 * Event Handlers
 */

async function handleSignIn() {
  try {
    console.log('GrandJury Extension: handleSignIn() called');
    console.log('GrandJury Extension: signInButton element in handler:', elements.signInButton);

    if (!elements.signInButton) {
      console.error('GrandJury Extension: signInButton not available in handler!');
      return;
    }

    elements.signInButton.disabled = true;
    elements.signInButton.textContent = 'Signing in...';
    console.log('GrandJury Extension: Button state updated, opening auth page');

    // Store the current active tab ID before opening auth tab
    const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const previousTabId = currentTab?.id;
    console.log('GrandJury Extension: Stored previous tab ID:', previousTabId);

    // Store previousTabId in service worker for later retrieval
    await chrome.runtime.sendMessage({
      action: 'STORE_PREVIOUS_TAB',
      previousTabId: previousTabId
    });

    // Open simple auth page for streamlined sign-in
    const signInUrl = 'https://humanjudge.com/auth';
    const authTab = await chrome.tabs.create({ url: signInUrl });
    console.log('GrandJury Extension: Auth tab created successfully, ID:', authTab.id);

    // Store auth tab ID too
    await chrome.runtime.sendMessage({
      action: 'STORE_AUTH_TAB',
      authTabId: authTab.id
    });
    
    // Set up listener for authentication completion
    const authListener = (message, sender, sendResponse) => {
      if (message.action === 'AUTH_COMPLETED' && message.token) {
        console.log('GrandJury Extension: Received authentication token');

        // Reset button state
        elements.signInButton.disabled = false;
        elements.signInButton.textContent = 'Sign In';

        // Reinitialize interface with real authentication
        initializeInterface();

        // Remove the listener after use
        chrome.runtime.onMessage.removeListener(authListener);

        sendResponse({ success: true });
        return true; // Will respond asynchronously
      }
    };
    
    // Add listener for auth completion
    chrome.runtime.onMessage.addListener(authListener);
    
    // Set a timeout to clean up the listener if auth doesn't complete
    setTimeout(() => {
      chrome.runtime.onMessage.removeListener(authListener);
      elements.signInButton.disabled = false;
      elements.signInButton.textContent = 'Sign In';
    }, 300000); // 5 minutes timeout
    
  } catch (error) {
    console.error('GrandJury Extension: Sign in error:', error);
    showError('Failed to sign in. Please try again.');
    elements.signInButton.disabled = false;
    elements.signInButton.textContent = 'Sign In';
  }
}

async function handleCreateAccount() {
  await chrome.tabs.create({ url: 'https://humanjudge.com/auth' });
}

async function handleSignOut() {
  try {
    await chrome.runtime.sendMessage({ action: 'CLEAR_AUTH' });
    
    // Reset UI state
    currentUser = null;
    evaluationSession = null;
    appConfiguration = null;
    
    if (sessionTimer) {
      clearInterval(sessionTimer);
      sessionTimer = null;
    }
    
    showScreen('auth-screen');
  } catch (error) {
    console.error('GrandJury Extension: Sign out error:', error);
  }
}

async function handleStartEvaluation() {
  try {
    if (!appConfiguration) {
      showError('No app configuration found');
      return;
    }

    // Check evaluator status before allowing start
    const evaluatorStatus = window.evaluatorStatus || 'not_applied';
    if (evaluatorStatus !== 'verified') {
      const statusMessages = {
        'not_applied': {
          title: '📝 Apply to Become an Evaluator',
          message: 'You need to apply as a community evaluator before you can start reviewing.\n\nIt only takes a minute — just upload your CV and we\'ll review within 12 hours!',
          action: 'Apply Now',
          url: 'https://humanjudge.com/evaluator/apply'
        },
        'pending': {
          title: '⏳ Application Under Review',
          message: 'Hang tight! Your evaluator application is being reviewed.\n\nWe\'ll notify you by email within 12 hours. Check your inbox (and spam folder)!',
          action: 'Check Status',
          url: 'https://humanjudge.com/dashboard'
        },
        'rejected': {
          title: '❌ Application Not Approved',
          message: 'Unfortunately, your evaluator application was not approved.\n\nIf you believe this is a mistake or have questions, please reach out to our support team.',
          action: 'Contact Support',
          url: 'mailto:support@humanjudge.com'
        }
      };

      const statusInfo = statusMessages[evaluatorStatus] || statusMessages['not_applied'];

      // Show friendly modal/alert with action button
      const userChoice = confirm(`${statusInfo.title}\n\n${statusInfo.message}\n\nClick OK to ${statusInfo.action.toLowerCase()}.`);
      if (userChoice) {
        window.open(statusInfo.url, '_blank');
      }
      return;
    }

    if (!elements.acceptTerms.checked) {
      alert('Please accept the evaluation terms before starting.');
      return;
    }

    elements.startEvaluationButton.disabled = true;
    elements.startEvaluationButton.textContent = 'Starting...';

    const response = await chrome.runtime.sendMessage({
      action: 'START_EVALUATION',
      configuration: appConfiguration
    });

    if (response && response.session) {
      evaluationSession = response.session;
      showActiveSession(response.session);
      startSessionTimer();

      // Notify content script
      await chrome.tabs.sendMessage(currentTab.id, {
        action: 'START_EVALUATION',
        configuration: appConfiguration
      });
    } else if (response && response.error) {
      // Handle backend verification error with friendly message
      if (response.error === 'evaluator_not_verified' || response.status === 403) {
        const errorMessage = response.message || 'You need to be a verified evaluator to start evaluations.';
        alert(`🚫 Cannot Start Evaluation\n\n${errorMessage}`);
        return;
      }
      showError(response.message || 'Failed to start evaluation session');
    }

  } catch (error) {
    console.error('GrandJury Extension: Error starting evaluation:', error);
    showError('Failed to start evaluation session');
  } finally {
    elements.startEvaluationButton.disabled = false;
    elements.startEvaluationButton.textContent = 'Start Evaluation';
  }
}

async function handleStopEvaluation() {
  try {
    await chrome.runtime.sendMessage({ action: 'STOP_EVALUATION' });
    
    // Notify content script
    if (currentTab) {
      await chrome.tabs.sendMessage(currentTab.id, {
        action: 'STOP_EVALUATION'
      });
    }
    
    evaluationSession = null;
    hideActiveSession();
    
  } catch (error) {
    console.error('GrandJury Extension: Error stopping evaluation:', error);
  }
}

async function handleOpenEvaluationInterface() {
  // This would open the evaluation interface (PBI-004)
  // For now, we'll show a placeholder
  alert('Evaluation interface will be available in PBI-004');
}

function handleToggleInstructions() {
  const isHidden = elements.instructionsContent.classList.contains('hidden');
  
  if (isHidden) {
    elements.instructionsContent.classList.remove('hidden');
    elements.toggleInstructions.textContent = 'Hide Details';
  } else {
    elements.instructionsContent.classList.add('hidden');
    elements.toggleInstructions.textContent = 'Show Details';
  }
}

function handleTermsAcceptance() {
  const accepted = elements.acceptTerms.checked;
  elements.startEvaluationButton.disabled = !accepted;
}

async function handleViewApps() {
  await chrome.tabs.create({ url: 'https://humanjudge.com/marketplace' });
}

async function handleSettings() {
  // Would open extension settings/options page
  alert('Settings panel coming soon');
}

async function handleRetry() {
  showScreen('loading-screen');
  try {
    await initializeInterface();
  } catch (error) {
    showError('Retry failed. Please check your connection.');
  }
}

async function handleReportError() {
  await chrome.tabs.create({ url: 'https://humanjudge.com/support?issue=extension' });
}

/**
 * Open external link in new tab
 */
async function openExternalLink(url) {
  try {
    await chrome.tabs.create({ url });
  } catch (error) {
    console.error('GrandJury Extension: Error opening external link:', error);
  }
}

/**
 * Debug interface handlers
 */
async function handleViewDebugLogs() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'GET_DEBUG_LOGS' });
    const display = document.getElementById('debug-logs-display');
    
    if (response && response.logs && response.logs.length > 0) {
      const logsText = response.logs.map(log => {
        return `[${log.timestamp}] ${log.type}\n${JSON.stringify(log, null, 2)}\n---`;
      }).join('\n');
      
      display.textContent = logsText;
      display.style.display = 'block';
    } else {
      display.textContent = 'No debug logs found';
      display.style.display = 'block';
    }
  } catch (error) {
    console.error('Error viewing debug logs:', error);
  }
}

async function handleClearDebugLogs() {
  try {
    await chrome.runtime.sendMessage({ action: 'CLEAR_DEBUG_LOGS' });
    const display = document.getElementById('debug-logs-display');
    display.textContent = 'Debug logs cleared';
    display.style.display = 'block';
    
    setTimeout(() => {
      display.style.display = 'none';
    }, 2000);
  } catch (error) {
    console.error('Error clearing debug logs:', error);
  }
}

// ==================== NEW TO-DO LIST FUNCTIONALITY ====================

/**
 * Initialize the Track AI Output interface
 * Shows button-based UI - loading only happens on user action
 */
async function initializeTodoList() {
  console.log('GrandJury Extension: Initializing Track AI Output interface...');

  // Get or create session ID with SDK integration
  let sessionId = await getOrCreateSessionId();
  elements.currentSessionId.textContent = sessionId.slice(0, 8) + '...';

  // Check SDK status and update connection indicator
  await updateSessionStatusWithSDK(sessionId);

  // Show initial state: Track AI Output button visible, loading hidden
  if (elements.trackPrompt) {
    elements.trackPrompt.classList.remove('hidden');
  }
  elements.loadingTodos.classList.add('hidden');
  elements.noTodos.classList.add('hidden');
  elements.todoList.classList.add('hidden');
  if (elements.retrackSection) {
    elements.retrackSection.classList.add('hidden');
  }

  // Note: No auto-loading - user must click "Track AI Output" button
}

/**
 * Extract UUID from project ID format
 * Converts: proj_79ce1f67_0d34_4f99_8738_a9ea98ab1507 → 79ce1f67-0d34-4f99-8738-a9ea98ab1507
 */
function extractProjectUuid(projectId) {
  if (!projectId) return null;
  // Remove 'proj_' prefix and replace underscores with dashes
  return projectId.replace(/^proj_/, '').replace(/_/g, '-');
}

/**
 * Get or create a grandjury session ID with SDK integration
 * Priority: 1) SDK session, 2) sessionStorage discovery, 3) manual generation
 */
async function getOrCreateSessionId() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab?.id) {
      // Step 1: Check for SDK session and all possible session storage keys
      try {
        // Check if chrome.scripting API is available
        if (!chrome.scripting || !chrome.scripting.executeScript) {
          throw new Error('chrome.scripting API not available - check manifest.json permissions');
        }
        
        const sdkResult = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            // Debug all potential session sources
            const sessionSources = {
              sdkSession: window.grandjurySessionId,
              sdkAvailable: !!window.GrandJury,
              sdkVersion: window.GrandJury?.version,
              sessionStorage: {
                grandjurySessionId: sessionStorage.getItem('grandjurySessionId'),
                grandjury_session_id: sessionStorage.getItem('grandjury_session_id'),
                sessionId: sessionStorage.getItem('sessionId'),
                all: Object.keys(sessionStorage).filter(key => 
                  key.toLowerCase().includes('session')).map(key => 
                  `${key}: ${sessionStorage.getItem(key)}`)
              }
            };
            
            console.log('GrandJury Extension: Session discovery debug:', sessionSources);
            
            // Priority 1: SDK session ID
            if (window.GrandJury && window.grandjurySessionId) {
              return {
                source: 'sdk',
                sessionId: window.grandjurySessionId,
                sdkVersion: window.GrandJury.version || 'unknown',
                debug: sessionSources
              };
            }
            
            // Priority 2: Travel diary session ID (original app session)
            const travelSession = sessionStorage.getItem('sessionId');
            if (travelSession && travelSession.startsWith('session_')) {
              return {
                source: 'travel_diary',
                sessionId: travelSession,
                debug: sessionSources
              };
            }
            
            // Priority 3: Any GrandJury session in storage
            const grantJurySession = sessionStorage.getItem('grandjurySessionId') || 
                                   sessionStorage.getItem('grandjury_session_id');
            if (grantJurySession) {
              return {
                source: 'sessionStorage',
                sessionId: grantJurySession,
                debug: sessionSources
              };
            }
            
            return { source: 'none', debug: sessionSources };
          }
        });
        
        const result = sdkResult[0]?.result;
        console.log('GrandJury Extension: Session discovery result:', result);
        
        if (result?.sessionId) {
          console.log(`GrandJury Extension: Using ${result.source} session ID: ${result.sessionId}`);
          return result.sessionId;
        }
        
        // Debug info for troubleshooting
        if (result?.debug) {
          console.log('GrandJury Extension: Session discovery debug info:', result.debug);
        }
        
      } catch (error) {
        console.log('GrandJury Extension: Could not check for SDK (may be restricted page):', error);
        console.log('GrandJury Extension: Error details:', error.message);
      }
    }
    
    // Step 2: Fallback to manual session generation
    console.log('GrandJury Extension: No session found, generating manual session ID');
    const newSessionId = generateManualSessionId();
    
    // Try to store the new session ID in the current tab
    if (tab?.id) {
      try {
        if (chrome.scripting && chrome.scripting.executeScript) {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (sessionId) => {
              sessionStorage.setItem('grandjurySessionId', sessionId);
              sessionStorage.setItem('grandjury_session_id', sessionId); // Legacy support
            },
            args: [newSessionId]
          });
        }
      } catch (error) {
        console.log('GrandJury Extension: Could not store session ID in tab:', error);
      }
    }
    
    return newSessionId;
    
  } catch (error) {
    console.error('GrandJury Extension: Error getting session ID:', error);
    return generateManualSessionId();
  }
}

/**
 * Generate a manual session ID when SDK is not available
 */
function generateManualSessionId() {
  return 'gj_session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

/**
 * Load pending evaluations by fetching Langfuse traces for captured inference IDs
 */
async function loadPendingEvaluations(sessionId) {
  try {
    // Show loading state
    elements.loadingTodos.classList.remove('hidden');
    elements.noTodos.classList.add('hidden');
    elements.todoList.classList.add('hidden');
    if (elements.retrackSection) {
      elements.retrackSection.classList.add('hidden');
    }

    console.log('🔍 Loading evaluations for session:', sessionId);

    // Check if we have a joined project
    if (!currentProject || !currentProject.grandjury_project_id) {
      console.log('⚠️ No project joined yet');
      elements.loadingTodos.classList.add('hidden');
      elements.noTodos.classList.remove('hidden');
      return;
    }

    const projectId = currentProject.grandjury_project_id;
    console.log('📋 Project ID:', projectId);

    // Get all inference IDs captured from the current tab
    const inferenceIds = await getInferenceIdsFromTab();

    if (inferenceIds.length === 0) {
      console.log('ℹ️ No inference IDs captured yet');
      elements.loadingTodos.classList.add('hidden');
      elements.noTodos.classList.remove('hidden');
      return;
    }

    console.log(`📊 Found ${inferenceIds.length} inference IDs:`, inferenceIds);

    // Fetch traces for each inference ID
    const traces = [];
    let hasLoadingTraces = false;

    for (const inferenceId of inferenceIds) {
      try {
        console.log(`🔎 Fetching trace for inference: ${inferenceId}`);
        const response = await chrome.runtime.sendMessage({
          action: 'GET_TRACE',
          inference_id: inferenceId,
          project_id: projectId
        });

        if (response && response.success && response.data) {
          // Check if this is an error response (Langfuse timeout/error)
          const isError = response.data.user_input === "Error fetching from Langfuse" ||
                         response.data.user_input?.includes("No conversation found") ||
                         response.data.ai_output?.includes("Langfuse API error") ||
                         response.data.ai_output?.includes("timed out");

          if (!isError) {
            traces.push(response.data);
            console.log(`✅ Got trace for ${inferenceId}`);
          } else {
            console.log(`⚠️ Trace not ready yet for ${inferenceId}: ${response.data.ai_output}`);
            hasLoadingTraces = true;
          }
        } else {
          console.log(`⚠️ No trace found for ${inferenceId}:`, response?.error);
        }
      } catch (error) {
        console.error(`❌ Error fetching trace for ${inferenceId}:`, error);
      }
    }

    // Hide loading
    elements.loadingTodos.classList.add('hidden');

    // PBI-005: Filter out traces that have already been evaluated
    // Only show traces where submitted_to_langfuse is false (not yet evaluated)
    const pendingTraces = traces.filter(trace => {
      // If submitted_to_langfuse is true, user has already evaluated this trace
      if (trace.submitted_to_langfuse === true) {
        console.log(`🚫 FILTERING OUT: Trace ${trace.trace_id} - already submitted (evaluation_status=${trace.evaluation_status})`);
        return false;
      }

      // Include traces that haven't been evaluated yet
      console.log(`✅ INCLUDING: Trace ${trace.trace_id} - pending evaluation (submitted_to_langfuse=${trace.submitted_to_langfuse})`);
      return true;
    });

    console.log(`📊 FILTERED: ${traces.length} total traces → ${pendingTraces.length} pending evaluations (${traces.length - pendingTraces.length} already submitted)`);

    if (pendingTraces.length === 0) {
      console.log('ℹ️ No pending evaluations after filtering');

      // Update message based on whether traces are still loading
      if (hasLoadingTraces) {
        elements.noTodos.innerHTML = `
          <div class="no-todos-icon">⏳</div>
          <p>Processing AI output...</p>
          <small>Your AI interaction is being processed. This usually takes a few seconds.</small>
          <button id="retry-track-dynamic" class="secondary-button" style="margin-top: 12px;">
            🔄 Check Again
          </button>
        `;
      } else if (traces.length > 0) {
        // All traces were filtered out (already evaluated) - show success + track again option
        elements.noTodos.innerHTML = `
          <div class="no-todos-icon">✅</div>
          <p>All evaluations complete!</p>
          <small>Great work! Use the app again and track new AI interactions.</small>
          <button id="retry-track-dynamic" class="primary-button" style="margin-top: 12px;">
            📋 Track New AI Output
          </button>
        `;
      } else {
        // No traces found at all
        elements.noTodos.innerHTML = `
          <div class="no-todos-icon">🔍</div>
          <p>No AI output found</p>
          <small>Use an AI feature on this page first, then track again.</small>
          <button id="retry-track-dynamic" class="secondary-button" style="margin-top: 12px;">
            🔄 Track Again
          </button>
        `;
      }

      // Add event listener to dynamically created button
      const retryBtn = elements.noTodos.querySelector('#retry-track-dynamic');
      if (retryBtn) {
        retryBtn.addEventListener('click', handleTrackAiOutput);
      }

      elements.noTodos.classList.remove('hidden');
    } else {
      console.log(`✅ Rendering ${pendingTraces.length} pending traces`);
      renderTodoList(pendingTraces);
      elements.todoList.classList.remove('hidden');
      // Show re-track button so user can fetch new AI output without submitting
      if (elements.retrackSection) {
        elements.retrackSection.classList.remove('hidden');
      }
    }

  } catch (error) {
    console.error('❌ Error loading pending evaluations:', error);
    elements.loadingTodos.classList.add('hidden');
    elements.noTodos.classList.remove('hidden');
  }
}

/**
 * Get all inference IDs captured from the current tab's sessionStorage
 */
async function getInferenceIdsFromTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab?.id) {
      console.log('⚠️ No active tab found');
      return [];
    }

    // Execute script to get inference IDs from the tab's sessionStorage
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        // Get all inference IDs stored in sessionStorage
        const inferenceIds = [];

        // Check for single inference ID (current)
        const currentInferenceId = sessionStorage.getItem('grandjury_current_inference_id');
        if (currentInferenceId) {
          inferenceIds.push(currentInferenceId);
        }

        // Check for array of inference IDs (if we're tracking multiple)
        const inferenceIdsJson = sessionStorage.getItem('grandjury_inference_ids');
        if (inferenceIdsJson) {
          try {
            const ids = JSON.parse(inferenceIdsJson);
            if (Array.isArray(ids)) {
              inferenceIds.push(...ids);
            }
          } catch (e) {
            console.error('Error parsing inference IDs:', e);
          }
        }

        // Remove duplicates
        return [...new Set(inferenceIds)];
      }
    });

    if (results && results[0]?.result) {
      return results[0].result;
    }

    return [];
  } catch (error) {
    console.error('❌ Error getting inference IDs from tab:', error);
    return [];
  }
}


/**
 * Render the to-do list with real Langfuse traces
 */
function renderTodoList(traces) {
  elements.todoList.innerHTML = '';

  traces.forEach((trace, index) => {
    const todoItem = document.createElement('div');
    todoItem.className = 'todo-item';

    // Format timestamp
    const timestamp = trace.timestamp
      ? new Date(trace.timestamp).toLocaleString()
      : 'Unknown time';

    // Escape HTML to prevent XSS
    const escapeHtml = (str) => {
      const div = document.createElement('div');
      div.textContent = str;
      return div.innerHTML;
    };

    // Format time for timeline
    const timeOnly = trace.timestamp
      ? new Date(trace.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : '--:--';

    // User input - use smart content rendering (supports JSON trees)
    const userInput = trace.user_input || 'No input captured';
    const maxPreviewLength = 150;
    const smartUserContent = renderSmartContent(userInput, escapeHtml);

    // For JSON content, the tree is already collapsible, no need for "Show more"
    // For plain text, use the existing preview logic
    const userInputPreview = !smartUserContent.isJSON && userInput.length > maxPreviewLength
      ? userInput.substring(0, maxPreviewLength) + '...'
      : userInput;
    const userInputLong = !smartUserContent.isJSON && userInput.length > maxPreviewLength;

    // AI output - use smart content rendering (C8: JSON tree for complex data)
    const aiOutput = trace.ai_output || 'No output captured';
    const smartAiContent = renderSmartContent(aiOutput, escapeHtml);

    // For JSON content, the tree is already collapsible, no need for "Show more"
    // For plain text, use the existing preview logic
    const aiOutputPreview = !smartAiContent.isJSON && aiOutput.length > maxPreviewLength
      ? aiOutput.substring(0, maxPreviewLength) + '...'
      : aiOutput;
    const aiOutputLong = !smartAiContent.isJSON && aiOutput.length > maxPreviewLength;

    todoItem.innerHTML = `
      <div class="todo-content">
        <div class="conversation-card">
          <!-- User Message - Collapsible (supports JSON tree rendering) -->
          <details class="conversation-turn user-turn" open>
            <summary class="turn-header">
              <div class="turn-indicator">
                <span class="turn-avatar user-avatar">U</span>
                <span class="turn-label">User</span>
              </div>
              <span class="turn-time">${timeOnly}</span>
            </summary>
            <div class="turn-content">
              <div class="message-text ${userInputLong ? 'truncated' : ''}" data-full="${escapeHtml(userInput)}">
                ${smartUserContent.isJSON ? smartUserContent.html : escapeHtml(userInputPreview)}
              </div>
              ${userInputLong ? '<button class="expand-btn">Show more</button>' : ''}
            </div>
          </details>

          <!-- AI Response - Collapsible (C8: Smart JSON tree rendering) -->
          <details class="conversation-turn ai-turn" open>
            <summary class="turn-header">
              <div class="turn-indicator">
                <span class="turn-avatar ai-avatar">AI</span>
                <span class="turn-label">AI</span>
              </div>
                          </summary>
            <div class="turn-content">
              <div class="message-text ${aiOutputLong ? 'truncated' : ''}" data-full="${escapeHtml(aiOutput)}">
                ${smartAiContent.isJSON ? smartAiContent.html : escapeHtml(aiOutputPreview)}
              </div>
              ${aiOutputLong ? '<button class="expand-btn">Show more</button>' : ''}
            </div>
          </details>
        </div>
      </div>
      <div class="todo-actions">
        <div class="todo-question">
          <p><strong>Did this response do the job?</strong></p>
        </div>
        <div class="todo-buttons">
          <button class="vote-button vote-pass" data-index="${index}">
            ✅ Pass
          </button>
          <button class="vote-button vote-flag" data-index="${index}">
            🚩 Flag
          </button>
        </div>
        <div class="feedback-section" data-index="${index}" style="display: none;">
          <div class="category-selector" data-index="${index}" style="display: none;">
            <div class="category-label">Select category:</div>
            <div class="category-chips">
              <span class="category-chip" data-category="wrong">Wrong</span>
              <span class="category-chip" data-category="incomplete">Incomplete</span>
              <span class="category-chip" data-category="missed_point">Missed Point</span>
              <span class="category-chip" data-category="harmful">Harmful</span>
              <span class="category-chip" data-category="impractical">Impractical</span>
            </div>
          </div>
          <div class="todo-feedback">
            <textarea
              class="feedback-input"
              data-index="${index}"
              placeholder="Share your feedback..."
              rows="2"
            ></textarea>
          </div>
          <button class="submit-feedback-btn primary-button" data-index="${index}">
            Submit Evaluation
          </button>
        </div>
      </div>
    `;

    // Add event listeners to vote buttons
    const passButton = todoItem.querySelector('.vote-pass');
    const flagButton = todoItem.querySelector('.vote-flag');
    const feedbackSection = todoItem.querySelector('.feedback-section');
    const categorySelector = todoItem.querySelector('.category-selector');
    const categoryChips = todoItem.querySelectorAll('.category-chip');
    const submitBtn = todoItem.querySelector('.submit-feedback-btn');
    const feedbackInput = todoItem.querySelector('.feedback-input');

    // Track current vote state
    let currentVoteType = null;
    let selectedCategory = null;

    // Pass button: show feedback section (optional feedback)
    passButton.addEventListener('click', () => {
      currentVoteType = 'pass';
      selectedCategory = null;

      // Toggle selection - allow switching between pass/flag
      passButton.classList.add('selected');
      flagButton.classList.remove('selected');

      // Show feedback section without category selector
      feedbackSection.style.display = 'block';
      categorySelector.style.display = 'none';
      feedbackInput.placeholder = 'Share your feedback (optional)...';
      feedbackInput.focus();
    });

    // Flag button: show feedback section with category selector
    flagButton.addEventListener('click', () => {
      currentVoteType = 'flag';

      // Toggle selection - allow switching between pass/flag
      flagButton.classList.add('selected');
      passButton.classList.remove('selected');

      // Show feedback section with category selector
      feedbackSection.style.display = 'block';
      categorySelector.style.display = 'block';
      feedbackInput.placeholder = 'Share your feedback (required)...';
    });

    // Category chip selection (single-select)
    categoryChips.forEach(chip => {
      chip.addEventListener('click', () => {
        selectedCategory = chip.dataset.category;
        categoryChips.forEach(c => c.classList.remove('selected'));
        chip.classList.add('selected');
      });
    });

    // Expand/collapse button for long messages (plain text only, not JSON)
    const expandBtns = todoItem.querySelectorAll('.expand-btn');
    expandBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation(); // Prevent bubbling to details element
        const messageText = btn.previousElementSibling;

        // Skip if this contains JSON tree (shouldn't have expand btn, but safeguard)
        if (messageText.querySelector('.json-tree')) {
          return;
        }

        const fullText = messageText.dataset.full;
        const isExpanded = messageText.classList.contains('expanded');

        if (isExpanded) {
          // Collapse - show truncated
          const truncated = fullText.length > 150
            ? fullText.substring(0, 150) + '...'
            : fullText;
          messageText.textContent = truncated;
          messageText.classList.remove('expanded');
          btn.textContent = 'Show more';
        } else {
          // Expand - show full text
          messageText.textContent = fullText;
          messageText.classList.add('expanded');
          btn.textContent = 'Show less';
        }
      });
    });

    // Submit button: submit the evaluation
    submitBtn.addEventListener('click', () => {
      if (currentVoteType === 'pass') {
        submitVote(trace, true, null, index);
      } else if (currentVoteType === 'flag') {
        submitVote(trace, false, selectedCategory, index);
      }
    });

    elements.todoList.appendChild(todoItem);
  });
}

/**
 * Submit a Pass/Flag evaluation
 * @param {Object} trace - The trace data to evaluate
 * @param {boolean} passFlag - true for Pass, false for Flag
 * @param {string|null} category - Category for Flag (required for Flag, null for Pass)
 * @param {number} itemIndex - Index of the item in the todo list
 */
async function submitVote(trace, passFlag, category, itemIndex) {
  try {
    const voteType = passFlag ? 'Pass' : 'Flag';
    console.log(`📤 Submitting ${voteType} evaluation for trace ${trace.trace_id || trace.inference_id}${category ? ` (category: ${category})` : ''}`);

    // Get feedback from textarea
    const todoItem = elements.todoList.children[itemIndex];
    const feedbackTextarea = todoItem.querySelector('.feedback-input');
    const feedback = feedbackTextarea?.value?.trim();

    // Validate feedback: REQUIRED for Flag, OPTIONAL for Pass
    if (!passFlag && (!feedback || feedback.length === 0)) {
      // Show error message
      const errorMsg = todoItem.querySelector('.feedback-error') || document.createElement('div');
      errorMsg.className = 'feedback-error';
      errorMsg.textContent = '⚠️ Feedback is required when flagging a response';
      errorMsg.style.color = '#dc2626';
      errorMsg.style.fontSize = '12px';
      errorMsg.style.marginTop = '4px';

      if (!todoItem.querySelector('.feedback-error')) {
        feedbackTextarea.parentElement.appendChild(errorMsg);
      }

      // Highlight textarea
      feedbackTextarea.style.borderColor = '#dc2626';
      feedbackTextarea.focus();

      return; // Don't submit without feedback for Flag
    }

    // Remove any existing error messages
    const existingError = todoItem.querySelector('.feedback-error');
    if (existingError) {
      existingError.remove();
    }
    feedbackTextarea.style.borderColor = '';

    // PBI-007 GAP 4: Check reward info BEFORE voting (volunteer mode warning)
    // Get evaluation ID from current project
    if (currentProject && currentProject.grandjury_project_id) {
      try {
        console.log('🔍 Checking reward info before voting...');

        // Convert project_id back to evaluation_id (remove "proj_" prefix and replace underscores with dashes)
        const evaluationId = currentProject.grandjury_project_id
          .replace('proj_', '')
          .replace(/_/g, '-');

        // Fetch reward info from backend
        const rewardResponse = await chrome.runtime.sendMessage({
          action: 'CHECK_REWARD_INFO',
          data: { evaluation_id: evaluationId }
        });

        console.log('📊 Reward info received:', rewardResponse);

        // If volunteer mode (effective reward = 0 but configured reward > 0)
        if (rewardResponse && rewardResponse.success &&
            rewardResponse.data.is_volunteer_mode) {

          console.log('⚠️ Volunteer mode detected - showing confirmation dialog');

          // Show volunteer mode warning dialog
          const confirmed = confirm(
            `⚠️ VOLUNTEER MODE WARNING\n\n` +
            `This evaluation is currently UNFUNDED.\n` +
            `Your vote will be recorded but you will receive $0 reward.\n\n` +
            `Project owner's credit balance: ${rewardResponse.data.creator_balance.toFixed(2)} credits\n` +
            `Configured reward: $${rewardResponse.data.configured_reward.toFixed(2)} per vote\n` +
            `Your effective reward: $0.00\n\n` +
            `Do you want to proceed with volunteer work?\n\n` +
            `Click OK to proceed (volunteer) or Cancel to skip this vote.`
          );

          if (!confirmed) {
            console.log('❌ User declined volunteer work');
            return; // User declined volunteer work - don't submit
          }

          console.log('✅ User confirmed volunteer work');
        }
      } catch (rewardCheckError) {
        // Don't block voting if reward check fails - log warning only
        console.warn('⚠️ Failed to check reward info (continuing with vote):', rewardCheckError);
      }
    }

    // Disable buttons and textarea during submission
    const buttons = todoItem.querySelectorAll('.vote-button');
    buttons.forEach(btn => {
      btn.disabled = true;
      btn.textContent = btn.textContent.replace(/✅|🚩/, '⏳');
    });
    feedbackTextarea.disabled = true;

    // Get current session ID
    const sessionId = await getOrCreateSessionId();

    if (feedback) {
      console.log(`📝 Feedback collected: "${feedback.substring(0, 50)}${feedback.length > 50 ? '...' : ''}"`);
    } else {
      console.log(`📝 No feedback provided (Pass allows optional feedback)`);
    }

    // Submit evaluation with new pass_flag and category structure
    const response = await chrome.runtime.sendMessage({
      action: 'SUBMIT_HUMAN_EVALUATION',
      data: {
        langfuse_trace_id: trace.trace_id || trace.inference_id,
        grandjury_session_id: sessionId,
        grandjury_project_id: currentProject?.grandjury_project_id,
        pass_flag: passFlag,
        category: category,
        feedback: feedback || null,
        user_input: trace.user_input,
        ai_output: trace.ai_output,
        inference_id: trace.inference_id
      }
    });

    if (response && response.success) {
      console.log('✅ Vote submitted successfully');

      const creditsEarned = response.data?.credits_earned || 0;

      // Show beautiful success message with link to public evaluation page
      const projectUuid = extractProjectUuid(currentProject?.grandjury_project_id);
      const publicPageUrl = projectUuid ? `https://humanjudge.com/reports/${projectUuid}` : null;

      todoItem.style.background = 'var(--bg-surface)';
      todoItem.querySelector('.todo-actions').innerHTML = `
        <div class="vote-success" style="text-align: center; padding: 16px;">
          <div style="font-size: 32px; margin-bottom: 8px;">✅</div>
          <div style="font-weight: 600; color: var(--color-success); margin-bottom: 4px;">Evaluation Submitted</div>
          <div style="font-size: 13px; color: var(--text-secondary);">+${creditsEarned} credits earned</div>
          ${publicPageUrl ? `
          <a href="${publicPageUrl}" target="_blank"
             style="display: inline-block; margin-top: 8px; font-size: 12px; color: var(--color-primary); text-decoration: none;">
            View Report →
          </a>
          ` : ''}
        </div>
      `;

      // Remove item after delay
      setTimeout(() => {
        todoItem.style.transition = 'all 0.3s ease';
        todoItem.style.opacity = '0';
        todoItem.style.height = '0px';
        todoItem.style.marginBottom = '0px';

        setTimeout(() => {
          todoItem.remove();

          // Check if list is empty - return to Track button state (not error state)
          if (elements.todoList.children.length === 0) {
            elements.todoList.classList.add('hidden');
            if (elements.retrackSection) {
              elements.retrackSection.classList.add('hidden');
            }

            // Show the Track button again instead of error/no-todos state
            if (elements.trackPrompt) {
              elements.trackPrompt.classList.remove('hidden');
            }
            elements.noTodos.classList.add('hidden');
          }
        }, 300);
      }, 2000);

      // Update stats after a brief delay to ensure database commit is visible
      setTimeout(() => {
        updateUserStats();
      }, 500);

    } else {
      throw new Error(response?.error || 'Failed to submit vote');
    }

  } catch (error) {
    console.error('❌ Error submitting vote:', error);

    // Re-enable buttons and show error
    const todoItem = elements.todoList.children[itemIndex];
    const buttons = todoItem.querySelectorAll('.vote-button');
    buttons.forEach((btn, i) => {
      btn.disabled = false;
      btn.textContent = i === 0 ? '✅ Pass' : '🚩 Flag';
    });

    // Re-enable feedback textarea
    const feedbackTextarea = todoItem.querySelector('.feedback-input');
    if (feedbackTextarea) {
      feedbackTextarea.disabled = false;
    }

    // Hide category selector if it was shown
    const categorySelector = todoItem.querySelector('.category-selector');
    if (categorySelector) {
      categorySelector.style.display = 'none';
    }
    
    // Show error message temporarily
    const actions = todoItem.querySelector('.todo-actions');
    actions.style.border = '2px solid #fef2f2';
    actions.style.background = '#fef2f2';
    actions.insertAdjacentHTML('beforeend', `
      <div class="vote-error" style="color: #dc2626; font-size: 12px; margin-top: 8px;">
        ❌ ${error.message}
      </div>
    `);
    
    setTimeout(() => {
      actions.style.border = '';
      actions.style.background = '';
      const errorEl = actions.querySelector('.vote-error');
      if (errorEl) errorEl.remove();
    }, 5000);
  }
};

/**
 * Handle Track AI Output button click
 * This is the main action button - loads on demand, not automatically
 */
async function handleTrackAiOutput() {
  // Hide the track prompt and no-todos state
  if (elements.trackPrompt) {
    elements.trackPrompt.classList.add('hidden');
  }
  elements.noTodos.classList.add('hidden');
  elements.todoList.classList.add('hidden');
  if (elements.retrackSection) {
    elements.retrackSection.classList.add('hidden');
  }

  // Show loading
  elements.loadingTodos.classList.remove('hidden');

  // Load the pending evaluations
  const sessionId = await getOrCreateSessionId();
  await loadPendingEvaluations(sessionId);
}

/**
 * Handle refresh todos button (legacy, also used internally)
 */
async function handleRefreshTodos() {
  const sessionId = await getOrCreateSessionId();
  await loadPendingEvaluations(sessionId);
}

// ============================================================================
// PBI-014: Others' Inferences Functions
// ============================================================================

/**
 * Handle mode switch between "Your Inferences" and "Others' Inferences"
 * @param {string} mode - 'your' or 'others'
 */
async function handleModeSwitch(mode) {
  if (mode === currentInferenceMode) return;

  console.log(`🔄 Switching inference mode: ${currentInferenceMode} → ${mode}`);
  currentInferenceMode = mode;

  // Update toggle button states
  if (mode === 'your') {
    elements.modeYourInferences?.classList.add('active');
    elements.modeOthersInferences?.classList.remove('active');

    // Show "Your Inferences" UI
    elements.trackOutputCard?.classList.remove('hidden');
    elements.othersInferenceCard?.classList.add('hidden');
  } else {
    elements.modeYourInferences?.classList.remove('active');
    elements.modeOthersInferences?.classList.add('active');

    // Show "Others' Inferences" UI
    elements.trackOutputCard?.classList.add('hidden');
    elements.othersInferenceCard?.classList.remove('hidden');

    // Fetch an inference from others
    await fetchOthersInference();
  }
}

/**
 * Fetch a random inference from another user
 */
async function fetchOthersInference() {
  if (!currentProject?.grandjury_project_id) {
    console.error('❌ Cannot fetch others inference: no project selected');
    return;
  }

  console.log('🔍 Fetching inference from others...');

  // Show loading state
  elements.othersLoading?.classList.remove('hidden');
  elements.othersEmpty?.classList.add('hidden');
  elements.othersInferenceDisplay?.classList.add('hidden');

  try {
    // Send the project_id as-is (backend expects proj_ format)
    const response = await chrome.runtime.sendMessage({
      action: 'FETCH_OTHERS_INFERENCE',
      data: { project_id: currentProject.grandjury_project_id }
    });

    console.log('📥 Others inference response:', response);

    // Hide loading
    elements.othersLoading?.classList.add('hidden');

    if (response && response.success && response.data?.found) {
      // Store current inference
      currentOthersInference = response.data.inference;

      // Display the inference
      displayOthersInference(currentOthersInference);
    } else {
      // No inference available
      currentOthersInference = null;
      elements.othersEmpty?.classList.remove('hidden');
      elements.othersInferenceDisplay?.classList.add('hidden');

      // Update empty message
      if (elements.othersEmptyMessage) {
        elements.othersEmptyMessage.textContent = response?.data?.message ||
          "No one else has submitted inferences yet, or you've evaluated them all!";
      }
    }
  } catch (error) {
    console.error('❌ Error fetching others inference:', error);
    elements.othersLoading?.classList.add('hidden');
    elements.othersEmpty?.classList.remove('hidden');
    elements.othersInferenceDisplay?.classList.add('hidden');

    if (elements.othersEmptyMessage) {
      elements.othersEmptyMessage.textContent = 'Error loading inference. Please try again.';
    }
  }
}

/**
 * Display an inference from another user - using PBI-13 styling
 * @param {Object} inference - The inference data to display
 */
function displayOthersInference(inference) {
  if (!inference) return;

  console.log('📋 Displaying others inference:', inference.langfuse_trace_id);

  // Show display section
  elements.othersInferenceDisplay?.classList.remove('hidden');
  elements.othersEmpty?.classList.add('hidden');

  // Escape HTML to prevent XSS
  const escapeHtml = (str) => {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  };

  // User input
  const userInput = typeof inference.user_input === 'string'
    ? inference.user_input
    : JSON.stringify(inference.user_input, null, 2);
  const maxPreviewLength = 150;
  const smartUserContent = renderSmartContent(userInput || 'No input available', escapeHtml);
  const userInputPreview = !smartUserContent.isJSON && userInput && userInput.length > maxPreviewLength
    ? userInput.substring(0, maxPreviewLength) + '...'
    : userInput || 'No input available';
  const userInputLong = !smartUserContent.isJSON && userInput && userInput.length > maxPreviewLength;

  // AI output
  const aiOutput = inference.ai_output || 'No output available';
  const smartAiContent = renderSmartContent(aiOutput, escapeHtml);
  const aiOutputPreview = !smartAiContent.isJSON && aiOutput.length > maxPreviewLength
    ? aiOutput.substring(0, maxPreviewLength) + '...'
    : aiOutput;
  const aiOutputLong = !smartAiContent.isJSON && aiOutput.length > maxPreviewLength;

  // Render content matching PBI-13 styling
  const contentHtml = `
    <div class="todo-content">
      <div class="conversation-card">
        <!-- User Message - Collapsible -->
        <details class="conversation-turn user-turn" open>
          <summary class="turn-header">
            <div class="turn-indicator">
              <span class="turn-avatar user-avatar">U</span>
              <span class="turn-label">User</span>
            </div>
          </summary>
          <div class="turn-content">
            <div class="message-text ${userInputLong ? 'truncated' : ''}" data-full="${escapeHtml(userInput || '')}">
              ${smartUserContent.isJSON ? smartUserContent.html : escapeHtml(userInputPreview)}
            </div>
            ${userInputLong ? '<button class="expand-btn">Show more</button>' : ''}
          </div>
        </details>

        <!-- AI Response - Collapsible -->
        <details class="conversation-turn ai-turn" open>
          <summary class="turn-header">
            <div class="turn-indicator">
              <span class="turn-avatar ai-avatar">AI</span>
              <span class="turn-label">AI</span>
            </div>
          </summary>
          <div class="turn-content">
            <div class="message-text ${aiOutputLong ? 'truncated' : ''}" data-full="${escapeHtml(aiOutput)}">
              ${smartAiContent.isJSON ? smartAiContent.html : escapeHtml(aiOutputPreview)}
            </div>
            ${aiOutputLong ? '<button class="expand-btn">Show more</button>' : ''}
          </div>
        </details>
      </div>
    </div>
    <div class="todo-actions">
      <div class="todo-question">
        <p><strong>Did this response do the job?</strong></p>
      </div>
      <div class="todo-buttons">
        <button class="vote-button vote-pass others-vote-pass">
          ✅ Pass
        </button>
        <button class="vote-button vote-flag others-vote-flag">
          🚩 Flag
        </button>
      </div>
      <div class="feedback-section others-feedback-section" style="display: none;">
        <div class="category-selector others-category-selector" style="display: none;">
          <div class="category-label">Select category:</div>
          <div class="category-chips">
            <span class="category-chip" data-category="wrong">Wrong</span>
            <span class="category-chip" data-category="incomplete">Incomplete</span>
            <span class="category-chip" data-category="missed_point">Missed Point</span>
            <span class="category-chip" data-category="harmful">Harmful</span>
            <span class="category-chip" data-category="impractical">Impractical</span>
          </div>
        </div>
        <div class="todo-feedback">
          <textarea
            class="feedback-input others-feedback-input"
            placeholder="Share your feedback..."
            rows="2"
          ></textarea>
        </div>
        <button class="submit-feedback-btn primary-button others-submit-btn">
          Submit Evaluation
        </button>
      </div>
    </div>
  `;

  // Set the content
  if (elements.othersInferenceContent) {
    elements.othersInferenceContent.innerHTML = contentHtml;

    // Setup event listeners for this inference
    setupOthersInferenceEventListeners();
  }

  // Set evaluation count - total reviews (creator + others)
  // Base case: count=1 means creator has reviewed
  if (elements.othersEvalCount) {
    const count = inference.evaluation_count || 1;
    if (count === 1) {
      elements.othersEvalCount.textContent = 'Reviewed by 1 user';
    } else {
      elements.othersEvalCount.textContent = `Reviewed by ${count} users`;
    }
  }
}

/**
 * Setup event listeners for the dynamically rendered others inference content
 */
function setupOthersInferenceEventListeners() {
  const container = elements.othersInferenceContent;
  if (!container) return;

  const passButton = container.querySelector('.others-vote-pass');
  const flagButton = container.querySelector('.others-vote-flag');
  const feedbackSection = container.querySelector('.others-feedback-section');
  const categorySelector = container.querySelector('.others-category-selector');
  const categoryChips = container.querySelectorAll('.category-chip');
  const submitBtn = container.querySelector('.others-submit-btn');
  const feedbackInput = container.querySelector('.others-feedback-input');
  const expandBtns = container.querySelectorAll('.expand-btn');

  // Track current vote state
  let currentVoteType = null;
  let selectedCategory = null;

  // Expand buttons for long text
  expandBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const textDiv = btn.previousElementSibling;
      if (textDiv && textDiv.dataset.full) {
        textDiv.textContent = textDiv.dataset.full;
        textDiv.classList.remove('truncated');
        btn.remove();
      }
    });
  });

  // Pass button: show feedback section (optional feedback)
  passButton?.addEventListener('click', () => {
    currentVoteType = 'pass';
    selectedCategory = null;

    // Toggle selection - allow switching between pass/flag
    passButton.classList.add('selected');
    flagButton.classList.remove('selected');

    feedbackSection.style.display = 'block';
    categorySelector.style.display = 'none';
    feedbackInput.placeholder = 'Share your feedback (optional)...';
    feedbackInput.focus();
  });

  // Flag button: show feedback section with category selector
  flagButton?.addEventListener('click', () => {
    currentVoteType = 'flag';

    // Toggle selection - allow switching between pass/flag
    flagButton.classList.add('selected');
    passButton.classList.remove('selected');

    feedbackSection.style.display = 'block';
    categorySelector.style.display = 'block';
    feedbackInput.placeholder = 'Share your feedback (required)...';
  });

  // Category chip selection (single-select)
  categoryChips.forEach(chip => {
    chip.addEventListener('click', () => {
      categoryChips.forEach(c => c.classList.remove('selected'));
      chip.classList.add('selected');
      selectedCategory = chip.dataset.category;
    });
  });

  // Submit button
  submitBtn?.addEventListener('click', async () => {
    // For Flag: require category selection
    if (currentVoteType === 'flag' && !selectedCategory) {
      alert('Please select a category for flagged responses');
      return;
    }

    const feedback = feedbackInput?.value?.trim() || null;
    const passFlag = currentVoteType === 'pass';

    // Disable submit button during submission
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting...';

    await submitOthersEvaluation(passFlag, selectedCategory, feedback);
  });
}

/**
 * Handle shuffle - get a different inference from others
 */
async function handleOthersShuffle() {
  console.log('🔀 Shuffling to get different inference...');
  await fetchOthersInference();
}

/**
 * Submit evaluation for others' inference (matches PBI-13 flow)
 * @param {boolean} passFlag - true for Pass, false for Flag
 * @param {string|null} category - Category if flagged
 * @param {string|null} feedback - Optional feedback text
 */
async function submitOthersEvaluation(passFlag, category, feedback) {
  if (!currentOthersInference) {
    console.error('❌ No current inference to vote on');
    return;
  }

  const voteType = passFlag ? 'Pass' : 'Flag';
  console.log(`📤 Submitting ${voteType} for others inference: ${currentOthersInference.langfuse_trace_id}`);

  try {
    // Get session ID
    const sessionId = await getOrCreateSessionId();

    // Submit evaluation
    const response = await chrome.runtime.sendMessage({
      action: 'SUBMIT_HUMAN_EVALUATION',
      data: {
        langfuse_trace_id: currentOthersInference.langfuse_trace_id,
        grandjury_session_id: sessionId,
        grandjury_project_id: currentProject?.grandjury_project_id,
        pass_flag: passFlag,
        category: category,
        feedback: feedback,
        user_input: currentOthersInference.user_input,
        ai_output: currentOthersInference.ai_output,
        inference_id: currentOthersInference.langfuse_trace_id
      }
    });

    if (response && response.success) {
      console.log('✅ Others inference evaluation submitted successfully');

      const creditsEarned = response.data?.credits_earned || 0;

      // Show success state in the todo-actions div (matching PBI-13 pattern)
      if (elements.othersInferenceContent) {
        const actionsDiv = elements.othersInferenceContent.querySelector('.todo-actions');
        if (actionsDiv) {
          const projectUuid = extractProjectUuid(currentProject?.grandjury_project_id);
          const publicPageUrl = projectUuid ? `https://humanjudge.com/reports/${projectUuid}` : null;

          actionsDiv.innerHTML = `
            <div class="vote-success" style="text-align: center; padding: 12px;">
              <div style="font-size: 24px; margin-bottom: 4px;">✅</div>
              <div style="font-weight: 600; color: var(--color-success);">Evaluation Submitted</div>
              <div style="font-size: 12px; color: var(--text-secondary);">+${creditsEarned} credits</div>
              ${publicPageUrl ? `
              <a href="${publicPageUrl}" target="_blank"
                 style="display: inline-block; margin-top: 8px; font-size: 12px; color: var(--color-primary); text-decoration: none;">
                View Report →
              </a>
              ` : ''}
            </div>
          `;
        }
      }

      // Update stats
      setTimeout(() => {
        updateUserStats();
      }, 500);

      // Auto-load next inference after delay (displayOthersInference will reset the UI)
      setTimeout(async () => {
        await fetchOthersInference();
      }, 2000);

    } else {
      throw new Error(response?.error || 'Failed to submit evaluation');
    }

  } catch (error) {
    console.error('❌ Error submitting others vote:', error);

    // Re-enable submit button
    const submitBtn = elements.othersInferenceContent?.querySelector('.others-submit-btn');
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Submit Evaluation';
    }

    // Show error
    alert(`Error: ${error.message}`);
  }
}

/**
 * Update the "Others' Inferences" count badge
 */
async function updateOthersInferenceCount() {
  if (!currentProject?.grandjury_project_id) return;

  try {
    // Send the project_id as-is (backend expects proj_ format)
    const response = await chrome.runtime.sendMessage({
      action: 'FETCH_OTHERS_INFERENCE_STATS',
      data: { project_id: currentProject.grandjury_project_id }
    });

    if (response && response.success && response.data) {
      othersInferenceStats = response.data;

      const count = response.data.available_count || 0;

      if (elements.othersCountBadge) {
        if (count > 0) {
          elements.othersCountBadge.textContent = count > 99 ? '99+' : count;
          elements.othersCountBadge.classList.remove('hidden');
        } else {
          elements.othersCountBadge.classList.add('hidden');
        }
      }
    }
  } catch (error) {
    console.error('⚠️ Error fetching others inference stats:', error);
  }
}

// ============================================================================
// End PBI-014 Functions
// ============================================================================

/**
 * Update session status with SDK integration info
 */
async function updateSessionStatusWithSDK(sessionId) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab?.id) {
      // Check if SDK is available on current tab
      if (!chrome.scripting || !chrome.scripting.executeScript) {
        console.log('GrandJury Extension: chrome.scripting API not available');
        updateSessionStatus('active', 'Session active');
        return;
      }
      
      const sdkStatus = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          if (window.GrandJury) {
            return {
              sdkAvailable: true,
              sdkVersion: window.GrandJury.version || 'unknown',
              hasSession: !!window.grandjurySessionId,
              hasConfig: !!window.grandjuryConfig
            };
          }
          return { sdkAvailable: false };
        }
      });
      
      const status = sdkStatus[0]?.result;
      
      if (status?.sdkAvailable) {
        updateSessionStatus('active', `SDK Active (v${status.sdkVersion})`);
        
        // Show SDK status in UI
        if (elements.sdkStatus && elements.sdkVersion) {
          elements.sdkStatus.classList.remove('hidden');
          elements.sdkVersion.textContent = `v${status.sdkVersion}`;
          elements.sdkVersion.style.color = '#4CAF50';
        }
        
        console.log('GrandJury Extension: SDK integration active', status);
      } else {
        updateSessionStatus('active', 'Connected');

        // Hide SDK status
        if (elements.sdkStatus) {
          elements.sdkStatus.classList.add('hidden');
        }

        console.log('GrandJury Extension: Using extension-only session');
      }
    } else {
      updateSessionStatus('active', 'Connected');
    }
  } catch (error) {
    console.error('GrandJury Extension: Error checking SDK status:', error);
    updateSessionStatus('active', 'Connected');
  }
}

/**
 * Update session status indicator
 */
function updateSessionStatus(status, text) {
  const statusDot = elements.sessionStatus.querySelector('.status-dot');
  const statusText = elements.sessionStatus.querySelector('.status-text');
  
  statusDot.className = `status-dot ${status}`;
  statusText.textContent = text;
}

/**
 * Update user stats from server
 */
async function updateUserStats() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'GET_USER_STATS' });
    if (response && response.success) {
      const stats = response.data;
      const totalEvals = stats.total_evaluations || 0;
      elements.totalEvaluations.textContent = totalEvals;
      elements.creditsEarned.textContent = stats.credits_earned || '0';

      // Check for milestone celebration (1st, 2nd, 3rd evaluation)
      checkMilestoneCelebration(totalEvals);
    }
  } catch (error) {
    console.error('Error updating stats:', error);
  }
}

/**
 * Check and show milestone celebration for 1st, 2nd, 3rd evaluation
 */
function checkMilestoneCelebration(totalEvaluations) {
  if (!elements.milestoneCelebration || !elements.milestoneMessage) {
    return;
  }

  const milestoneMessages = {
    1: "🎉 First evaluation complete! You're making AI better.",
    2: "⭐ Second evaluation done! You're on a roll.",
    3: "🏆 Three evaluations! You're a GrandJury pro."
  };

  const message = milestoneMessages[totalEvaluations];

  if (message) {
    elements.milestoneMessage.textContent = message;
    elements.milestoneCelebration.classList.remove('hidden');
  } else {
    elements.milestoneCelebration.classList.add('hidden');
  }
}

/**
 * Utility function to truncate text
 */
function truncateText(text, maxLength) {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

// ============================================================================
// INFERENCE OBSERVABILITY FUNCTIONALITY
// ============================================================================

/**
 * Grab the latest inference ID from the frontend app
 */
async function handleGrabInferenceId() {
  const button = document.getElementById('grab-inference-id');
  const originalText = button.textContent;
  
  try {
    // Update button state
    button.textContent = '🔄 Grabbing...';
    button.disabled = true;
    button.classList.add('pulse');
    
    console.log('🔍 [INFERENCE] Attempting to grab inference ID from current tab...');
    
    // Send message to content script to get inference data
    const response = await chrome.tabs.sendMessage(currentTab.id, {
      action: 'GET_INFERENCE_DATA'
    });
    
    if (response && response.success) {
      console.log('✅ [INFERENCE] Successfully grabbed inference data:', response.data);
      updateInferenceDisplay(response.data);
      addInferenceToLog(response.data);
    } else {
      console.warn('⚠️ [INFERENCE] No inference data available:', response);
      updateInferenceDisplay({
        status: 'No inference ID detected',
        sdkStatus: 'SDK not detected or no active inference',
        timestamp: new Date().toISOString()
      });
    }
    
  } catch (error) {
    console.error('❌ [INFERENCE] Error grabbing inference ID:', error);
    updateInferenceDisplay({
      status: 'Error: ' + error.message,
      sdkStatus: 'Connection failed',
      timestamp: new Date().toISOString()
    });
  } finally {
    // Reset button state
    button.textContent = originalText;
    button.disabled = false;
    button.classList.remove('pulse');
  }
}

/**
 * Clear all inference data
 */
async function handleClearInferenceData() {
  try {
    console.log('🗑️ [INFERENCE] Clearing inference data...');
    
    // Clear display
    updateInferenceDisplay({
      status: 'Cleared',
      sdkStatus: 'Ready',
      timestamp: '--'
    });
    
    // Clear log
    clearInferenceLog();
    
    // Clear storage
    await chrome.storage.local.remove(['inferenceHistory']);
    
    console.log('✅ [INFERENCE] Inference data cleared');
    
  } catch (error) {
    console.error('❌ [INFERENCE] Error clearing inference data:', error);
  }
}

/**
 * Update the inference display UI
 */
function updateInferenceDisplay(data) {
  const currentInferenceId = document.getElementById('current-inference-id');
  const inferenceTimestamp = document.getElementById('inference-timestamp');
  const sdkConnectionStatus = document.getElementById('sdk-connection-status');
  
  if (currentInferenceId) {
    if (data.inferenceId) {
      currentInferenceId.textContent = data.inferenceId;
      currentInferenceId.title = data.inferenceId; // Full text on hover
    } else {
      currentInferenceId.textContent = data.status || 'None detected';
    }
  }
  
  if (inferenceTimestamp) {
    if (data.timestamp && data.timestamp !== '--') {
      const time = new Date(data.timestamp);
      inferenceTimestamp.textContent = time.toLocaleTimeString();
    } else {
      inferenceTimestamp.textContent = data.timestamp || '--';
    }
  }
  
  if (sdkConnectionStatus) {
    sdkConnectionStatus.textContent = data.sdkStatus || 'Unknown';
    
    // Update status class
    sdkConnectionStatus.className = 'connection-status';
    if (data.sdkStatus?.includes('Connected') || data.sdkStatus?.includes('Ready')) {
      sdkConnectionStatus.classList.add('connected');
    } else if (data.sdkStatus?.includes('failed') || data.sdkStatus?.includes('Error')) {
      sdkConnectionStatus.classList.add('disconnected');
    } else {
      sdkConnectionStatus.classList.add('checking');
    }
  }
}

/**
 * Add inference to log history
 */
async function addInferenceToLog(inferenceData) {
  try {
    // Get existing history
    const result = await chrome.storage.local.get(['inferenceHistory']);
    const history = result.inferenceHistory || [];
    
    // Add new inference (only if it has a valid ID)
    if (inferenceData.inferenceId && inferenceData.inferenceId !== 'None detected') {
      const logEntry = {
        inferenceId: inferenceData.inferenceId,
        timestamp: inferenceData.timestamp || new Date().toISOString(),
        metadata: inferenceData.metadata || {},
        url: currentTab?.url || 'Unknown'
      };
      
      // Check if this inference ID already exists
      const exists = history.some(entry => entry.inferenceId === logEntry.inferenceId);
      if (!exists) {
        history.unshift(logEntry); // Add to beginning
        
        // Keep only last 20 entries
        if (history.length > 20) {
          history.splice(20);
        }
        
        // Save back to storage
        await chrome.storage.local.set({ inferenceHistory: history });
      }
    }
    
    // Update UI
    updateInferenceLog(history);
    
  } catch (error) {
    console.error('❌ [INFERENCE] Error adding to log:', error);
  }
}

/**
 * Update the inference log UI
 */
function updateInferenceLog(history = []) {
  const logItems = document.getElementById('inference-log-items');
  const inferenceCount = document.getElementById('inference-count');
  
  if (!logItems || !inferenceCount) return;
  
  // Update count
  inferenceCount.textContent = history.length.toString();
  
  // Clear existing items
  logItems.innerHTML = '';
  
  if (history.length === 0) {
    logItems.innerHTML = '<div class="log-empty">No inference IDs captured yet</div>';
    return;
  }
  
  // Add log items
  history.forEach((entry, index) => {
    const logItem = document.createElement('div');
    logItem.className = 'log-item';
    
    const time = new Date(entry.timestamp);
    const timeStr = time.toLocaleTimeString();
    
    const truncatedId = entry.inferenceId.length > 25 
      ? entry.inferenceId.substring(0, 25) + '...'
      : entry.inferenceId;
    
    logItem.innerHTML = `
      <div class="log-item-header">
        <span class="log-item-inference" title="${entry.inferenceId}">${truncatedId}</span>
        <span class="log-item-time">${timeStr}</span>
      </div>
      <div class="log-item-metadata">
        ${entry.metadata?.user_intent || 'Unknown intent'} • ${new URL(entry.url).hostname}
      </div>
    `;
    
    logItems.appendChild(logItem);
  });
}

/**
 * Clear inference log
 */
function clearInferenceLog() {
  const logItems = document.getElementById('inference-log-items');
  const inferenceCount = document.getElementById('inference-count');
  
  if (logItems) {
    logItems.innerHTML = '<div class="log-empty">No inference IDs captured yet</div>';
  }
  
  if (inferenceCount) {
    inferenceCount.textContent = '0';
  }
}

/**
 * Initialize inference observability when dashboard loads
 */
async function initializeInferenceObservability() {
  try {
    console.log('🔍 [INFERENCE] Initializing observability...');
    
    // Load inference history from storage
    const result = await chrome.storage.local.get(['inferenceHistory']);
    const history = result.inferenceHistory || [];
    
    // Update log UI
    updateInferenceLog(history);
    
    // Initial status check
    updateInferenceDisplay({
      status: 'Ready to capture',
      sdkStatus: 'Checking...',
      timestamp: '--'
    });
    
    console.log('✅ [INFERENCE] Observability initialized with', history.length, 'entries');
    
  } catch (error) {
    console.error('❌ [INFERENCE] Error initializing observability:', error);
  }
}

/**
 * Initialize conversation fetching when dashboard loads
 */
async function initializeConversationFetching() {
  try {
    console.log('💬 [CONVERSATION] Initializing conversation fetching...');
    
    // Enable the fetch conversation button for testing
    const fetchButton = document.getElementById('fetch-conversation');
    if (fetchButton) {
      fetchButton.disabled = false;
      fetchButton.textContent = '💬 Fetch Conversation (Ready)';
      console.log('✅ [CONVERSATION] Fetch button enabled for testing');
    }
    
    console.log('✅ [CONVERSATION] Conversation fetching initialized');
    
  } catch (error) {
    console.error('❌ [CONVERSATION] Error initializing conversation fetching:', error);
  }
}

// ============================================================================
// CONVERSATION FETCHING FUNCTIONALITY  
// ============================================================================

let currentInferenceId = null;
let currentProjectId = null;

/**
 * Handle fetch conversation button click
 */
async function handleFetchConversation() {
  const button = document.getElementById('fetch-conversation');
  const originalText = button.textContent;
  
  try {
    // Update button state
    button.textContent = '🔄 Fetching...';
    button.disabled = true;
    
    console.log('🔍 [CONVERSATION] Starting conversation fetch...');
    
    // Step 1: Get the latest inference ID from the current tab
    await updateCurrentInferenceData();
    
    if (!currentInferenceId) {
      // For testing: use hardcoded inference ID
      currentInferenceId = 'gj_inf_1759291075177_jlt1';
      console.log('🔧 [CONVERSATION] Using hardcoded inference ID for testing:', currentInferenceId);
    }
    
    if (!currentProjectId) {
      throw new Error('No project ID detected. This Chrome extension needs to run on a page with GrandJury SDK initialized.');
    }
    
    console.log('📋 [CONVERSATION] Using inference ID:', currentInferenceId);
    console.log('📋 [CONVERSATION] Using project ID:', currentProjectId);
    
    // Step 2: Call the backend API to fetch traces
    const authResponse = await chrome.runtime.sendMessage({ action: 'GET_AUTH_STATUS' });
    if (!authResponse || !authResponse.token) {
      throw new Error('Not authenticated. Please sign in first.');
    }
    
    const apiUrl = await getApiBaseUrl();
    const response = await fetch(`${apiUrl}/api/v1/extension/traces/${encodeURIComponent(currentInferenceId)}?project_id=${encodeURIComponent(currentProjectId)}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authResponse.token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API request failed: ${response.status} - ${errorText}`);
    }
    
    const traceData = await response.json();
    console.log('✅ [CONVERSATION] Received trace data:', traceData);
    
    // Step 3: Display the conversation
    displayConversation(traceData);
    
  } catch (error) {
    console.error('❌ [CONVERSATION] Error fetching conversation:', error);
    showConversationError(error.message);
  } finally {
    // Reset button state
    button.textContent = originalText;
    button.disabled = false;
  }
}

/**
 * Update current inference and project ID from tab
 */
async function updateCurrentInferenceData() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab?.id) {
      throw new Error('No active tab found');
    }
    
    // Try to get inference data from content script
    const response = await chrome.tabs.sendMessage(tab.id, {
      action: 'GET_INFERENCE_DATA'
    });
    
    if (response && response.success && response.data) {
      currentInferenceId = response.data.inferenceId;
      currentProjectId = response.data.projectId;
      
      console.log('📡 [CONVERSATION] Got inference data from tab:', {
        inferenceId: currentInferenceId,
        projectId: currentProjectId
      });
      
      // Update button state based on data availability
      const button = document.getElementById('fetch-conversation');
      if (currentInferenceId) {
        button.disabled = false;
        button.textContent = '💬 Fetch Conversation';
      } else {
        // For testing: always enable the button
        button.disabled = false;
        button.textContent = '💬 Fetch Conversation (Test)';
      }
      
      return true;
    } else {
      // Fallback: try to get from page directly
      const fallbackResult = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          // Check for GrandJury SDK data
          const sdkData = {
            inferenceId: window.grandjuryCurrentInferenceId || window.grandjuryInferenceId || window.currentInferenceId,
            projectId: window.grandjuryProjectId || window.grandJuryProjectId || window.currentProjectId
          };
          
          // Check sessionStorage for stored data
          const storedInference = sessionStorage.getItem('grandjury_current_inference_id') ||
                                sessionStorage.getItem('currentInferenceId') || 
                                sessionStorage.getItem('grandjury_inference_id');
          const storedProject = sessionStorage.getItem('grandjury_project_id') ||
                               sessionStorage.getItem('currentProjectId');
          
          return {
            sdk: sdkData,
            storage: {
              inferenceId: storedInference,
              projectId: storedProject
            },
            found: !!(sdkData.inferenceId || storedInference || sdkData.projectId || storedProject)
          };
        }
      });
      
      const fallback = fallbackResult[0]?.result;
      if (fallback?.found) {
        currentInferenceId = fallback.sdk.inferenceId || fallback.storage.inferenceId;
        currentProjectId = fallback.sdk.projectId || fallback.storage.projectId;
        
        console.log('📡 [CONVERSATION] Got fallback data:', {
          inferenceId: currentInferenceId,
          projectId: currentProjectId
        });
        
        return true;
      }
      
      console.log('⚠️ [CONVERSATION] No inference data found in tab');
      return false;
    }
    
  } catch (error) {
    console.error('❌ [CONVERSATION] Error getting inference data:', error);
    return false;
  }
}

/**
 * Display conversation data in the UI
 */
function displayConversation(traceData) {
  const conversationDisplay = document.getElementById('conversation-display');
  
  if (!conversationDisplay) {
    console.error('❌ [CONVERSATION] Conversation display element not found');
    return;
  }
  
  if (!traceData || !traceData.traces || traceData.traces.length === 0) {
    // Show debug info if available
    let debugHTML = '';
    if (traceData && traceData.traces && traceData.traces[0]) {
      const trace = traceData.traces[0];
      if (trace.debug_info) {
        debugHTML = `
          <details class="debug-info">
            <summary>🔍 Debug Info (Click to expand)</summary>
            <pre>${JSON.stringify(trace.debug_info, null, 2)}</pre>
          </details>
        `;
      }
      if (trace.raw_traces && trace.raw_traces.length > 0) {
        debugHTML += `
          <details class="debug-info">
            <summary>📊 Raw Langfuse Traces (${trace.raw_traces.length} traces)</summary>
            <pre>${JSON.stringify(trace.raw_traces, null, 2)}</pre>
          </details>
        `;
      }
    }

    conversationDisplay.innerHTML = `
      <div class="conversation-empty">
        <h3>No Conversation Found</h3>
        <p>No traces found for inference ID: <code>${currentInferenceId}</code></p>
        <p>Project: <code>${currentProjectId}</code></p>
        ${debugHTML}
      </div>
    `;
    conversationDisplay.style.display = 'block';
    return;
  }
  
  // Build conversation HTML
  let conversationHTML = `
    <div class="conversation-header">
      <h3>💬 AI Conversation</h3>
      <div class="conversation-meta">
        <small>Inference: ${currentInferenceId}</small>
        <small>Found ${traceData.traces.length} trace(s)</small>
      </div>
    </div>
    <div class="conversation-content">
  `;
  
  // Process each trace
  traceData.traces.forEach((trace, index) => {
    const userInput = trace.input || 'No input recorded';
    const aiOutput = trace.output || 'No output recorded';
    const timestamp = trace.timestamp ? new Date(trace.timestamp).toLocaleTimeString() : 'Unknown time';
    
    conversationHTML += `
      <div class="conversation-turn">
        <div class="conversation-user">
          <div class="conversation-role">👤 User</div>
          <div class="conversation-message">${escapeHtml(userInput)}</div>
        </div>
        <div class="conversation-ai">
          <div class="conversation-role">🤖 Assistant</div>
          <div class="conversation-message">${escapeHtml(aiOutput)}</div>
        </div>
        <div class="conversation-timestamp">${timestamp}</div>
      </div>
    `;
  });
  
  conversationHTML += `
    </div>
    <div class="conversation-actions">
      <button class="copy-button">📋 Copy Conversation</button>
      <button class="clear-button">🗑️ Clear</button>
    </div>
  `;

  conversationDisplay.innerHTML = conversationHTML;
  conversationDisplay.style.display = 'block';

  // Add event listeners (CSP-compliant - no inline onclick)
  conversationDisplay.querySelector('.copy-button')?.addEventListener('click', window.copyConversation);
  conversationDisplay.querySelector('.clear-button')?.addEventListener('click', window.clearConversation);

  console.log('✅ [CONVERSATION] Conversation displayed successfully');
}

/**
 * Show conversation error
 */
function showConversationError(errorMessage) {
  const conversationDisplay = document.getElementById('conversation-display');
  
  if (!conversationDisplay) return;
  
  conversationDisplay.innerHTML = `
    <div class="conversation-error">
      <h3>❌ Conversation Fetch Failed</h3>
      <p class="error-message">${escapeHtml(errorMessage)}</p>
      <div class="error-details">
        <small>Inference ID: ${currentInferenceId || 'Not detected'}</small>
        <small>Project ID: ${currentProjectId || 'Not detected'}</small>
        <small>Timestamp: ${new Date().toISOString()}</small>
      </div>
      <button class="clear-button">🗑️ Clear</button>
    </div>
  `;
  conversationDisplay.style.display = 'block';

  // Add event listener (CSP-compliant - no inline onclick)
  conversationDisplay.querySelector('.clear-button')?.addEventListener('click', window.clearConversation);
}

/**
 * Copy conversation to clipboard
 */
window.copyConversation = function() {
  const conversationContent = document.querySelector('.conversation-content');
  if (!conversationContent) return;
  
  let text = `AI Conversation (${currentInferenceId})\n\n`;
  
  const turns = conversationContent.querySelectorAll('.conversation-turn');
  turns.forEach((turn, index) => {
    const userMsg = turn.querySelector('.conversation-user .conversation-message').textContent;
    const aiMsg = turn.querySelector('.conversation-ai .conversation-message').textContent;
    const timestamp = turn.querySelector('.conversation-timestamp').textContent;
    
    text += `[${timestamp}]\nUser: ${userMsg}\nAssistant: ${aiMsg}\n\n`;
  });
  
  navigator.clipboard.writeText(text).then(() => {
    const button = document.querySelector('.copy-button');
    const originalText = button.textContent;
    button.textContent = '✅ Copied!';
    setTimeout(() => {
      button.textContent = originalText;
    }, 2000);
  });
};

/**
 * Clear conversation display
 */
window.clearConversation = function() {
  const conversationDisplay = document.getElementById('conversation-display');
  if (conversationDisplay) {
    conversationDisplay.style.display = 'none';
  }
};

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/**
 * Get API base URL (reuse from existing code)
 */
async function getApiBaseUrl() {
  try {
    const response = await fetch('http://127.0.0.1:8001/api/v1/extension/health', {
      method: 'GET',
      signal: AbortSignal.timeout(2000)
    });
    
    if (response.ok) {
      console.log('🔧 [API] Using development API');
      return 'http://127.0.0.1:8001';
    }
  } catch (error) {
    // Development server not available
  }
  
  console.log('🔧 [API] Using production API');
  return 'https://grandjury-server.onrender.com';
}

// ============================================================================
// PROJECT SELECTION AND JOINING FUNCTIONALITY
// ============================================================================

// Global state for projects
let availableProjects = [];
let currentProject = null;
let selectedProjectForDetails = null;

/**
 * Get joined project from storage
 */
async function getJoinedProject() {
  try {
    const result = await chrome.storage.local.get(['joinedProject']);
    return result.joinedProject || null;
  } catch (error) {
    console.error('Error getting joined project:', error);
    return null;
  }
}

/**
 * Save joined project to storage
 */
async function saveJoinedProject(project) {
  try {
    await chrome.storage.local.set({ joinedProject: project });
    console.log('✅ Joined project saved:', project.grandjury_project_id);
  } catch (error) {
    console.error('Error saving joined project:', error);
  }
}

/**
 * Clear joined project from storage (when URL doesn't match)
 */
async function clearJoinedProject() {
  try {
    await chrome.storage.local.remove(['joinedProject']);
    console.log('🗑️ Joined project cleared from storage');
  } catch (error) {
    console.error('Error clearing joined project:', error);
  }
}

/**
 * Fetch available projects from current tab
 * Filters by the current tab's URL to only show matching projects
 */
async function fetchAvailableProjects() {
  try {
    console.log('═══════════════════════════════════════════════════');
    console.log('🔍 [URL DETECTION] Starting project fetch...');
    console.log('═══════════════════════════════════════════════════');

    // Get current tab URL to filter projects
    let currentTabUrl = null;
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      console.log('📍 [URL DETECTION] Tab query result:', {
        tabFound: !!tab,
        tabId: tab?.id,
        tabUrl: tab?.url,
        tabTitle: tab?.title
      });

      if (tab && tab.url) {
        currentTabUrl = tab.url;
        // Parse URL to show domain
        try {
          const parsedUrl = new URL(currentTabUrl);
          console.log('📍 [URL DETECTION] Parsed URL details:', {
            fullUrl: currentTabUrl,
            protocol: parsedUrl.protocol,
            hostname: parsedUrl.hostname,
            pathname: parsedUrl.pathname
          });
        } catch (e) {
          console.log('📍 [URL DETECTION] Could not parse URL:', currentTabUrl);
        }
      } else {
        console.warn('⚠️ [URL DETECTION] No URL found in current tab');
      }
    } catch (tabError) {
      console.warn('⚠️ [URL DETECTION] Error querying tab:', tabError);
    }

    // Get opportunities from backend, filtered by current URL
    console.log('📡 [API REQUEST] Sending GET_OPPORTUNITIES with filterUrl:', currentTabUrl);
    const opportunitiesData = await chrome.runtime.sendMessage({
      action: 'GET_OPPORTUNITIES',
      filterUrl: currentTabUrl
    });

    console.log('📡 [API RESPONSE] Raw response:', {
      hasData: !!opportunitiesData,
      hasOpportunities: !!(opportunitiesData?.opportunities),
      opportunityCount: opportunitiesData?.opportunities?.length || 0,
      userStats: opportunitiesData?.user_stats ? 'present' : 'missing'
    });

    if (!opportunitiesData || !opportunitiesData.opportunities) {
      console.log('⚠️ [API RESPONSE] No opportunities data received');
      return [];
    }

    const opportunities = opportunitiesData.opportunities;
    console.log(`📋 [API RESPONSE] Found ${opportunities.length} matching projects`);

    // Log each opportunity for debugging
    opportunities.forEach((opp, idx) => {
      console.log(`   [${idx + 1}] Project: "${opp.title}" (ID: ${opp.id})`);
      console.log(`       - primary_url: ${opp.app_detection?.primary_url || 'not set'}`);
    });

    // Extract unique projects (opportunities may have duplicate projects)
    const projectsMap = new Map();

    for (const opp of opportunities) {
      const projectId = opp.id; // Using opportunity ID as unique identifier
      if (!projectsMap.has(projectId)) {
        projectsMap.set(projectId, {
          id: projectId,
          grandjury_project_id: projectId, // Will be the evaluation config ID
          title: opp.title || 'Untitled Project',
          description: opp.description || 'No description',
          reward_per_vote: opp.reward_per_vote || 0,
          evaluation_instructions: opp.evaluation_instructions || {},
          app_detection: opp.app_detection || {},
          requires_expertise: opp.requires_expertise || false,
          credit_rates: opp.credit_rates || {}
        });
      }
    }

    const finalProjects = Array.from(projectsMap.values());
    console.log('═══════════════════════════════════════════════════');
    console.log(`✅ [URL DETECTION] Complete: ${finalProjects.length} unique projects returned`);
    console.log('═══════════════════════════════════════════════════');
    return finalProjects;

  } catch (error) {
    console.error('❌ [URL DETECTION] Error fetching projects:', error);
    return [];
  }
}

/**
 * Show project selection screen with available projects
 */
function showProjectSelection(projects) {
  console.log('📋 Showing project selection for', projects.length, 'projects');

  availableProjects = projects;
  elements.projectsList.innerHTML = '';

  // Update subtitle based on project count
  if (elements.projectsSubtitle) {
    if (projects.length === 1) {
      elements.projectsSubtitle.textContent = '1 project available on this page';
    } else {
      elements.projectsSubtitle.textContent = `${projects.length} projects available on this page`;
    }
  }

  projects.forEach((project, index) => {
    const projectCard = document.createElement('div');
    projectCard.className = 'project-card';

    // Determine reward display (credits vs dollars)
    const creditRates = project.credit_rates || {};
    const communityRate = creditRates.community_rate || 0;
    let rewardDisplay = '';
    if (communityRate > 0) {
      rewardDisplay = `💰 ${communityRate} credits/eval`;
    } else {
      rewardDisplay = `💰 $${project.reward_per_vote}/eval`;
    }

    projectCard.innerHTML = `
      <div class="project-card-header">
        <h4>${project.title}</h4>
        <span class="project-reward">${rewardDisplay}</span>
      </div>
      <div class="project-card-body">
        <p class="project-description">${project.description}</p>
        <div class="project-meta">
          <span class="project-id">ID: ${project.grandjury_project_id.substring(0, 8)}...</span>
          ${project.requires_expertise ? '<span class="badge-expert">Expert Required</span>' : ''}
        </div>
      </div>
      <div class="project-card-footer">
        <button class="primary-button view-details-btn" data-index="${index}">
          View Details & Join
        </button>
      </div>
    `;
    elements.projectsList.appendChild(projectCard);

    // Add event listener (CSP-compliant - no inline onclick)
    const viewBtn = projectCard.querySelector('.view-details-btn');
    viewBtn.addEventListener('click', () => {
      window.viewProjectDetails(index);
    });
  });

  showScreen('project-selection-screen');
}

/**
 * View project details (called from project card button)
 */
window.viewProjectDetails = function(projectIndex) {
  const project = availableProjects[projectIndex];
  selectedProjectForDetails = project;

  console.log('📄 Viewing details for project:', project.grandjury_project_id);

  // Populate project details screen
  const instructions = project.evaluation_instructions || {};

  elements.detailProjectId.textContent = project.grandjury_project_id;
  elements.detailProjectName.textContent = project.title || 'Unnamed Project';

  // Display credit rewards instead of dollar amounts
  const creditRates = project.credit_rates || {};
  const communityRate = creditRates.community_rate || 0;
  if (communityRate > 0) {
    elements.detailReward.textContent = `${communityRate} credits per evaluation`;
  } else {
    elements.detailReward.textContent = `$${project.reward_per_vote} per evaluation`;
  }

  elements.detailAppContext.textContent = instructions.app_context || 'No context provided';
  elements.detailGeneralGuidelines.textContent = instructions.general_guidelines || 'No guidelines provided';
  elements.detailEvaluationCriteria.textContent = instructions.evaluation_criteria || 'No criteria provided';

  // Reset checkbox
  elements.acceptTermsCheckbox.checked = false;
  elements.acceptJoinProject.disabled = true;

  showScreen('project-details-screen');
};

/**
 * Handle terms checkbox change
 */
function handleTermsCheckboxChange() {
  elements.acceptJoinProject.disabled = !elements.acceptTermsCheckbox.checked;
}

/**
 * Handle accept and join project
 * PRE-014: Now calls backend to persist participation in evaluation_participants table
 */
async function handleAcceptJoinProject() {
  if (!selectedProjectForDetails) {
    console.error('No project selected');
    return;
  }

  const projectId = selectedProjectForDetails.grandjury_project_id;

  try {
    console.log('✅ Accepting and joining project:', projectId);

    // Step 1: Call backend to register participation (UPSERT - safe to call multiple times)
    const authResponse = await chrome.runtime.sendMessage({ action: 'GET_AUTH_STATUS' });
    if (!authResponse || !authResponse.token) {
      throw new Error('Not authenticated. Please sign in first.');
    }

    const apiUrl = await getApiBaseUrl();
    const response = await fetch(`${apiUrl}/api/v1/extension/projects/${encodeURIComponent(projectId)}/join`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authResponse.token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      // Check if this is an evaluator verification block (403)
      if (response.status === 403) {
        let errorData;
        try {
          errorData = await response.json();
        } catch {
          errorData = { status: 'unknown' };
        }

        // Handle evaluator not verified - show small hint under button
        if (errorData.detail?.error === 'evaluator_not_verified') {
          const status = errorData.detail?.status || 'not_applied';
          const statusMessages = {
            'not_applied': 'Please apply as an evaluator first at humanjudge.com/evaluator/apply',
            'pending': 'Your application is under review. We\'ll notify you within 12 hours!',
            'rejected': 'Your application was not approved. Contact support@humanjudge.com for help.'
          };
          const msgEl = document.getElementById('join-status-message');
          if (msgEl) {
            msgEl.textContent = statusMessages[status] || statusMessages['not_applied'];
            msgEl.style.display = 'block';
          }
          return; // Block - do not proceed
        }
      }

      // For other errors, log and allow fallback to local storage
      const errorText = await response.text();
      console.error('❌ Backend join failed:', response.status, errorText);
      console.warn('⚠️ Proceeding with local storage only');
    } else {
      const result = await response.json();
      console.log('✅ Backend join successful:', result);
    }

    // Step 2: Save to local storage (always do this for extension state)
    currentProject = selectedProjectForDetails;
    await saveJoinedProject(currentProject);

    // Update dashboard with project context
    displayProjectContext(currentProject);

    // Show dashboard
    showScreen('dashboard-screen');

    // Initialize dashboard with this project
    await initializeTodoList();

  } catch (error) {
    console.error('❌ Error joining project:', error);
    showError('Failed to join project. Please try again.');
  }
}

/**
 * Display project context in dashboard
 */
function displayProjectContext(project) {
  if (!project) {
    elements.projectContextCard.classList.add('hidden');
    return;
  }

  const instructions = project.evaluation_instructions || {};

  // Set project ID with title for tooltip on hover (fixes overflow)
  elements.currentProjectId.textContent = project.grandjury_project_id;
  elements.currentProjectId.title = project.grandjury_project_id; // Full ID on hover
  elements.currentProjectName.textContent = project.title || 'Unnamed Project';

  // Display credit rewards instead of dollar amounts
  const creditRates = project.credit_rates || {};
  const communityRate = creditRates.community_rate || 0;
  if (communityRate > 0) {
    elements.currentReward.textContent = `${communityRate} credits per evaluation`;
  } else {
    elements.currentReward.textContent = `$${project.reward_per_vote} per evaluation`;
  }

  elements.currentAppContext.textContent = instructions.app_context || 'No context provided';
  elements.currentGeneralGuidelines.textContent = instructions.general_guidelines || 'No guidelines provided';
  elements.currentEvaluationCriteria.textContent = instructions.evaluation_criteria || 'No criteria provided';

  elements.projectContextCard.classList.remove('hidden');

  // PBI-015: Show View Report link
  if (elements.projectActions && elements.viewReportLink) {
    // Get the evaluation UUID from grandjury_project_id (convert proj_ format to UUID with dashes)
    const evaluationUuid = extractProjectUuid(project.grandjury_project_id);
    elements.viewReportLink.href = `https://humanjudge.com/reports/${evaluationUuid}`;
    elements.projectActions.classList.remove('hidden');
  }

  // PBI-014: Show mode toggle and update others' inference count
  if (elements.inferenceModeToggle) {
    elements.inferenceModeToggle.classList.remove('hidden');
  }

  // Reset to "Your Inferences" mode by default
  currentInferenceMode = 'your';
  elements.modeYourInferences?.classList.add('active');
  elements.modeOthersInferences?.classList.remove('active');
  elements.trackOutputCard?.classList.remove('hidden');
  elements.othersInferenceCard?.classList.add('hidden');

  // Fetch count of available inferences from others
  updateOthersInferenceCount();

  console.log('✅ Project context displayed in dashboard');
}

/**
 * Handle change project button
 */
async function handleChangeProject() {
  console.log('🔄 User wants to change project');

  // Fetch fresh list of projects
  const projects = await fetchAvailableProjects();

  if (projects.length === 0) {
    alert('No projects available on this page');
    return;
  }

  if (projects.length === 1) {
    // Only one project, show details directly
    selectedProjectForDetails = projects[0];
    window.viewProjectDetails(0);
  } else {
    // Multiple projects, show selection
    showProjectSelection(projects);
  }
}

console.log('GrandJury Extension: Popup script loaded');