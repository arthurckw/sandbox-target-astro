/**
 * GrandJury Chrome Extension API Utilities
 * Centralized API communication functions
 */

// API Configuration
const API_ENDPOINTS = {
  production: 'https://grandjury-server.onrender.com',
  development: 'http://127.0.0.1:8001'
};

/**
 * Get the appropriate API base URL
 */
async function getApiBaseUrl() {
  try {
    // Try to reach local development server first
    const response = await fetch(`${API_ENDPOINTS.development}/api/v1/extension/health`, {
      method: 'GET',
      signal: AbortSignal.timeout(2000) // 2 second timeout
    });
    
    if (response.ok) {
      console.log('GrandJury Extension: Using development API');
      return API_ENDPOINTS.development;
    }
  } catch (error) {
    // Development server not available
  }
  
  console.log('GrandJury Extension: Using production API');
  return API_ENDPOINTS.production;
}

/**
 * Make authenticated API request
 */
async function makeApiRequest(endpoint, options = {}) {
  try {
    const baseUrl = await getApiBaseUrl();
    const url = `${baseUrl}${endpoint}`;
    
    // Get auth token from storage
    const authResponse = await chrome.runtime.sendMessage({ action: 'GET_AUTH_STATUS' });
    
    const defaultOptions = {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(authResponse?.token && { 'Authorization': `Bearer ${authResponse.token}` })
      }
    };
    
    const finalOptions = {
      ...defaultOptions,
      ...options,
      headers: {
        ...defaultOptions.headers,
        ...options.headers
      }
    };
    
    const response = await fetch(url, finalOptions);
    
    if (!response.ok) {
      if (response.status === 401) {
        // Clear invalid auth
        await chrome.runtime.sendMessage({ action: 'CLEAR_AUTH' });
        throw new Error('Authentication expired');
      }
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('GrandJury Extension: API request error:', error);
    throw error;
  }
}

/**
 * API Functions
 */

/**
 * Get evaluation configurations
 */
async function getConfigurations() {
  return await makeApiRequest('/api/v1/extension/configurations');
}

/**
 * Get evaluation opportunities
 */
async function getOpportunities() {
  return await makeApiRequest('/api/v1/extension/opportunities');
}

/**
 * Validate authentication token
 */
async function validateAuth(token, extensionVersion = '1.0.0') {
  return await makeApiRequest('/api/v1/extension/auth/validate', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
      token: token,
      extension_version: extensionVersion
    })
  });
}

/**
 * Get user statistics
 */
async function getUserStats() {
  return await makeApiRequest('/api/v1/extension/user/stats');
}

/**
 * Start evaluation session
 */
async function startEvaluationSession(configurationId) {
  return await makeApiRequest('/api/v1/extension/sessions/start', {
    method: 'POST',
    body: JSON.stringify({
      configuration_id: configurationId
    })
  });
}

/**
 * Stop evaluation session
 */
async function stopEvaluationSession(sessionId) {
  return await makeApiRequest('/api/v1/extension/sessions/stop', {
    method: 'POST',
    body: JSON.stringify({
      session_id: sessionId
    })
  });
}

/**
 * Send session heartbeat to keep session alive
 */
async function sendSessionHeartbeat(sessionId) {
  return await makeApiRequest('/api/v1/extension/sessions/heartbeat', {
    method: 'POST',
    body: JSON.stringify({
      session_id: sessionId
    })
  });
}

/**
 * Track events for analytics and debugging
 */
async function trackEvent(eventName, properties = {}) {
  return await makeApiRequest('/api/v1/extension/events/track', {
    method: 'POST',
    body: JSON.stringify({
      event: eventName,
      properties: properties
    })
  });
}

/**
 * Check API health
 */
async function checkApiHealth() {
  try {
    const baseUrl = await getApiBaseUrl();
    const response = await fetch(`${baseUrl}/api/v1/extension/health`);
    return response.ok;
  } catch (error) {
    return false;
  }
}

// Export API functions
export {
  getApiBaseUrl,
  makeApiRequest,
  getConfigurations,
  getOpportunities,
  validateAuth,
  getUserStats,
  startEvaluationSession,
  stopEvaluationSession,
  sendSessionHeartbeat,
  trackEvent,
  checkApiHealth
};