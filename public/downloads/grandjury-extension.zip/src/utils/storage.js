/**
 * GrandJury Chrome Extension Storage Utilities
 * Centralized storage management for extension data
 */

/**
 * Storage keys used by the extension
 */
const STORAGE_KEYS = {
  AUTH_TOKEN: 'authToken',
  SESSION_EXPIRY: 'sessionExpiry',
  USER_PROFILE: 'userProfile',
  EVALUATION_SESSION: 'evaluationSession',
  CONFIG_CACHE: 'configCache',
  CONFIG_CACHE_TIMESTAMP: 'configCacheTimestamp',
  USER_PREFERENCES: 'userPreferences',
  EXTENSION_SETTINGS: 'extensionSettings'
};

/**
 * Default user preferences
 */
const DEFAULT_PREFERENCES = {
  notifications: true,
  autoDetection: true,
  badgeUpdates: true,
  sessionReminders: true
};

/**
 * Default extension settings
 */
const DEFAULT_SETTINGS = {
  apiEndpoint: 'auto',
  performanceMode: 'balanced',
  debugMode: false
};

/**
 * Storage operations
 */

/**
 * Get item from Chrome storage
 */
async function getStorageItem(key, defaultValue = null) {
  try {
    const result = await chrome.storage.local.get([key]);
    return result[key] !== undefined ? result[key] : defaultValue;
  } catch (error) {
    console.error(`GrandJury Extension: Error getting storage item ${key}:`, error);
    return defaultValue;
  }
}

/**
 * Set item in Chrome storage
 */
async function setStorageItem(key, value) {
  try {
    await chrome.storage.local.set({ [key]: value });
    console.log(`GrandJury Extension: Storage item ${key} updated`);
  } catch (error) {
    console.error(`GrandJury Extension: Error setting storage item ${key}:`, error);
    throw error;
  }
}

/**
 * Remove item from Chrome storage
 */
async function removeStorageItem(key) {
  try {
    await chrome.storage.local.remove([key]);
    console.log(`GrandJury Extension: Storage item ${key} removed`);
  } catch (error) {
    console.error(`GrandJury Extension: Error removing storage item ${key}:`, error);
    throw error;
  }
}

/**
 * Get multiple items from Chrome storage
 */
async function getStorageItems(keys) {
  try {
    const result = await chrome.storage.local.get(keys);
    return result;
  } catch (error) {
    console.error('GrandJury Extension: Error getting storage items:', error);
    return {};
  }
}

/**
 * Set multiple items in Chrome storage
 */
async function setStorageItems(items) {
  try {
    await chrome.storage.local.set(items);
    console.log('GrandJury Extension: Multiple storage items updated');
  } catch (error) {
    console.error('GrandJury Extension: Error setting storage items:', error);
    throw error;
  }
}

/**
 * Clear all extension storage
 */
async function clearAllStorage() {
  try {
    await chrome.storage.local.clear();
    console.log('GrandJury Extension: All storage cleared');
  } catch (error) {
    console.error('GrandJury Extension: Error clearing storage:', error);
    throw error;
  }
}

/**
 * Authentication storage functions
 */

/**
 * Store authentication data
 */
async function storeAuthData(token, expiryTime = null) {
  const expiry = expiryTime || (Date.now() + (30 * 60 * 1000)); // 30 minutes default
  
  await setStorageItems({
    [STORAGE_KEYS.AUTH_TOKEN]: token,
    [STORAGE_KEYS.SESSION_EXPIRY]: expiry
  });
}

/**
 * Get authentication data
 */
async function getAuthData() {
  const data = await getStorageItems([
    STORAGE_KEYS.AUTH_TOKEN,
    STORAGE_KEYS.SESSION_EXPIRY
  ]);
  
  return {
    token: data[STORAGE_KEYS.AUTH_TOKEN],
    expiry: data[STORAGE_KEYS.SESSION_EXPIRY]
  };
}

/**
 * Check if authentication is valid
 */
async function isAuthValid() {
  const authData = await getAuthData();
  
  if (!authData.token || !authData.expiry) {
    return false;
  }
  
  return Date.now() < authData.expiry;
}

/**
 * Clear authentication data
 */
async function clearAuthData() {
  await chrome.storage.local.remove([
    STORAGE_KEYS.AUTH_TOKEN,
    STORAGE_KEYS.SESSION_EXPIRY,
    STORAGE_KEYS.USER_PROFILE
  ]);
}

/**
 * User profile storage functions
 */

/**
 * Store user profile
 */
async function storeUserProfile(profile) {
  await setStorageItem(STORAGE_KEYS.USER_PROFILE, profile);
}

/**
 * Get user profile
 */
async function getUserProfile() {
  return await getStorageItem(STORAGE_KEYS.USER_PROFILE);
}

/**
 * Session storage functions
 */

/**
 * Store evaluation session
 */
async function storeEvaluationSession(session) {
  await setStorageItem(STORAGE_KEYS.EVALUATION_SESSION, session);
}

/**
 * Get evaluation session
 */
async function getEvaluationSession() {
  return await getStorageItem(STORAGE_KEYS.EVALUATION_SESSION);
}

/**
 * Clear evaluation session
 */
async function clearEvaluationSession() {
  await removeStorageItem(STORAGE_KEYS.EVALUATION_SESSION);
}

/**
 * Configuration cache functions
 */

/**
 * Store configuration cache
 */
async function storeConfigCache(configurations) {
  await setStorageItems({
    [STORAGE_KEYS.CONFIG_CACHE]: configurations,
    [STORAGE_KEYS.CONFIG_CACHE_TIMESTAMP]: Date.now()
  });
}

/**
 * Get configuration cache
 */
async function getConfigCache() {
  const data = await getStorageItems([
    STORAGE_KEYS.CONFIG_CACHE,
    STORAGE_KEYS.CONFIG_CACHE_TIMESTAMP
  ]);
  
  return {
    configurations: data[STORAGE_KEYS.CONFIG_CACHE],
    timestamp: data[STORAGE_KEYS.CONFIG_CACHE_TIMESTAMP]
  };
}

/**
 * Check if configuration cache is valid (5 minutes)
 */
async function isConfigCacheValid() {
  const cache = await getConfigCache();
  
  if (!cache.configurations || !cache.timestamp) {
    return false;
  }
  
  const fiveMinutes = 5 * 60 * 1000;
  return (Date.now() - cache.timestamp) < fiveMinutes;
}

/**
 * Clear configuration cache
 */
async function clearConfigCache() {
  await chrome.storage.local.remove([
    STORAGE_KEYS.CONFIG_CACHE,
    STORAGE_KEYS.CONFIG_CACHE_TIMESTAMP
  ]);
}

/**
 * Preferences and settings functions
 */

/**
 * Get user preferences
 */
async function getUserPreferences() {
  const preferences = await getStorageItem(STORAGE_KEYS.USER_PREFERENCES);
  return { ...DEFAULT_PREFERENCES, ...preferences };
}

/**
 * Update user preferences
 */
async function updateUserPreferences(updates) {
  const current = await getUserPreferences();
  const updated = { ...current, ...updates };
  await setStorageItem(STORAGE_KEYS.USER_PREFERENCES, updated);
  return updated;
}

/**
 * Get extension settings
 */
async function getExtensionSettings() {
  const settings = await getStorageItem(STORAGE_KEYS.EXTENSION_SETTINGS);
  return { ...DEFAULT_SETTINGS, ...settings };
}

/**
 * Update extension settings
 */
async function updateExtensionSettings(updates) {
  const current = await getExtensionSettings();
  const updated = { ...current, ...updates };
  await setStorageItem(STORAGE_KEYS.EXTENSION_SETTINGS, updated);
  return updated;
}

/**
 * Data management functions
 */

/**
 * Get storage usage information
 */
async function getStorageUsage() {
  try {
    const usage = await chrome.storage.local.getBytesInUse();
    const all = await chrome.storage.local.get();
    
    return {
      bytesUsed: usage,
      itemCount: Object.keys(all).length,
      items: Object.keys(all)
    };
  } catch (error) {
    console.error('GrandJury Extension: Error getting storage usage:', error);
    return null;
  }
}

/**
 * Export all extension data (for backup)
 */
async function exportExtensionData() {
  try {
    const allData = await chrome.storage.local.get();
    return {
      timestamp: Date.now(),
      version: '1.0.0',
      data: allData
    };
  } catch (error) {
    console.error('GrandJury Extension: Error exporting data:', error);
    throw error;
  }
}

/**
 * Import extension data (from backup)
 */
async function importExtensionData(exportData) {
  try {
    if (!exportData.data) {
      throw new Error('Invalid export data format');
    }
    
    await chrome.storage.local.clear();
    await chrome.storage.local.set(exportData.data);
    
    console.log('GrandJury Extension: Data imported successfully');
  } catch (error) {
    console.error('GrandJury Extension: Error importing data:', error);
    throw error;
  }
}

// Export all storage functions
export {
  STORAGE_KEYS,
  DEFAULT_PREFERENCES,
  DEFAULT_SETTINGS,
  getStorageItem,
  setStorageItem,
  removeStorageItem,
  getStorageItems,
  setStorageItems,
  clearAllStorage,
  storeAuthData,
  getAuthData,
  isAuthValid,
  clearAuthData,
  storeUserProfile,
  getUserProfile,
  storeEvaluationSession,
  getEvaluationSession,
  clearEvaluationSession,
  storeConfigCache,
  getConfigCache,
  isConfigCacheValid,
  clearConfigCache,
  getUserPreferences,
  updateUserPreferences,
  getExtensionSettings,
  updateExtensionSettings,
  getStorageUsage,
  exportExtensionData,
  importExtensionData
};