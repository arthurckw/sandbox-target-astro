/**
 * GrandJury Chrome Extension Content Script
 * Runs on all web pages for app detection with <100ms performance impact
 */

(function() {
  'use strict';
  
  // Performance tracking
  const startTime = performance.now();
  
  // Content script state
  let isGrandJuryApp = false;
  let currentConfiguration = null;
  let evaluationOverlay = null;
  let isInEvaluationMode = false;
  let aiResponseDetector = null;
  let currentEvaluationInterface = null;
  let sdkDetected = false;
  let sdkReadyListener = null;
  
  /**
   * Initialize content script with minimal DOM impact
   */
  function initializeContentScript() {
    try {
      // Quick URL check first (fastest operation)
      const currentUrl = window.location.href;
      
      // Check if this looks like a configured app URL
      checkIfConfiguredApp(currentUrl);
      
      // Detect SDK availability
      detectSDKAvailability();
      
      // Listen for messages from service worker
      chrome.runtime.onMessage.addListener(handleMessage);
      
      // Listen for authentication tokens from auth-capture script
      window.addEventListener('message', (event) => {
        // Only accept messages from same origin
        if (event.origin !== window.location.origin) return;
        
        // Check if it's our auth token message
        if (event.data && event.data.type === 'GRANDJURY_AUTH_TOKEN') {
          console.log('GrandJury Extension: Received auth token from webpage');
          
          // Forward the token to extension background script
          chrome.runtime.sendMessage({
            action: event.data.action,
            token: event.data.token,
            source: event.data.source,
            timestamp: event.data.timestamp
          }, (response) => {
            if (chrome.runtime.lastError) {
              console.error('GrandJury Extension: Error forwarding token:', chrome.runtime.lastError);
            } else {
              console.log('GrandJury Extension: Token forwarded successfully:', response);
            }
          });
        }
      });
      
      // Track performance impact
      const initTime = performance.now() - startTime;
      if (initTime > 100) {
        console.warn(`GrandJury Extension: Content script initialization took ${initTime.toFixed(2)}ms (target: <100ms)`);
      } else {
        console.log(`GrandJury Extension: Content script initialized in ${initTime.toFixed(2)}ms`);
      }
      
    } catch (error) {
      console.error('GrandJury Extension: Content script initialization error:', error);
    }
  }
  
  /**
   * Detect if GrandJury SDK is available on the webpage
   */
  function detectSDKAvailability() {
    try {
      // Check if SDK is already loaded
      if (window.GrandJury) {
        handleSDKDetected();
        return;
      }
      
      // Listen for SDK ready event
      sdkReadyListener = (event) => {
        if (event.type === 'grandjury:ready' || 
            (event.detail && event.detail.type === 'grandjury:ready')) {
          console.log('GrandJury Extension: SDK ready event detected');
          handleSDKDetected();
        }
      };
      
      // Add event listener for SDK ready
      document.addEventListener('grandjury:ready', sdkReadyListener);
      window.addEventListener('grandjury:ready', sdkReadyListener);
      
      // Check periodically for SDK availability (fallback)
      let checkCount = 0;
      const maxChecks = 10; // Check for 5 seconds
      
      const sdkCheck = setInterval(() => {
        checkCount++;
        
        if (window.GrandJury) {
          clearInterval(sdkCheck);
          handleSDKDetected();
        } else if (checkCount >= maxChecks) {
          clearInterval(sdkCheck);
          console.log('GrandJury Extension: SDK not detected after', maxChecks * 500, 'ms');
        }
      }, 500);
      
    } catch (error) {
      console.error('GrandJury Extension: Error detecting SDK:', error);
    }
  }
  
  /**
   * Handle SDK detection
   */
  function handleSDKDetected() {
    if (sdkDetected) return; // Already handled
    
    sdkDetected = true;
    console.log('GrandJury Extension: SDK detected on page', {
      version: window.GrandJury?.version || 'unknown',
      sessionId: window.grandjurySessionId ? 'present' : 'not set',
      config: window.grandjuryConfig ? 'present' : 'not set'
    });
    
    // Clean up event listeners
    if (sdkReadyListener) {
      document.removeEventListener('grandjury:ready', sdkReadyListener);
      window.removeEventListener('grandjury:ready', sdkReadyListener);
      sdkReadyListener = null;
    }
    
    // Enhance app detection with SDK integration
    enhanceAppDetectionWithSDK();
    
    // Listen for SDK events
    listenForSDKEvents();
  }
  
  /**
   * Enhance app detection with SDK integration
   */
  function enhanceAppDetectionWithSDK() {
    try {
      // If SDK has configuration, use it to enhance detection
      if (window.grandjuryConfig) {
        const sdkConfig = window.grandjuryConfig;
        console.log('GrandJury Extension: Using SDK configuration for enhanced detection');
        
        // Mark as SDK-enabled app
        isGrandJuryApp = true;
        currentConfiguration = {
          ...currentConfiguration,
          sdk_enabled: true,
          sdk_config: sdkConfig
        };
        
        // Show enhanced indicator for SDK-enabled apps
        showSDKEnabledIndicator();
      }
    } catch (error) {
      console.error('GrandJury Extension: Error enhancing detection with SDK:', error);
    }
  }
  
  /**
   * Listen for SDK events
   */
  function listenForSDKEvents() {
    try {
      // Listen for SDK interaction events
      document.addEventListener('grandjury:interaction', (event) => {
        if (isInEvaluationMode) {
          console.log('GrandJury Extension: SDK interaction detected during evaluation:', event.detail);
          
          // Could enhance evaluation with SDK interaction data
          if (event.detail && event.detail.type) {
            logEvaluationEvent('sdk_interaction', event.detail);
          }
        }
      });
      
      // Listen for SDK session changes
      document.addEventListener('grandjury:session', (event) => {
        console.log('GrandJury Extension: SDK session event:', event.detail);
        
        // Sync with SDK session changes
        if (event.detail && event.detail.sessionId) {
          syncWithSDKSession(event.detail.sessionId);
        }
      });
      
      // Listen for SDK inference events (NEW)
      document.addEventListener('grandjury:inference', (event) => {
        console.log('GrandJury Extension: SDK inference event:', event.detail);
        
        // Capture inference ID for evaluation tracking
        if (event.detail && event.detail.inferenceId) {
          captureInferenceId(event.detail.inferenceId, event.detail.metadata);
        }
      });
      
      // Listen for SDK evaluation events
      document.addEventListener('grandjury:evaluation', (event) => {
        console.log('GrandJury Extension: SDK evaluation event:', event.detail);
        
        // Handle SDK-triggered evaluations
        if (event.detail && event.detail.action === 'request') {
          handleSDKEvaluationRequest(event.detail);
        }
      });
      
    } catch (error) {
      console.error('GrandJury Extension: Error setting up SDK event listeners:', error);
    }
  }
  
  /**
   * Show enhanced indicator for SDK-enabled apps
   */
  function showSDKEnabledIndicator() {
    // Create a more prominent indicator for SDK-enabled apps
    if (document.getElementById('grandjury-sdk-indicator')) {
      return; // Already exists
    }
    
    const indicator = document.createElement('div');
    indicator.id = 'grandjury-sdk-indicator';
    indicator.style.cssText = `
      position: fixed;
      top: 10px;
      right: 10px;
      width: 12px;
      height: 12px;
      background: linear-gradient(45deg, #4CAF50, #2196F3);
      border-radius: 50%;
      z-index: 10000;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      opacity: 0.8;
      transition: all 0.3s ease;
      border: 2px solid rgba(255,255,255,0.8);
    `;
    
    // Add subtle pulsing animation for SDK apps
    indicator.style.animation = 'grandjury-pulse 2s infinite ease-in-out';
    
    // Add CSS for pulse animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes grandjury-pulse {
        0%, 100% { opacity: 0.8; transform: scale(1); }
        50% { opacity: 1; transform: scale(1.1); }
      }
    `;
    document.head.appendChild(style);
    
    // Fade out after 5 seconds (longer for SDK apps)
    document.body.appendChild(indicator);
    setTimeout(() => {
      if (indicator && indicator.parentNode) {
        indicator.style.opacity = '0';
        setTimeout(() => {
          if (indicator && indicator.parentNode) {
            indicator.remove();
          }
        }, 300);
      }
    }, 5000);
  }
  
  /**
   * Sync with SDK session changes
   */
  function syncWithSDKSession(sessionId) {
    try {
      console.log('GrandJury Extension: Syncing with SDK session:', sessionId.slice(0, 12) + '...');
      
      // Store SDK session in sessionStorage for extension access
      sessionStorage.setItem('grandjurySessionId', sessionId);
      sessionStorage.setItem('grandjury_session_id', sessionId); // Legacy support
      
      // Notify popup if open
      chrome.runtime.sendMessage({
        action: 'SDK_SESSION_UPDATED',
        sessionId: sessionId
      }).catch(() => {
        // Popup may not be open, ignore error
      });
      
    } catch (error) {
      console.error('GrandJury Extension: Error syncing with SDK session:', error);
    }
  }
  
  /**
   * Capture inference ID for evaluation tracking
   */
  function captureInferenceId(inferenceId, metadata) {
    try {
      console.log('GrandJury Extension: Capturing inference ID:', {
        inferenceId: inferenceId,
        metadata: metadata,
        timestamp: new Date().toISOString()
      });

      // Store current inference ID for evaluation
      window.grandjuryCurrentInferenceId = inferenceId;

      // Update global config
      if (window.grandjuryConfig) {
        window.grandjuryConfig.currentInferenceId = inferenceId;
      }

      // Store in sessionStorage for persistence (single current ID)
      sessionStorage.setItem('grandjury_current_inference_id', inferenceId);
      sessionStorage.setItem('grandjury_inference_metadata', JSON.stringify(metadata));

      // Also store in an array to track ALL inference IDs from this session
      const existingIds = sessionStorage.getItem('grandjury_inference_ids');
      let inferenceIdsArray = [];
      if (existingIds) {
        try {
          inferenceIdsArray = JSON.parse(existingIds);
        } catch (e) {
          console.error('Error parsing existing inference IDs:', e);
        }
      }

      // Add new inference ID if not already present
      if (!inferenceIdsArray.includes(inferenceId)) {
        inferenceIdsArray.push(inferenceId);
        sessionStorage.setItem('grandjury_inference_ids', JSON.stringify(inferenceIdsArray));
        console.log(`GrandJury Extension: Total inference IDs captured: ${inferenceIdsArray.length}`);
      }

      // Notify background script about new inference
      chrome.runtime.sendMessage({
        action: 'INFERENCE_CREATED',
        inferenceId: inferenceId,
        metadata: metadata,
        sessionId: window.grandjurySessionId,
        timestamp: new Date().toISOString()
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn('GrandJury Extension: Error notifying background script:', chrome.runtime.lastError);
        } else {
          console.log('GrandJury Extension: Inference ID captured successfully');
        }
      });

      // If we're in evaluation mode, prepare for evaluation with this inference
      if (isInEvaluationMode && currentEvaluationInterface) {
        updateEvaluationWithInference(inferenceId, metadata);
      }

    } catch (error) {
      console.error('GrandJury Extension: Error capturing inference ID:', error);
    }
  }
  
  /**
   * Update current evaluation with inference information
   */
  function updateEvaluationWithInference(inferenceId, metadata) {
    try {
      // Add inference information to evaluation interface
      if (currentEvaluationInterface) {
        const inferenceInfo = currentEvaluationInterface.querySelector('.inference-info');
        if (inferenceInfo) {
          inferenceInfo.innerHTML = `
            <strong>Inference ID:</strong> ${inferenceId}<br>
            <strong>Metadata:</strong> ${JSON.stringify(metadata, null, 2)}
          `;
        } else {
          // Create inference info element
          const infoDiv = document.createElement('div');
          infoDiv.className = 'inference-info';
          infoDiv.style.cssText = 'background: #e3f2fd; padding: 10px; border-radius: 4px; margin: 10px 0; font-family: monospace; font-size: 12px;';
          infoDiv.innerHTML = `
            <strong>Inference Tracking:</strong><br>
            <strong>ID:</strong> ${inferenceId}<br>
            <strong>Metadata:</strong> ${JSON.stringify(metadata, null, 2)}
          `;
          currentEvaluationInterface.insertBefore(infoDiv, currentEvaluationInterface.firstChild);
        }
      }
      
      console.log('GrandJury Extension: Evaluation updated with inference:', inferenceId);
      
    } catch (error) {
      console.error('GrandJury Extension: Error updating evaluation with inference:', error);
    }
  }

  /**
   * Handle SDK-triggered evaluation requests
   */
  function handleSDKEvaluationRequest(detail) {
    try {
      console.log('GrandJury Extension: SDK evaluation request:', detail);
      
      // If we have AI response content from SDK, trigger evaluation
      if (detail.aiResponse && detail.aiResponse.content) {
        const traceId = detail.traceId || 'sdk_trace_' + Date.now();
        
        // Show evaluation interface with SDK data
        showEvaluationInterface(detail.aiResponse.content, traceId);
      }
      
    } catch (error) {
      console.error('GrandJury Extension: Error handling SDK evaluation request:', error);
    }
  }
  
  /**
   * Log evaluation events for analytics
   */
  function logEvaluationEvent(eventType, data) {
    try {
      console.log(`GrandJury Extension: Evaluation event - ${eventType}:`, data);
      
      // Could send to analytics endpoint in the future
      // For now, just log for debugging
      
    } catch (error) {
      console.error('GrandJury Extension: Error logging evaluation event:', error);
    }
  }
  
  /**
   * Check if current page is a configured app
   */
  async function checkIfConfiguredApp(url) {
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'CHECK_URL_MATCH',
        url: url
      });
      
      if (response && response.matched) {
        isGrandJuryApp = true;
        currentConfiguration = response.configuration;
        console.log('GrandJury Extension: Configured app detected');
        
        // Show subtle visual indicator that app is detected
        showAppDetectedIndicator();
      }
    } catch (error) {
      console.error('GrandJury Extension: Error checking app configuration:', error);
    }
  }
  
  /**
   * Handle messages from service worker and popup
   */
  function handleMessage(message, sender, sendResponse) {
    console.log('GrandJury Extension: Content script received message:', message.action);
    
    switch (message.action) {
      case 'APP_DETECTED':
        isGrandJuryApp = true;
        currentConfiguration = message.configuration;
        showAppDetectedIndicator();
        sendResponse({ success: true });
        break;
        
      case 'START_EVALUATION':
        if (isGrandJuryApp) {
          startEvaluationMode();
          sendResponse({ success: true });
        } else {
          sendResponse({ error: 'Not a configured app' });
        }
        break;
        
      case 'SHOW_EVALUATION_INTERFACE':
        if (isInEvaluationMode && message.aiResponse) {
          showEvaluationInterface(message.aiResponse, message.traceId);
          sendResponse({ success: true });
        } else {
          sendResponse({ error: 'Not in evaluation mode' });
        }
        break;
        
      case 'STOP_EVALUATION':
        stopEvaluationMode();
        sendResponse({ success: true });
        break;
        
      case 'GET_PAGE_INFO':
        sendResponse({
          url: window.location.href,
          title: document.title,
          isConfiguredApp: isGrandJuryApp,
          configuration: currentConfiguration
        });
        break;
        
      case 'GET_INFERENCE_DATA':
        // Get inference data from frontend app (async)
        getInferenceDataFromPage().then(inferenceData => {
          sendResponse({
            success: inferenceData !== null,
            data: inferenceData
          });
        }).catch(error => {
          console.error('🔍 [INFERENCE] Error getting inference data:', error);
          sendResponse({
            success: false,
            error: error.message
          });
        });
        return true; // Keep the message channel open for async response
        
      default:
        sendResponse({ error: 'Unknown action' });
    }
  }
  
  /**
   * Show subtle indicator that app is detected (non-intrusive)
   */
  function showAppDetectedIndicator() {
    // Create a minimal, non-intrusive indicator
    if (document.getElementById('grandjury-app-indicator')) {
      return; // Already exists
    }
    
    const indicator = document.createElement('div');
    indicator.id = 'grandjury-app-indicator';
    indicator.style.cssText = `
      position: fixed;
      top: 10px;
      right: 10px;
      width: 8px;
      height: 8px;
      background-color: #4CAF50;
      border-radius: 50%;
      z-index: 10000;
      box-shadow: 0 2px 4px rgba(0,0,0,0.2);
      opacity: 0.7;
      transition: opacity 0.3s ease;
    `;
    
    // Fade out after 3 seconds
    document.body.appendChild(indicator);
    setTimeout(() => {
      if (indicator && indicator.parentNode) {
        indicator.style.opacity = '0';
        setTimeout(() => {
          if (indicator && indicator.parentNode) {
            indicator.remove();
          }
        }, 300);
      }
    }, 3000);
  }
  
  /**
   * Start evaluation mode - prepare page for evaluation
   */
  function startEvaluationMode() {
    try {
      console.log('GrandJury Extension: Starting evaluation mode');
      
      isInEvaluationMode = true;
      
      // Create evaluation overlay
      createEvaluationOverlay();
      
      // Add evaluation context to page
      addEvaluationContext();
      
      // Listen for interactions that might be relevant to evaluation
      addEvaluationListeners();
      
      // Start AI response detection
      startAIResponseDetection();
      
    } catch (error) {
      console.error('GrandJury Extension: Error starting evaluation mode:', error);
    }
  }
  
  /**
   * Stop evaluation mode - clean up
   */
  function stopEvaluationMode() {
    try {
      console.log('GrandJury Extension: Stopping evaluation mode');
      
      isInEvaluationMode = false;
      
      // Stop AI response detection
      stopAIResponseDetection();
      
      // Remove evaluation interface
      if (currentEvaluationInterface && currentEvaluationInterface.parentNode) {
        currentEvaluationInterface.remove();
        currentEvaluationInterface = null;
      }
      
      // Remove evaluation overlay
      if (evaluationOverlay && evaluationOverlay.parentNode) {
        evaluationOverlay.remove();
        evaluationOverlay = null;
      }
      
      // Remove evaluation-specific elements
      const evaluationElements = document.querySelectorAll('[data-grandjury-evaluation]');
      evaluationElements.forEach(element => element.remove());
      
      // Remove event listeners (if we added any)
      removeEvaluationListeners();
      
    } catch (error) {
      console.error('GrandJury Extension: Error stopping evaluation mode:', error);
    }
  }
  
  /**
   * Create evaluation overlay for session info
   */
  function createEvaluationOverlay() {
    if (evaluationOverlay) {
      return; // Already exists
    }
    
    evaluationOverlay = document.createElement('div');
    evaluationOverlay.id = 'grandjury-evaluation-overlay';
    evaluationOverlay.setAttribute('data-grandjury-evaluation', 'true');
    evaluationOverlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      background: linear-gradient(90deg, #2196F3, #4CAF50);
      color: white;
      padding: 8px 16px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      font-weight: 500;
      z-index: 10001;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      text-align: center;
      transition: transform 0.3s ease;
    `;
    
    evaluationOverlay.innerHTML = `
      <span>🔍 Evaluation Session Active</span>
      <button id="grandjury-stop-evaluation" style="
        background: rgba(255,255,255,0.2);
        border: 1px solid rgba(255,255,255,0.3);
        color: white;
        padding: 4px 12px;
        border-radius: 4px;
        margin-left: 16px;
        cursor: pointer;
        font-size: 12px;
      ">Stop Session</button>
    `;
    
    // Add stop button functionality
    const stopButton = evaluationOverlay.querySelector('#grandjury-stop-evaluation');
    stopButton.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'STOP_EVALUATION' });
    });
    
    document.body.appendChild(evaluationOverlay);
    
    // Animate in
    requestAnimationFrame(() => {
      evaluationOverlay.style.transform = 'translateY(0)';
    });
  }
  
  /**
   * Add evaluation context to page
   */
  function addEvaluationContext() {
    if (!currentConfiguration) return;
    
    // Add evaluation instructions to page metadata
    const meta = document.createElement('meta');
    meta.setAttribute('data-grandjury-evaluation', 'true');
    meta.name = 'grandjury-evaluation-config';
    meta.content = JSON.stringify({
      instructions: currentConfiguration.evaluation_instructions,
      creditRates: currentConfiguration.credit_rates,
      appName: currentConfiguration.app_detection?.app_identifier || document.title
    });
    
    document.head.appendChild(meta);
  }
  
  /**
   * Add evaluation-specific event listeners
   */
  function addEvaluationListeners() {
    // Could add listeners for user interactions that are relevant to evaluation
    // For now, we'll keep this minimal to avoid performance impact
    
    // Example: Track significant user actions
    document.addEventListener('click', handleEvaluationClick, { passive: true });
    document.addEventListener('submit', handleEvaluationSubmit, { passive: true });
  }
  
  /**
   * Remove evaluation event listeners
   */
  function removeEvaluationListeners() {
    document.removeEventListener('click', handleEvaluationClick);
    document.removeEventListener('submit', handleEvaluationSubmit);
  }
  
  /**
   * Handle clicks during evaluation (for context)
   */
  function handleEvaluationClick(event) {
    // Log significant interactions for evaluation context
    const target = event.target;
    if (target.matches('button, [role="button"], a, input[type="submit"]')) {
      console.log('GrandJury Evaluation: User interaction -', {
        type: 'click',
        element: target.tagName,
        text: target.textContent?.slice(0, 50) || target.value?.slice(0, 50) || '',
        timestamp: Date.now()
      });
    }
  }
  
  /**
   * Handle form submissions during evaluation
   */
  function handleEvaluationSubmit(event) {
    console.log('GrandJury Evaluation: Form submission -', {
      type: 'submit',
      form: event.target.action || window.location.href,
      timestamp: Date.now()
    });
  }
  
  /**
   * Handle page navigation changes (for SPAs)
   */
  function handleNavigationChange() {
    // Re-check app configuration on navigation changes
    const newUrl = window.location.href;
    checkIfConfiguredApp(newUrl);
  }
  
  // Listen for navigation changes in SPAs
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      handleNavigationChange();
    }
  }).observe(document, { subtree: true, childList: true });
  
  /**
   * AI Response Detection and Evaluation Interface (PBI-004)
   * Implements judgment-first evaluation interface with context loading
   */
  
  function startAIResponseDetection() {
    console.log('GrandJury Extension: Starting AI response detection');
    
    // Create mutation observer to detect new AI responses
    aiResponseDetector = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === 1) { // Element node
            checkForAIResponse(node);
          }
        });
      });
    });
    
    // Start observing the document for changes
    aiResponseDetector.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    // Also check existing content
    checkForAIResponse(document.body);
  }
  
  function stopAIResponseDetection() {
    if (aiResponseDetector) {
      aiResponseDetector.disconnect();
      aiResponseDetector = null;
    }
  }
  
  function checkForAIResponse(element) {
    if (!isInEvaluationMode) return;
    
    // Common AI response indicators
    const aiIndicators = [
      // Text-based indicators
      'assistant response',
      'ai response',
      'generated response',
      // CSS class indicators
      '.assistant-message',
      '.ai-message',
      '.bot-response',
      '.generated-content',
      // Attribute indicators
      '[data-role="assistant"]',
      '[data-type="ai"]',
      '[data-message-type="assistant"]'
    ];
    
    // Check if element or its children contain AI response indicators
    for (const indicator of aiIndicators) {
      let found = false;
      
      if (indicator.startsWith('.') || indicator.startsWith('[')) {
        // CSS selector
        found = element.matches && element.matches(indicator) || 
                element.querySelector && element.querySelector(indicator);
      } else {
        // Text content
        found = element.textContent && 
                element.textContent.toLowerCase().includes(indicator.toLowerCase());
      }
      
      if (found) {
        console.log('GrandJury Extension: AI response detected');
        const aiResponseContent = extractAIResponseContent(element);
        if (aiResponseContent && aiResponseContent.length > 50) { // Minimum content length
          triggerEvaluationInterface(aiResponseContent, element);
        }
        break;
      }
    }
  }
  
  function extractAIResponseContent(element) {
    // Extract the actual AI response text, filtering out UI elements
    const textNodes = [];
    const walker = document.createTreeWalker(
      element,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    
    let node;
    while (node = walker.nextNode()) {
      const text = node.nodeValue.trim();
      if (text && text.length > 10) {
        textNodes.push(text);
      }
    }
    
    return textNodes.join(' ').trim();
  }
  
  function triggerEvaluationInterface(aiResponseContent, sourceElement) {
    // Generate a mock trace ID for this evaluation
    const traceId = 'trace_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    
    console.log('GrandJury Extension: Triggering evaluation interface for trace:', traceId);
    
    // Show evaluation interface with progressive disclosure
    showEvaluationInterface(aiResponseContent, traceId, sourceElement);
  }
  
  async function showEvaluationInterface(aiResponseContent, traceId, sourceElement = null) {
    if (currentEvaluationInterface && currentEvaluationInterface.parentNode) {
      currentEvaluationInterface.remove();
    }
    
    // Create evaluation interface with judgment-first design
    currentEvaluationInterface = document.createElement('div');
    currentEvaluationInterface.id = 'grandjury-evaluation-interface';
    currentEvaluationInterface.setAttribute('data-grandjury-evaluation', 'true');
    currentEvaluationInterface.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 90%;
      max-width: 600px;
      max-height: 80vh;
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.15);
      z-index: 10002;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      overflow: hidden;
      display: flex;
      flex-direction: column;
    `;
    
    // Create backdrop
    const backdrop = document.createElement('div');
    backdrop.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.5);
      z-index: 10001;
    `;
    backdrop.addEventListener('click', () => {
      closeEvaluationInterface();
    });
    
    // Initial interface (judgment-first design)
    currentEvaluationInterface.innerHTML = `
      <div style="padding: 24px; border-bottom: 1px solid #e5e5e5;">
        <h3 style="margin: 0 0 16px 0; color: #333; font-size: 18px; font-weight: 600;">
          🎯 Rate this AI response
        </h3>
        <div style="background: #f8f9fa; padding: 16px; border-radius: 8px; margin-bottom: 20px; max-height: 120px; overflow-y: auto;">
          <div style="font-size: 14px; color: #666; line-height: 1.5;">
            ${aiResponseContent.substring(0, 300)}${aiResponseContent.length > 300 ? '...' : ''}
          </div>
        </div>
      </div>
      
      <div style="padding: 24px; flex: 1; overflow-y: auto;">
        <div id="rating-section">
          <div style="margin-bottom: 20px;">
            <label style="display: block; margin-bottom: 8px; color: #333; font-weight: 500;">
              Your Rating:
            </label>
            <div id="star-rating" style="display: flex; gap: 4px; margin-bottom: 12px;">
              ${Array.from({length: 10}, (_, i) => `
                <span class="star" data-rating="${i + 1}" style="
                  font-size: 24px; 
                  cursor: pointer; 
                  color: #ddd; 
                  transition: color 0.2s;
                  user-select: none;
                ">⭐</span>
              `).join('')}
            </div>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px;">
              <button class="quick-rating" data-rating="9" style="
                background: #4CAF50; color: white; border: none; padding: 6px 12px; 
                border-radius: 16px; font-size: 12px; cursor: pointer;
              ">Excellent</button>
              <button class="quick-rating" data-rating="7" style="
                background: #2196F3; color: white; border: none; padding: 6px 12px; 
                border-radius: 16px; font-size: 12px; cursor: pointer;
              ">Good</button>
              <button class="quick-rating" data-rating="4" style="
                background: #FF9800; color: white; border: none; padding: 6px 12px; 
                border-radius: 16px; font-size: 12px; cursor: pointer;
              ">Needs Work</button>
              <button class="quick-rating" data-rating="2" style="
                background: #F44336; color: white; border: none; padding: 6px 12px; 
                border-radius: 16px; font-size: 12px; cursor: pointer;
              ">Poor</button>
            </div>
          </div>
          
          <div style="margin-bottom: 20px;">
            <label style="display: block; margin-bottom: 8px; color: #333; font-weight: 500;">
              Your Feedback (optional):
            </label>
            <textarea id="evaluation-feedback" placeholder="What makes this response good or bad?" style="
              width: 100%; height: 80px; padding: 12px; border: 1px solid #ddd; 
              border-radius: 6px; font-size: 14px; resize: vertical; box-sizing: border-box;
            "></textarea>
          </div>
          
          <div style="display: flex; gap: 12px; justify-content: space-between;">
            <button id="continue-with-rating" disabled style="
              background: #2196F3; color: white; border: none; padding: 12px 24px; 
              border-radius: 6px; font-weight: 500; cursor: pointer; flex: 1;
              opacity: 0.5;
            ">Continue with My Rating</button>
            <button id="see-context-first" style="
              background: transparent; color: #2196F3; border: 1px solid #2196F3; 
              padding: 12px 24px; border-radius: 6px; font-weight: 500; cursor: pointer;
            ">See Context First</button>
          </div>
        </div>
        
        <div id="context-section" style="display: none;">
          <div id="context-loading" style="text-align: center; padding: 40px;">
            <div style="font-size: 16px; color: #666; margin-bottom: 12px;">🔄 Loading context...</div>
            <div style="font-size: 14px; color: #999;">Fetching AI metrics and evaluation history</div>
          </div>
          <div id="context-content" style="display: none;"></div>
        </div>
      </div>
      
      <div style="padding: 16px 24px; border-top: 1px solid #e5e5e5; background: #f8f9fa;">
        <button id="close-evaluation" style="
          background: transparent; color: #666; border: none; 
          padding: 8px 16px; cursor: pointer; float: right;
        ">Close</button>
      </div>
    `;
    
    // Add to DOM
    document.body.appendChild(backdrop);
    document.body.appendChild(currentEvaluationInterface);
    
    // Add event listeners
    setupEvaluationInterfaceListeners(traceId, aiResponseContent);
    
    // Start loading context in background
    loadEvaluationContext(traceId, aiResponseContent);
  }
  
  function setupEvaluationInterfaceListeners(traceId, aiResponseContent) {
    let currentRating = 0;
    let initialBlindRating = 0;
    
    // Star rating
    const stars = currentEvaluationInterface.querySelectorAll('.star');
    const continueButton = currentEvaluationInterface.querySelector('#continue-with-rating');
    
    stars.forEach((star, index) => {
      star.addEventListener('mouseenter', () => {
        updateStarDisplay(index + 1);
      });
      
      star.addEventListener('mouseleave', () => {
        updateStarDisplay(currentRating);
      });
      
      star.addEventListener('click', () => {
        currentRating = index + 1;
        updateStarDisplay(currentRating);
        continueButton.disabled = false;
        continueButton.style.opacity = '1';
        continueButton.style.cursor = 'pointer';
        
        if (!initialBlindRating) {
          initialBlindRating = currentRating;
        }
      });
    });
    
    // Quick rating buttons
    const quickButtons = currentEvaluationInterface.querySelectorAll('.quick-rating');
    quickButtons.forEach(button => {
      button.addEventListener('click', () => {
        currentRating = parseInt(button.dataset.rating);
        updateStarDisplay(currentRating);
        continueButton.disabled = false;
        continueButton.style.opacity = '1';
        continueButton.style.cursor = 'pointer';
        
        if (!initialBlindRating) {
          initialBlindRating = currentRating;
        }
      });
    });
    
    // Continue with rating
    continueButton.addEventListener('click', () => {
      showContextComparison(currentRating, initialBlindRating, traceId, aiResponseContent);
    });
    
    // See context first
    currentEvaluationInterface.querySelector('#see-context-first').addEventListener('click', () => {
      showContextSection();
    });
    
    // Close button
    currentEvaluationInterface.querySelector('#close-evaluation').addEventListener('click', () => {
      closeEvaluationInterface();
    });
    
    function updateStarDisplay(rating) {
      stars.forEach((star, index) => {
        star.style.color = index < rating ? '#FFD700' : '#ddd';
      });
    }
  }
  
  async function loadEvaluationContext(traceId, aiResponseContent) {
    try {
      // Get auth token from storage
      const authToken = await chrome.storage.local.get(['authToken']);
      if (!authToken.authToken) {
        console.warn('GrandJury Extension: No auth token available for context loading');
        return;
      }
      
      // Prepare request data
      const requestData = {
        trace_id: traceId,
        evaluation_config_id: currentConfiguration?.id || '00000000-0000-0000-0000-000000000000',
        ai_response_content: aiResponseContent,
        session_metadata: {
          url: window.location.href,
          timestamp: Date.now(),
          user_agent: navigator.userAgent
        }
      };
      
      // Make API request to load context
      const response = await fetch('http://localhost:8000/api/v1/evaluation-context/load', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken.authToken}`
        },
        body: JSON.stringify(requestData)
      });
      
      if (response.ok) {
        const contextData = await response.json();
        console.log('GrandJury Extension: Context loaded successfully:', contextData);
        
        // Store context for later use
        currentEvaluationInterface.contextData = contextData;
      } else {
        console.warn('GrandJury Extension: Context loading failed:', response.status);
      }
      
    } catch (error) {
      console.error('GrandJury Extension: Error loading evaluation context:', error);
    }
  }
  
  function showContextSection() {
    const ratingSection = currentEvaluationInterface.querySelector('#rating-section');
    const contextSection = currentEvaluationInterface.querySelector('#context-section');
    
    ratingSection.style.display = 'none';
    contextSection.style.display = 'block';
    
    // Show context if available
    if (currentEvaluationInterface.contextData) {
      displayContextData(currentEvaluationInterface.contextData);
    }
  }
  
  function showContextComparison(userRating, initialRating, traceId, aiResponseContent) {
    const contextData = currentEvaluationInterface.contextData;
    
    const comparisonHTML = `
      <div style="background: #e8f5e8; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
        <div style="font-weight: 600; color: #2e7d32; margin-bottom: 8px;">
          ✅ Your Rating: ${userRating}/10
        </div>
        <div style="font-size: 14px; color: #555;">
          ${getRatingDescription(userRating)}
        </div>
      </div>
      
      ${contextData ? generateContextDisplay(contextData, userRating) : `
        <div style="background: #fff3cd; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
          <div style="color: #856404;">
            ℹ️ Context loading unavailable, but your evaluation is still valuable.
          </div>
        </div>
      `}
      
      <div style="margin-bottom: 16px;">
        <label style="display: block; margin-bottom: 8px; color: #333; font-weight: 500;">
          Want to adjust your rating?
        </label>
        <div style="display: flex; gap: 12px;">
          <button id="keep-rating" style="
            background: #4CAF50; color: white; border: none; padding: 8px 16px; 
            border-radius: 4px; cursor: pointer; flex: 1;
          ">Keep ${userRating}/10</button>
          <button id="change-rating" style="
            background: transparent; color: #2196F3; border: 1px solid #2196F3; 
            padding: 8px 16px; border-radius: 4px; cursor: pointer;
          ">Change</button>
        </div>
      </div>
      
      <button id="submit-final-evaluation" style="
        background: #2196F3; color: white; border: none; padding: 12px 24px; 
        border-radius: 6px; font-weight: 500; cursor: pointer; width: 100%;
      ">Submit Final Evaluation</button>
    `;
    
    const ratingSection = currentEvaluationInterface.querySelector('#rating-section');
    ratingSection.innerHTML = comparisonHTML;
    
    // Add event listeners for final actions
    currentEvaluationInterface.querySelector('#keep-rating').addEventListener('click', () => {
      submitEvaluation(userRating, initialRating, traceId, aiResponseContent);
    });
    
    currentEvaluationInterface.querySelector('#change-rating').addEventListener('click', () => {
      location.reload(); // Reset interface
    });
    
    currentEvaluationInterface.querySelector('#submit-final-evaluation').addEventListener('click', () => {
      submitEvaluation(userRating, initialRating, traceId, aiResponseContent);
    });
  }
  
  function generateContextDisplay(contextData, userRating) {
    const { context, availability, loading_time_ms } = contextData;
    
    let html = `<div style="background: #f8f9fa; padding: 16px; border-radius: 8px; margin-bottom: 20px;">`;
    
    // AI Performance Context
    if (availability.langfuse_available && context.langfuse_metrics) {
      const metrics = context.langfuse_metrics;
      html += `
        <div style="margin-bottom: 16px;">
          <div style="font-weight: 600; color: #333; margin-bottom: 8px;">📊 AI Performance Context:</div>
          <div style="font-size: 14px; color: #666; line-height: 1.4;">
            ${metrics.llm_score ? `• LLM Score: ${metrics.llm_score}/10` : '• LLM Score: Not available'}<br>
            ${metrics.generation_time_seconds ? `• Generation Time: ${metrics.generation_time_seconds.toFixed(1)} seconds` : ''}<br>
            ${metrics.cost_usd ? `• Cost: $${metrics.cost_usd.toFixed(4)}` : '• Cost: Not available'}<br>
            ${metrics.model_name ? `• Model: ${metrics.model_name}` : '• Model: Not specified'}
          </div>
        </div>
      `;
    }
    
    // Previous Human Evaluations
    if (availability.previous_evals_available && context.previous_evaluations) {
      const prevEvals = context.previous_evaluations;
      if (prevEvals.total_evaluations > 0) {
        html += `
          <div style="margin-bottom: 16px;">
            <div style="font-weight: 600; color: #333; margin-bottom: 8px;">👥 Previous Human Evaluations:</div>
            <div style="font-size: 14px; color: #666; line-height: 1.4;">
              • Average: ${prevEvals.average_score}/10 from ${prevEvals.total_evaluations} evaluators<br>
              • Your rating (${userRating}) vs community (${prevEvals.average_score}) - ${compareRatings(userRating, prevEvals.average_score)}
            </div>
          </div>
        `;
      } else {
        html += `
          <div style="margin-bottom: 16px;">
            <div style="font-weight: 600; color: #333; margin-bottom: 8px;">👥 Previous Human Evaluations:</div>
            <div style="font-size: 14px; color: #666;">
              • First evaluation - You're pioneering the assessment of this response!
            </div>
          </div>
        `;
      }
    }
    
    // Session Context
    if (availability.session_context_available && context.session_context) {
      const sessionCtx = context.session_context;
      html += `
        <div style="margin-bottom: 16px;">
          <div style="font-weight: 600; color: #333; margin-bottom: 8px;">🔍 Session Context:</div>
          <div style="font-size: 14px; color: #666; line-height: 1.4;">
            ${sessionCtx.question_number ? `• Question #${sessionCtx.question_number} in this session` : ''}<br>
            ${sessionCtx.user_type ? `• ${sessionCtx.user_type}` : ''}<br>
            ${sessionCtx.app_section ? `• ${sessionCtx.app_section}` : ''}
          </div>
        </div>
      `;
    }
    
    html += `</div>`;
    
    return html;
  }
  
  function compareRatings(userRating, avgRating) {
    const diff = Math.abs(userRating - avgRating);
    if (diff < 0.5) return "Right in line!";
    if (userRating > avgRating) return "You're more optimistic!";
    return "You spotted issues others missed!";
  }
  
  function getRatingDescription(rating) {
    if (rating >= 9) return "Excellent - outstanding AI response";
    if (rating >= 7) return "Good - solid AI response with minor issues";
    if (rating >= 5) return "Acceptable - AI response needs some improvement";
    if (rating >= 3) return "Poor - significant issues with AI response";
    return "Very poor - AI response has major problems";
  }
  
  function displayContextData(contextData) {
    const contextContent = currentEvaluationInterface.querySelector('#context-content');
    const contextLoading = currentEvaluationInterface.querySelector('#context-loading');
    
    contextLoading.style.display = 'none';
    contextContent.style.display = 'block';
    contextContent.innerHTML = generateContextDisplay(contextData, 0);
  }
  
  async function submitEvaluation(finalRating, initialRating, traceId, aiResponseContent) {
    try {
      const feedback = currentEvaluationInterface.querySelector('#evaluation-feedback')?.value || '';
      const contextData = currentEvaluationInterface.contextData;
      
      const evaluationData = {
        trace_id: traceId,
        evaluator_rating: finalRating,
        evaluator_feedback: feedback,
        context_viewed: !!contextData,
        initial_blind_rating: initialRating,
        final_rating: finalRating,
        context_available: contextData?.availability || {
          langfuse_available: false,
          previous_evals_available: false,
          session_context_available: false
        },
        timestamp: new Date().toISOString(),
        ai_response_content: aiResponseContent,
        session_url: window.location.href
      };
      
      // Store evaluation data locally for PBI-005 to submit later
      const existingEvaluations = await chrome.storage.local.get(['pendingEvaluations']);
      const pendingEvaluations = existingEvaluations.pendingEvaluations || [];
      pendingEvaluations.push(evaluationData);
      
      await chrome.storage.local.set({ pendingEvaluations });
      
      console.log('GrandJury Extension: Evaluation saved locally:', evaluationData);
      
      // Show success message
      showEvaluationSuccess(finalRating);
      
    } catch (error) {
      console.error('GrandJury Extension: Error submitting evaluation:', error);
      showEvaluationError();
    }
  }
  
  function showEvaluationSuccess(rating) {
    currentEvaluationInterface.innerHTML = `
      <div style="padding: 40px; text-align: center;">
        <div style="font-size: 48px; margin-bottom: 16px;">✅</div>
        <h3 style="margin: 0 0 12px 0; color: #4CAF50; font-size: 20px;">
          Evaluation Submitted Successfully!
        </h3>
        <p style="margin: 0 0 20px 0; color: #666; font-size: 14px;">
          Your rating of ${rating}/10 has been saved and will help improve AI systems.
        </p>
        <button id="close-success" style="
          background: #4CAF50; color: white; border: none; padding: 12px 24px; 
          border-radius: 6px; font-weight: 500; cursor: pointer;
        ">Continue Evaluating</button>
      </div>
    `;
    
    currentEvaluationInterface.querySelector('#close-success').addEventListener('click', () => {
      closeEvaluationInterface();
    });
    
    // Auto-close after 3 seconds
    setTimeout(() => {
      closeEvaluationInterface();
    }, 3000);
  }
  
  function showEvaluationError() {
    currentEvaluationInterface.innerHTML = `
      <div style="padding: 40px; text-align: center;">
        <div style="font-size: 48px; margin-bottom: 16px;">❌</div>
        <h3 style="margin: 0 0 12px 0; color: #F44336; font-size: 20px;">
          Evaluation Save Failed
        </h3>
        <p style="margin: 0 0 20px 0; color: #666; font-size: 14px;">
          There was an error saving your evaluation. Please try again.
        </p>
        <button id="close-error" style="
          background: #F44336; color: white; border: none; padding: 12px 24px; 
          border-radius: 6px; font-weight: 500; cursor: pointer;
        ">Close</button>
      </div>
    `;
    
    currentEvaluationInterface.querySelector('#close-error').addEventListener('click', () => {
      closeEvaluationInterface();
    });
  }
  
  function closeEvaluationInterface() {
    // Remove backdrop
    const backdrop = document.querySelector('div[style*="position: fixed"][style*="background: rgba(0,0,0,0.5)"]');
    if (backdrop && backdrop.parentNode) {
      backdrop.remove();
    }
    
    // Remove interface
    if (currentEvaluationInterface && currentEvaluationInterface.parentNode) {
      currentEvaluationInterface.remove();
      currentEvaluationInterface = null;
    }
  }

  /**
   * Get inference data from the frontend app
   * This checks for GrandJury SDK variables and current inference ID
   */
  async function getInferenceDataFromPage() {
    try {
      console.log('🔍 [INFERENCE] Checking page for inference data...');

      // CSP blocks inline scripts, so we check sessionStorage instead
      // The SDK should store project ID in sessionStorage for extension access
      const pageData = {
        hasSDK: false,
        projectId: sessionStorage.getItem('grandjury_project_id') || sessionStorage.getItem('grandjuryProjectId'),
        inferenceId: sessionStorage.getItem('grandjury_current_inference_id'),
        sdkVersion: sessionStorage.getItem('grandjury_sdk_version'),
        sessionId: sessionStorage.getItem('grandjury_session_id')
      };

      const hasSDK = pageData.hasSDK || false;
      const projectId = pageData.projectId;

      // Check for project ID from grandjuryConfig (set by SDK) or fallback variables
      console.log('🔍 [INFERENCE] Project ID check:', {
        projectId: pageData.projectId,
        sdkVersion: pageData.sdkVersion
      });

      // Check for global inference variables (set by SDK)
      console.log('🔍 [INFERENCE] Available window variables:', {
        sessionStorage_grandjuryInferenceId: sessionStorage.getItem('grandjury_current_inference_id'),
        sessionStorage_grandJuryInferenceId: sessionStorage.getItem('grandjury_inference_record'),
        // Check all sessionStorage keys that might be related
        allSessionKeys: Object.keys(sessionStorage).filter(key => key.toLowerCase().includes('inference'))
      });

      // Try to get inference ID from multiple sources
      let currentInferenceId = pageData.inferenceId || sessionStorage.getItem('grandjury_current_inference_id');

      // If not found, try to parse from inference record
      if (!currentInferenceId) {
        try {
          const inferenceRecord = sessionStorage.getItem('grandjury_inference_record');
          if (inferenceRecord) {
            const parsed = JSON.parse(inferenceRecord);
            currentInferenceId = parsed.id;
          }
        } catch (error) {
          console.log('🔍 [INFERENCE] Error parsing inference record:', error);
        }
      }

      const sdkVersion = pageData.sdkVersion;

      // Get additional SDK info
      let sdkStatus = 'Not detected';
      if (hasSDK) {
        sdkStatus = 'Connected & Ready';
      }

      const inferenceData = {
        inferenceId: currentInferenceId,
        projectId: projectId, // ✅ Include project ID at top level for easy access
        sdkStatus: sdkStatus,
        timestamp: new Date().toISOString(),
        metadata: {
          hasSDK: hasSDK,
          sdkVersion: sdkVersion,
          projectId: projectId,
          url: window.location.href,
          title: document.title
        }
      };

      console.log('🔍 [INFERENCE] Found inference data:', inferenceData);

      // Return data if we found an inference ID or SDK
      if (currentInferenceId || hasSDK) {
        return inferenceData;
      } else {
        console.log('🔍 [INFERENCE] No inference data found on page');
        return {
          status: 'No inference ID detected',
          sdkStatus: 'SDK not detected',
          timestamp: new Date().toISOString(),
          metadata: {
            hasSDK: false,
            url: window.location.href,
            title: document.title
          }
        };
      }

    } catch (error) {
      console.error('🔍 [INFERENCE] Error getting inference data from page:', error);
      return {
        status: 'Error: ' + error.message,
        sdkStatus: 'Error checking SDK',
        timestamp: new Date().toISOString(),
        metadata: {
          error: error.message
        }
      };
    }
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeContentScript);
  } else {
    initializeContentScript();
  }
  
})();