/**
 * GrandJury Authentication Capture Content Script
 * CSP-compliant version for grandjury.xyz authentication
 */

// ============================================================================
// CONFIGURATION - Toggle visual indicators for debugging
// Set to true to show auth status toasts, false to hide them
// ============================================================================
const SHOW_AUTH_INDICATORS = false;

// Only run on GrandJury domains
if (window.location.hostname.includes('grandjury.xyz') ||
    window.location.hostname.includes('humanjudge.com') ||
    window.location.hostname.includes('grandjury-server.onrender.com') ||
    window.location.hostname.includes('localhost') ||
    window.location.hostname.includes('127.0.0.1')) {
  
  console.log('GrandJury Auth Capture: CSP-compliant script loaded on', window.location.hostname);
  
  // Immediate token check without complex monitoring to avoid CSP issues
  console.log('GrandJury Auth Capture: Starting immediate authentication check');
  performImmediateAuthCheck();
  
  /**
   * Perform immediate authentication check (CSP-compliant)
   */
  function performImmediateAuthCheck() {
    // Create simple visual indicator
    addSimpleIndicator();

    // Check for authentication token immediately
    const result = findAuthToken();

    if (result.token) {
      console.log('GrandJury Auth Capture: Found valid auth token, sending to extension');
      sendTokenToExtension(result.token);
    } else if (result.expired) {
      // Token exists but is expired - wait for Supabase to auto-refresh
      console.log('GrandJury Auth Capture: Token expired, waiting for Supabase auto-refresh...');
      updateSimpleIndicator('🔄 Session refreshing...', '#2196F3');
      waitForTokenRefresh();
    } else {
      console.log('GrandJury Auth Capture: No auth token found, retrying in 2 seconds');
      // Retry after 2 seconds for page load
      setTimeout(() => {
        const retryResult = findAuthToken();
        if (retryResult.token) {
          sendTokenToExtension(retryResult.token);
        } else if (retryResult.expired) {
          // Still expired after wait, try refresh wait
          waitForTokenRefresh();
        } else {
          showLoginPrompt();
        }
      }, 2000);
    }
  }

  /**
   * Wait for Supabase to auto-refresh the token
   */
  function waitForTokenRefresh() {
    let attempts = 0;
    const maxAttempts = 10; // 10 attempts * 500ms = 5 seconds max wait

    const checkInterval = setInterval(() => {
      attempts++;
      console.log(`GrandJury Auth Capture: Checking for refreshed token (attempt ${attempts}/${maxAttempts})`);

      const result = findAuthToken();

      if (result.token) {
        clearInterval(checkInterval);
        console.log('GrandJury Auth Capture: ✅ Got refreshed token!');
        sendTokenToExtension(result.token);
      } else if (attempts >= maxAttempts) {
        clearInterval(checkInterval);
        console.log('GrandJury Auth Capture: ❌ Token refresh timed out, user needs to re-login');
        showExpiredTokenMessage();
      }
    }, 500);
  }
  
  /**
   * Check if token is expired
   */
  function isTokenExpired(parsed) {
    // Supabase stores expires_at as Unix timestamp (seconds)
    if (parsed.expires_at) {
      const expiresAt = parsed.expires_at * 1000; // Convert to milliseconds
      const now = Date.now();
      const isExpired = now >= expiresAt;

      if (isExpired) {
        const expiredAgo = Math.round((now - expiresAt) / 1000 / 60); // minutes ago
        console.log(`GrandJury Auth Capture: Token EXPIRED ${expiredAgo} minutes ago`);
      } else {
        const validFor = Math.round((expiresAt - now) / 1000 / 60); // minutes remaining
        console.log(`GrandJury Auth Capture: Token valid for ${validFor} more minutes`);
      }

      return isExpired;
    }

    // If no expires_at, assume token might be valid
    console.log('GrandJury Auth Capture: No expires_at field, assuming token is valid');
    return false;
  }

  /**
   * Find authentication token in localStorage (CSP-compliant)
   * Returns { token: string|null, expired: boolean }
   */
  function findAuthToken() {
    try {
      // Mock token disabled - using real authentication

      // We know the exact key from testing: sb-oodfmtbnkumtfhcdzqoi-auth-token
      const authData = localStorage.getItem('sb-oodfmtbnkumtfhcdzqoi-auth-token');
      if (authData) {
        const parsed = JSON.parse(authData);
        if (parsed.access_token) {
          console.log('GrandJury Auth Capture: Found Supabase token');

          // Check if token is expired
          if (isTokenExpired(parsed)) {
            console.log('GrandJury Auth Capture: ⚠️ Token is EXPIRED, waiting for refresh');
            // DON'T clear the token - Supabase needs the refresh_token to auto-refresh
            return { token: null, expired: true };
          }

          return { token: parsed.access_token, expired: false };
        }
      }

      // Fallback: check other possible keys
      const fallbackKeys = [
        'sb-localhost-auth-token',
        'supabase.auth.token'
      ];

      for (const key of fallbackKeys) {
        const fallbackAuth = localStorage.getItem(key);
        if (fallbackAuth) {
          const parsed = JSON.parse(fallbackAuth);
          if (parsed.access_token) {
            console.log('GrandJury Auth Capture: Found token with fallback key:', key);

            // Check if token is expired
            if (isTokenExpired(parsed)) {
              console.log('GrandJury Auth Capture: ⚠️ Fallback token is EXPIRED');
              return { token: null, expired: true };
            }

            return { token: parsed.access_token, expired: false };
          }
        }
      }

      return { token: null, expired: false };
    } catch (error) {
      console.log('GrandJury Auth Capture: Error finding auth token:', error);
      return { token: null, expired: false };
    }
  }

  /**
   * Show expired token message to user
   */
  function showExpiredTokenMessage() {
    updateSimpleIndicator('⚠️ Session expired - Please log in again', '#FF9800');
  }

  /**
   * Check for existing authentication tokens (legacy function)
   */
  function checkForAuthentication() {
    // Method 1: Check localStorage for Supabase tokens
    // Look for various possible Supabase storage keys
    const possibleKeys = [
      'sb-oodfmtbnkumtfhcdzqoi-auth-token',  // Your actual Supabase project ID
      'sb-localhost-auth-token',
      'sb-ojxdwcuwfbkxflozyiiy-auth-token',
      'supabase.auth.token',
      'sb-auth-token'
    ];
    
    for (const key of possibleKeys) {
      const supabaseAuth = localStorage.getItem(key);
      if (supabaseAuth) {
        try {
          const authData = JSON.parse(supabaseAuth);
          if (authData.access_token) {
            console.log('GrandJury Auth Capture: Found Supabase token in localStorage with key:', key);
            sendTokenToExtension(authData.access_token);
            return;
          }
        } catch (error) {
          console.log('GrandJury Auth Capture: Error parsing Supabase auth data:', error);
        }
      }
    }
    
    // Method 2: Check sessionStorage
    const sessionAuth = sessionStorage.getItem('supabase.auth.token');
    if (sessionAuth) {
      try {
        const authData = JSON.parse(sessionAuth);
        if (authData.access_token) {
          console.log('GrandJury Auth Capture: Found token in sessionStorage');
          sendTokenToExtension(authData.access_token);
          return;
        }
      } catch (error) {
        console.log('GrandJury Auth Capture: Error parsing session auth data:', error);
      }
    }
    
    // Method 3: Check for authentication state in the page
    // This might be available in React state or global variables
    if (window.__SUPABASE_AUTH__ && window.__SUPABASE_AUTH__.access_token) {
      console.log('GrandJury Auth Capture: Found token in global state');
      sendTokenToExtension(window.__SUPABASE_AUTH__.access_token);
      return;
    }
    
    // Method 4: Wait for React app to load and check for auth state
    setTimeout(() => {
      checkReactAuthState();
    }, 2000);
  }
  
  /**
   * Check React application auth state
   */
  function checkReactAuthState() {
    // Look for authentication indicators in the DOM
    const userElements = [
      'data-user-authenticated',
      'data-auth-token', 
      'data-user-id'
    ];
    
    for (const attr of userElements) {
      const element = document.querySelector(`[${attr}]`);
      if (element) {
        const token = element.getAttribute(attr);
        if (token && token !== 'null' && token !== 'undefined') {
          console.log('GrandJury Auth Capture: Found token in DOM attribute');
          sendTokenToExtension(token);
          return;
        }
      }
    }
    
    // Check if user appears to be logged in (look for user profile elements)
    const profileElements = document.querySelectorAll('[data-testid*="user"], [class*="user-profile"], .user-menu, .profile-menu');
    if (profileElements.length > 0) {
      console.log('GrandJury Auth Capture: User appears logged in, waiting for token...');
      showAuthenticationWaiting();
    } else {
      console.log('GrandJury Auth Capture: No authentication found, user needs to log in');
      showLoginPrompt();
    }
  }
  
  /**
   * Set up monitoring for authentication state changes
   */
  function setUpAuthenticationMonitoring() {
    // Monitor localStorage changes
    const originalSetItem = localStorage.setItem;
    localStorage.setItem = function(key, value) {
      originalSetItem.apply(this, arguments);
      
      if (key.includes('auth') || key.includes('supabase')) {
        console.log('GrandJury Auth Capture: localStorage auth change detected');
        setTimeout(() => checkForAuthentication(), 500);
      }
    };
    
    // Monitor sessionStorage changes
    const originalSessionSetItem = sessionStorage.setItem;
    sessionStorage.setItem = function(key, value) {
      originalSessionSetItem.apply(this, arguments);
      
      if (key.includes('auth') || key.includes('supabase')) {
        console.log('GrandJury Auth Capture: sessionStorage auth change detected');
        setTimeout(() => checkForAuthentication(), 500);
      }
    };
    
    // Monitor DOM changes for auth elements
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          // Check if any new elements contain auth information
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              checkElementForAuth(node);
            }
          }
        }
      }
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
  
  /**
   * Check DOM element for authentication data
   */
  function checkElementForAuth(element) {
    // Check if element has auth-related attributes
    const authAttributes = ['data-user-id', 'data-auth-token', 'data-session'];
    for (const attr of authAttributes) {
      if (element.hasAttribute && element.hasAttribute(attr)) {
        const value = element.getAttribute(attr);
        if (value && value !== 'null') {
          console.log('GrandJury Auth Capture: Found auth data in new DOM element');
          sendTokenToExtension(value);
          return;
        }
      }
    }
    
    // Check if element contains auth data in text content (like script tags)
    if (element.textContent && element.textContent.includes('access_token')) {
      try {
        const matches = element.textContent.match(/"access_token":\s*"([^"]+)"/);
        if (matches && matches[1]) {
          console.log('GrandJury Auth Capture: Found token in script content');
          sendTokenToExtension(matches[1]);
          return;
        }
      } catch (error) {
        console.log('GrandJury Auth Capture: Error parsing script content:', error);
      }
    }
  }
  
  /**
   * Send authentication token to Chrome extension (CSP-compliant)
   */
  function sendTokenToExtension(token) {
    console.log('GrandJury Auth Capture: Sending token to extension via postMessage');
    
    try {
      // Always use postMessage to avoid CSP issues
      window.postMessage({
        type: 'GRANDJURY_AUTH_TOKEN',
        action: 'SET_AUTH_TOKEN',
        token: token,
        source: 'grandjury_auth_capture',
        timestamp: Date.now()
      }, '*');
      
      console.log('GrandJury Auth Capture: ✅ Token sent via postMessage');
      showAuthSuccess();
      
    } catch (error) {
      console.error('GrandJury Auth Capture: Error sending token:', error);
      showAuthError('Failed to authenticate with extension');
    }
  }

  /**
   * Add simple visual indicator (CSP-compliant)
   */
  function addSimpleIndicator() {
    if (!SHOW_AUTH_INDICATORS) return null;

    try {
      const indicator = document.createElement('div');
      indicator.id = 'grandjury-auth-indicator';
      indicator.className = 'grandjury-auth-detection-element'; // Add class for detection
      indicator.innerHTML = '🔄 Checking authentication...';
      indicator.style.cssText = 'position:fixed;bottom:20px;right:20px;background:#2196F3;color:white;padding:10px;border-radius:5px;z-index:9999;font-size:12px;';
      document.body.appendChild(indicator);
      return indicator;
    } catch (error) {
      console.log('GrandJury Auth Capture: Could not add indicator (CSP):', error);
      return null;
    }
  }
  
  /**
   * Add visual indicator for extension authentication
   */
  function addExtensionAuthIndicator() {
    if (!SHOW_AUTH_INDICATORS) return null;

    // Create indicator element
    const indicator = document.createElement('div');
    indicator.id = 'grandjury-extension-auth-indicator';
    indicator.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: #2196F3;
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      font-weight: 500;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 10000;
      max-width: 300px;
      border-left: 4px solid #1976D2;
    `;
    indicator.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <div style="width: 8px; height: 8px; background: #4CAF50; border-radius: 50%; animation: pulse 2s infinite;"></div>
        <span>grandjury Extension Authentication</span>
      </div>
      <div style="font-size: 12px; opacity: 0.9; margin-top: 4px;">
        Waiting for authentication...
      </div>
    `;
    
    // Add pulsing animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.5; }
        100% { opacity: 1; }
      }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(indicator);
    
    return indicator;
  }
  
  /**
   * Show login prompt to user
   */
  function showLoginPrompt() {
    updateIndicator('⚠️ Please log in to authenticate the extension', '#FF9800');
  }
  
  /**
   * Show authentication waiting state
   */
  function showAuthenticationWaiting() {
    updateIndicator('🔄 Detecting authentication... Please wait', '#2196F3');
  }
  
  /**
   * Show authentication success
   */
  function showAuthSuccess() {
    updateSimpleIndicator('✅ Extension authenticated successfully!', '#4CAF50');
  }
  
  /**
   * Show authentication error
   */
  function showAuthError(message) {
    updateSimpleIndicator(`❌ ${message}`, '#F44336');
  }
  
  /**
   * Show login prompt to user
   */
  function showLoginPrompt() {
    updateSimpleIndicator('⚠️ Please log in to authenticate extension', '#FF9800');
  }
  
  /**
   * Update the simple indicator element
   */
  function updateSimpleIndicator(message, color) {
    try {
      const indicator = document.getElementById('grandjury-auth-indicator');
      if (indicator) {
        indicator.innerHTML = message;
        indicator.style.background = color;
      }
    } catch (error) {
      console.log('GrandJury Auth Capture: Could not update indicator:', error);
    }
  }
  
  console.log('GrandJury Auth Capture: Content script initialized');
}